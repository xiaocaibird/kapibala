# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/delivery-read-causal-followup.spec.ts >> [INT-READ-SAVE-ROLLBACK-001] publicly initiated send survives a real original-history save rollback and same-key process recovery
- Location: tests/system/delivery-read-causal-followup.spec.ts:42:1

# Error details

```
AssertionError: 原消息实际副作用未唯一落地

0 !== 1

```

# Test source

```ts
  200 |       durationMs: 5000,
  201 |     });
  202 |     if (!runs.complete) throw new BlockedError('保存专项未取得原公开run');
  203 |     const runId = runs.last[0]!.id;
  204 |     if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(runId))
  205 |       throw new BlockedError('原run identity不是可安全定位的UUID');
  206 |     let lease = await control.arm('observe-tool-wait', {
  207 |       kind: 'tool-wait',
  208 |       groupId: group.id,
  209 |       runId,
  210 |       toolUseId: 'all-run-steps',
  211 |     });
  212 |     // Only this fresh run and this actual tool_result are rejected. The model
  213 |     // response history and unrelated rows remain readable/writable. No business
  214 |     // rows, active budgets, completed steps or idempotency records are seeded.
  215 |     await verifyOwnership();
  216 |     await observer.query(`CREATE FUNCTION public."${functionName}"() RETURNS trigger LANGUAGE plpgsql AS $qa$
  217 |       BEGIN
  218 |         IF NEW.id::text='${runId}' AND EXISTS (
  219 |           SELECT 1 FROM jsonb_array_elements(COALESCE(NEW.history::jsonb,'[]'::jsonb)) AS m,
  220 |           LATERAL jsonb_array_elements(CASE WHEN jsonb_typeof(m->'content')='array'
  221 |             THEN m->'content' ELSE '[]'::jsonb END) AS t
  222 |           WHERE t->>'type'='tool_result' AND t->>'tool_use_id'='${tool}') THEN
  223 |           RAISE EXCEPTION 'independent QA owned history fault' USING ERRCODE='P0001';
  224 |         END IF;
  225 |         RETURN NEW;
  226 |       END $qa$`);
  227 |     createdFunction = true;
  228 |     await observer.query(`CREATE TRIGGER "${triggerName}" BEFORE UPDATE OF history ON public.agent_runs
  229 |       FOR EACH ROW EXECUTE FUNCTION public."${functionName}"()`);
  230 |     createdTrigger = true;
  231 |     evidence.faultInstalled = {
  232 |       runId,
  233 |       groupId: group.id,
  234 |       toolUseId: tool,
  235 |       at: new Date().toISOString(),
  236 |     };
  237 |     qa.agent.barriers.release(modelBarrier);
  238 |     await qa.gateway.barriers.waitFor(sendBarrier);
  239 |     const before = await lease.snapshot();
  240 |     const entered = before.events.filter(
  241 |       (event) => event.kind === 'send-tool-entered' && event.toolUseId === tool,
  242 |     );
  243 |     const started = before.events.filter(
  244 |       (event) => event.kind === 'send-wait-started' && event.toolUseId === tool,
  245 |     );
  246 |     if (
  247 |       entered.length !== 1 ||
  248 |       started.length !== 1 ||
  249 |       typeof started[0]!.clientMsgId !== 'string' ||
  250 |       typeof entered[0]!.stepId !== 'string' ||
  251 |       typeof entered[0]!.clockDomain !== 'string' ||
  252 |       before.events.some(
  253 |         (event) => event.kind === 'send-tool-result-returned' && event.toolUseId === tool,
  254 |       )
  255 |     )
  256 |       throw new BlockedError('trigger已安装但未命中原真实send/保存前窗口');
  257 |     const clientMsgId = started[0]!.clientMsgId as string;
  258 |     const origin: ReadIdentity = {
  259 |       groupId: group.id,
  260 |       runId,
  261 |       toolUseId: tool,
  262 |       stepId: entered[0]!.stepId,
  263 |       attemptId: entered[0]!.attemptId,
  264 |       clientMsgId,
  265 |       clockDomain: entered[0]!.clockDomain,
  266 |     };
  267 |     const projection = async () => ({
  268 |       run: (
  269 |         await observer!.query(
  270 |           'SELECT id,history::jsonb AS history FROM public.agent_runs WHERE id=$1',
  271 |           [runId],
  272 |         )
  273 |       ).rows,
  274 |       step: (
  275 |         await observer!.query(
  276 |           'SELECT run_id,tool_use_id,ordinal,state,result FROM public.agent_steps WHERE run_id=$1 AND tool_use_id=$2',
  277 |           [runId, tool],
  278 |         )
  279 |       ).rows,
  280 |     });
  281 |     const baseline = await projection();
  282 |     if (
  283 |       baseline.run.length !== 1 ||
  284 |       baseline.step.length !== 1 ||
  285 |       baseline.step[0]!.result !== null
  286 |     )
  287 |       throw new BlockedError('原公开流程未形成唯一真实未完成step基线');
  288 |     evidence.original = origin;
  289 |     const publicBefore = await qa.api.agentRun(runId);
  290 |     evidence.before = { witness: before, baseline, publicRun: publicBefore };
  291 |     const effects = () => {
  292 |       const gateway = qa.gateway.snapshot();
  293 |       assert.equal(
  294 |         gateway.requests.filter(
  295 |           (request) => request.path === `/groups/${group.gatewayGroupId}/send`,
  296 |         ).length,
  297 |         1,
  298 |         '同一原发送出现重复实际send',
  299 |       );
> 300 |       assert.equal(
      |              ^ AssertionError: 原消息实际副作用未唯一落地
  301 |         gateway.messages.filter((message) => message.clientMsgId === clientMsgId).length,
  302 |         1,
  303 |         '原消息实际副作用未唯一落地',
  304 |       );
  305 |       assert.equal(qa.agent.snapshot().audits.length, 1, '同key重复审计');
  306 |     };
  307 |     check('original send and audit really happened once before local failure', effects);
  308 |     qa.gateway.barriers.release(sendBarrier);
  309 |     const failed = await observe({
  310 |       read: () => lease.snapshot(),
  311 |       invariant: () => check('finite failure observation side effects', effects),
  312 |       complete: (snapshot) =>
  313 |         snapshot.events.some(
  314 |           (event) =>
  315 |             String(event.kind) === 'send-tool-history-save-failed' &&
  316 |             event.attemptId === origin.attemptId,
  317 |         ),
  318 |       durationMs: 8000,
  319 |       intervalMs: 20,
  320 |     });
  321 |     if (!failed.complete) missing.push('未取得原真实history保存拒绝；QA8000ms观察不是业务SLA');
  322 |     check('original five-second success remains a separate strict check', () =>
  323 |       assertToolWaitBudget(toolWaitWindow(failed.last.events, tool, key), null),
  324 |     );
  325 |     check('actual original Agent UPDATE/P0001/outer ROLLBACK', () => {
  326 |       evidence.rollback = assertAgentSaveBoundary(failed.last.events, origin, 'rollback');
  327 |     });
  328 |     const rolledBack = await projection();
  329 |     check('real original step and history remain unchanged by failed transaction', () => {
  330 |       assert.deepEqual(rolledBack, baseline, '实际ROLLBACK后step/result/history出现部分保存');
  331 |     });
  332 |     const failedPublic = await qa.api.agentRun(runId);
  333 |     check('public history never advertises the failed step as saved', () => {
  334 |       const step = failedPublic.steps.filter((item) => item.toolUseId === tool);
  335 |       assert.equal(step.length, 1);
  336 |       const previous = publicBefore.steps.filter((item) => item.toolUseId === tool);
  337 |       if (previous.length !== 1) throw new BlockedError('原未保存step公开基线缺失');
  338 |       assert.equal(
  339 |         step[0]!.resultSummary,
  340 |         previous[0]!.resultSummary,
  341 |         '实际未提交step已对外显示保存结果',
  342 |       );
  343 |       assert.equal(step[0]!.isError, previous[0]!.isError);
  344 |       assert.equal(step[0]!.errorCode, previous[0]!.errorCode);
  345 |     });
  346 |     check('no later model turn precedes actual original history commit', () =>
  347 |       assert.equal(qa.agent.snapshot().turns.length, 1, '实际保存失败后仍请求下一模型turn'),
  348 |     );
  349 |     evidence.failed = {
  350 |       observation: failed,
  351 |       rolledBack,
  352 |       publicRun: failedPublic,
  353 |       gateway: qa.gateway.snapshot(),
  354 |       agent: qa.agent.snapshot(),
  355 |     };
  356 |     // End the failure capture before removing our fault. Restart retains all
  357 |     // existing remote/DB state, and the next execution is reported separately.
  358 |     await control.close();
  359 |     controls.shift();
  360 |     await qa.kill();
  361 |     await removeFault();
  362 |     await qa.start();
  363 |     const nextControl = runtimeObservationFor(qa);
  364 |     controls.push(nextControl);
  365 |     await nextControl.verify(['tool-wait-witness']);
  366 |     lease = await nextControl.arm('observe-tool-wait', {
  367 |       kind: 'tool-wait',
  368 |       groupId: group.id,
  369 |       runId,
  370 |       toolUseId: 'all-run-steps',
  371 |     });
  372 |     const resumed = await observe({
  373 |       read: () => lease.snapshot(),
  374 |       invariant: () => check('finite restart recovery side effects', effects),
  375 |       complete: (snapshot) =>
  376 |         snapshot.events.some(
  377 |           (event) => event.kind === 'send-tool-history-committed' && event.toolUseId === tool,
  378 |         ),
  379 |       durationMs: 12_000,
  380 |       intervalMs: 25,
  381 |     });
  382 |     if (!resumed.complete)
  383 |       missing.push('12秒QA恢复观察未取得原step真实COMMIT；不以新固定期限替代需求');
  384 |     check('same original key is reused in a distinct actual process attempt', () => {
  385 |       const window = toolWaitWindow(resumed.last.events, tool, key);
  386 |       assert.equal(window.clientMsgId, clientMsgId, '恢复同key变成另一消息身份');
  387 |       assert.equal(window.keyReused, true, '恢复未复用原持久key');
  388 |       assert.equal((window.result as { deliveryStatus?: unknown }).deliveryStatus, 'sent');
  389 |       assert.notEqual(window.attemptId, origin.attemptId, '重启执行被误当原保存事务');
  390 |       assert.notEqual(window.clockDomain, origin.clockDomain, '跨进程使用旧时钟域');
  391 |       assertToolWaitBudget(window, null);
  392 |       assertToolWaitCompletion(window);
  393 |       evidence.recoveryCommit = assertAgentSaveBoundary(
  394 |         resumed.last.events,
  395 |         {
  396 |           ...origin,
  397 |           stepId: window.stepId!,
  398 |           attemptId: window.attemptId,
  399 |           clockDomain: window.clockDomain as string,
  400 |         },
```