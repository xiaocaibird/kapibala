# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/delivery-read-causal-followup.spec.ts >> [INT-READ-CAUSAL-001] original locked read, real SQL rollback and actual Agent history commit remain independent of strict five seconds
- Location: tests/system/delivery-read-causal-followup.spec.ts:481:1

# Error details

```
AssertionError: 实际工具状态等待下界超过原始5000ms上限
```

# Test source

```ts
  267 |     if (
  268 |       event.kind.endsWith('-committed') ||
  269 |       event.kind === 'agent-run-created' ||
  270 |       event.kind === 'send-tool-prepared' ||
  271 |       event.kind === 'message-recovery-adopted'
  272 |     )
  273 |       need(event.commitBoundary === 'outer-commit-confirmed', '不能将提交尝试冒充已提交');
  274 |   }
  275 | }
  276 | 
  277 | const one = (events: readonly RuntimeEvent[], kind: string) => {
  278 |   const matches = events.filter((e) => e.kind === kind);
  279 |   need(matches.length === 1, `需要唯一真实${kind}，当前${matches.length}条`);
  280 |   return matches[0]!;
  281 | };
  282 | function completeHistory(events: readonly RuntimeEvent[]) {
  283 |   need(
  284 |     events[0]?.kind === 'lifecycle-observation-attached' && events[0].droppedThroughSourceSeq === 0,
  285 |     '进程历史已截断或不完整，不能证明完整生命周期',
  286 |   );
  287 | }
  288 | 
  289 | export function toolWaitWindow(events: readonly RuntimeEvent[], toolUseId: string, key: string) {
  290 |   const entered = one(
  291 |     events.filter((e) => e.toolUseId === toolUseId),
  292 |     'send-tool-entered',
  293 |   );
  294 |   const execution = events.filter((e) => e.attemptId === entered.attemptId);
  295 |   const startBefore = one(execution, 'send-key-resolved');
  296 |   const startAfter = one(execution, 'send-wait-started');
  297 |   const endBefore = one(execution, 'send-wait-result-ready');
  298 |   const endAfter = one(execution, 'send-tool-result-returned');
  299 |   const ordered = [entered, startBefore, startAfter, endBefore, endAfter];
  300 |   need(
  301 |     ordered.every(
  302 |       (e, i) =>
  303 |         e.stepId === entered.stepId &&
  304 |         e.toolUseId === toolUseId &&
  305 |         e.runId === entered.runId &&
  306 |         e.clockDomain === entered.clockDomain &&
  307 |         (!i || e.sourceSeq! > ordered[i - 1]!.sourceSeq!),
  308 |     ),
  309 |     '工具等待跨步骤/时钟/顺序',
  310 |   );
  311 |   need(
  312 |     [startBefore, startAfter, endBefore, endAfter].every(
  313 |       (e) => e.clientMsgId === startBefore.clientMsgId && e.idempotencyKey === key,
  314 |     ),
  315 |     '工具等待未关联同一真实消息和key',
  316 |   );
  317 |   const start: Interval = [
  318 |     observationInterval(startBefore.monotonicMs)[0],
  319 |     observationInterval(startAfter.monotonicMs)[1],
  320 |   ];
  321 |   const end: Interval = [
  322 |     observationInterval(endBefore.monotonicMs)[0],
  323 |     observationInterval(endAfter.monotonicMs)[1],
  324 |   ];
  325 |   return {
  326 |     start,
  327 |     end,
  328 |     elapsed: span(start, end),
  329 |     clientMsgId: startBefore.clientMsgId,
  330 |     attemptId: entered.attemptId,
  331 |     runId: entered.runId,
  332 |     stepId: entered.stepId,
  333 |     toolUseId,
  334 |     enteredSeq: entered.seq,
  335 |     clockDomain: entered.clockDomain,
  336 |     errorCode: endAfter.errorCode,
  337 |     readyErrorCode: endBefore.errorCode,
  338 |     keyReused: startBefore.keyReused,
  339 |     result: endAfter.result,
  340 |     returnedSeq: endAfter.seq,
  341 |     droppedThroughSourceSeq: events[0]?.droppedThroughSourceSeq,
  342 |     earlierStages: events.filter(
  343 |       (e) =>
  344 |         e.stepId === entered.stepId &&
  345 |         [
  346 |           'send-tool-prepared',
  347 |           'send-tool-entered',
  348 |           'send-audit-started',
  349 |           'send-audit-completed',
  350 |         ].includes(e.kind),
  351 |     ),
  352 |     history: execution.filter((e) => e.kind === 'send-tool-history-committed'),
  353 |     historyCandidates: events.filter(
  354 |       (e) =>
  355 |         e.stepId === entered.stepId &&
  356 |         e.toolUseId === toolUseId &&
  357 |         e.kind === 'send-tool-history-committed',
  358 |     ),
  359 |   };
  360 | }
  361 | export function assertToolWaitBudget(
  362 |   window: ReturnType<typeof toolWaitWindow>,
  363 |   expectedCode: string | null,
  364 | ) {
  365 |   assert.equal(window.errorCode, expectedCode, '实际工具交还结果错误');
  366 |   assert.equal(window.readyErrorCode, expectedCode, '状态等待结果与交还结果不一致');
> 367 |   assert.ok(window.elapsed[0] <= 5000, '实际工具状态等待下界超过原始5000ms上限');
      |          ^ AssertionError: 实际工具状态等待下界超过原始5000ms上限
  368 |   if (expectedCode === 'SEND_TIMEOUT')
  369 |     assert.ok(window.elapsed[1] >= 5000, '未满5秒且无结论却提前宣告SEND_TIMEOUT');
  370 |   if (window.elapsed[1] > 5000)
  371 |     throw new BlockedError('工具实际等待区间跨5000ms，不能用后续turn或计时容差补证');
  372 | }
  373 | 
  374 | /** Pair by the real execution attempt, never repair a missing host argument by
  375 |  * guessing from a matching toolUseId. Check hard timing violations first. */
  376 | export function assertToolWaitCompletion(window: ReturnType<typeof toolWaitWindow>) {
  377 |   need(window.droppedThroughSourceSeq === 0, '工具流此前历史被截断');
  378 |   const prepared = window.earlierStages.filter((e) => e.kind === 'send-tool-prepared');
  379 |   need(
  380 |     prepared.length === 1 &&
  381 |       prepared[0]!.runId === window.runId &&
  382 |       prepared[0]!.toolUseId === window.toolUseId &&
  383 |       prepared[0]!.stepId === window.stepId &&
  384 |       prepared[0]!.clockDomain === window.clockDomain &&
  385 |       prepared[0]!.seq < window.enteredSeq,
  386 |     '缺少真实合法工具持久化来源',
  387 |   );
  388 |   need(
  389 |     window.history.length === 1 &&
  390 |       window.historyCandidates.length === 1 &&
  391 |       window.history[0]!.seq === window.historyCandidates[0]!.seq &&
  392 |       window.history[0]!.sourceSeq === window.historyCandidates[0]!.sourceSeq &&
  393 |       window.history[0]!.attemptId === window.attemptId &&
  394 |       window.history[0]!.runId === window.runId &&
  395 |       window.history[0]!.stepId === window.stepId &&
  396 |       window.history[0]!.toolUseId === window.toolUseId &&
  397 |       window.history[0]!.seq > window.returnedSeq &&
  398 |       window.history[0]!.clockDomain === window.clockDomain,
  399 |     '缺少同一真实executionAttempt的history COMMIT，不能按toolUseId猜配',
  400 |   );
  401 |   assert.equal(window.history[0]!.errorCode, window.errorCode, '保存history的错误码与交还值不同');
  402 |   assert.deepEqual(window.history[0]!.result, window.result, '保存history的结果与交还值不同');
  403 | }
  404 | 
  405 | /** RuntimeLease has already validated real run/process/clock identities. This
  406 |  * order violation needs neither elapsed-time truth nor a later successful COMMIT. */
  407 | export function assertNoDispatchAfterStop(events: readonly RuntimeEvent[]): void {
  408 |   for (const decision of events.filter((event) => event.kind === 'agent-termination-decided'))
  409 |     assert.ok(
  410 |       !events.some(
  411 |         (event) =>
  412 |           event.kind === 'agent-turn-dispatched' &&
  413 |           event.runId === decision.runId &&
  414 |           event.groupId === decision.groupId &&
  415 |           event.applicationPid === decision.applicationPid &&
  416 |           event.clockDomain === decision.clockDomain &&
  417 |           event.seq > decision.seq,
  418 |       ),
  419 |       '实际终止决定之后不得派发新turn',
  420 |     );
  421 | }
  422 | 
  423 | export function assertAgentLifecycle(events: readonly RuntimeEvent[]) {
  424 |   assertNoDispatchAfterStop(events);
  425 |   const created = one(events, 'agent-run-created');
  426 |   const start = observationInterval(created.creationWindowMs);
  427 |   const decisions = events.filter((e) => e.kind === 'agent-termination-decided');
  428 |   // Evaluate every observed hard violation before missing completion/history.
  429 |   for (const event of [...decisions, ...events.filter((e) => e.kind === 'agent-turn-dispatched')]) {
  430 |     const end = observationInterval(
  431 |       event.kind === 'agent-termination-decided' ? event.decisionWindowMs : event.monotonicMs,
  432 |     );
  433 |     assert.ok(end[0] - start[1] <= 60_000, '真实决定或新turn派发已超过原始60000ms上限');
  434 |   }
  435 |   completeHistory(events);
  436 |   const terminal = one(events, 'agent-terminal-committed');
  437 |   const decision = one(
  438 |     decisions.filter((e) => e.attemptId === terminal.attemptId),
  439 |     'agent-termination-decided',
  440 |   );
  441 |   need(
  442 |     decision.seq < terminal.seq &&
  443 |       decision.status === terminal.status &&
  444 |       decision.reason === terminal.reason,
  445 |     '终止决定与实际COMMIT没有配对',
  446 |   );
  447 |   assert.equal(terminal.status, 'failed');
  448 |   assert.equal(terminal.reason, 'wall_clock');
  449 |   const elapsed = span(start, observationInterval(decision.decisionWindowMs));
  450 |   // The paired COMMIT proves durability but is not the stop-decision timestamp.
  451 |   // A5.2 imposes only the maximum; it does not require running until 60000ms.
  452 |   if (elapsed[1] > 60_000)
  453 |     throw new BlockedError('实际停止决定区间跨60000ms，不能用公开终态或提交时间补证');
  454 |   return {
  455 |     elapsed,
  456 |     created,
  457 |     decision,
  458 |     terminal,
  459 |     turns: events.filter((e) => e.kind === 'agent-turn-dispatched'),
  460 |   };
  461 | }
  462 | 
  463 | /** Diagnostic only: an automatic query is not a negative completion guarantee. */
  464 | export function messageRecoveryEvidence(events: readonly RuntimeEvent[]) {
  465 |   return {
  466 |     attached: events[0],
  467 |     dispatches: events.filter((e) => e.kind === 'message-send-dispatch'),
```