# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/dispatched-kick-observation-followup.spec.ts >> [INT-KICK-OBSERVATION-001] original active budget bounds an already dispatched kick with unresolved 504 confirmation
- Location: tests/system/dispatched-kick-observation-followup.spec.ts:39:1

# Error details

```
AssertionError: complete activity lower bound: 完整实际活动下界已超过60000ms
```

# Test source

```ts
  783 |     }
  784 |     ledgerChecks();
  785 |     if (primary instanceof assert.AssertionError) add(failures, primary.message);
  786 |     else if (primary instanceof BlockedError) add(missing, primary.message);
  787 |     await evidence('dispatched-kick-observation-final', {
  788 |       caseId: 'INT-KICK-OBSERVATION-001',
  789 |       kick,
  790 |       requiredMaximumMs: 60_000,
  791 |       diagnosticBudgetMs,
  792 |       stages,
  793 |       publicSamples,
  794 |       activitySamples,
  795 |       activity: activity?.latest,
  796 |       lifecycle: lifecycle?.latest,
  797 |       lifecycleVerdict,
  798 |       capacity: capacityLease?.latest,
  799 |       gateway: qa.gateway.snapshot(),
  800 |       agent: qa.agent.snapshot(),
  801 |       postId,
  802 |       confirmationId,
  803 |       postReleased,
  804 |       confirmationWindowEstablished,
  805 |       auditPassEstablished,
  806 |       windowClosedBeforeTerminal,
  807 |       decisionObservedWithPendingConfirmation,
  808 |       calibrations,
  809 |       mappedConfirmationBoundary,
  810 |       observationClaims,
  811 |       actualBudgetPendingProof,
  812 |       laterTerminalCrossDiagnostic,
  813 |       knownStrongRecoveryObservation,
  814 |       failures,
  815 |       missing,
  816 |       primary: primary ? String(primary) : null,
  817 |       coverage: {
  818 |         secondInstance: 'NOT_RUN',
  819 |         restartRecovery: 'NOT_RUN',
  820 |         arbitraryUnknownRecovery: 'NOT_RUN',
  821 |         cancellationCause: {
  822 |           result: observationClaims['KB-CANCEL actual source identity'] ?? {
  823 |             status: 'BLOCKED',
  824 |             reason: '真实原请求取消身份尚未建立',
  825 |           },
  826 |         },
  827 |         limit:
  828 |           '单实例实际活动/已派发kick/有限不重放组合；unknown仅如实记录。peer-close不自动证明abort原因，不替代A5.8强恢复，也不证明所有未来不重复。',
  829 |       },
  830 |     });
  831 |     // Stop only this QA-owned process if a response remains held. The final
  832 |     // product snapshot above is immutable; cleanup must not manufacture a
  833 |     // success by sending the previously unavailable members response.
  834 |     const pending =
  835 |       !!kick &&
  836 |       requests().some(
  837 |         (entry) =>
  838 |           entry.path.startsWith(`/groups/${kick!.group.gatewayGroupId}/`) &&
  839 |           !entry.responseFinishedAt &&
  840 |           !entry.responseClosedAt,
  841 |       );
  842 |     // Read-only observers can be released against the still-live owner. A held
  843 |     // admission gate is released only after stopping an unfinished owned run.
  844 |     try {
  845 |       await runtime?.close();
  846 |     } catch (error) {
  847 |       add(secondary, `runtime cleanup: ${String(error)}`);
  848 |     }
  849 |     if (capacityLease?.latest?.state === 'released') {
  850 |       try {
  851 |         await capacity?.close();
  852 |       } catch (error) {
  853 |         add(secondary, `capacity cleanup: ${String(error)}`);
  854 |       }
  855 |     }
  856 |     if (createdBefore && (pending || !run || run.status === 'running')) {
  857 |       try {
  858 |         await qa.kill();
  859 |       } catch (error) {
  860 |         add(secondary, `owned process stop: ${String(error)}`);
  861 |       }
  862 |     }
  863 |     qa.agent.barriers.release(kick?.auditBarrier ?? 'qa-audit-dispatched-original-budget');
  864 |     qa.gateway.barriers.release(postBarrier);
  865 |     qa.gateway.barriers.release(confirmationBarrier);
  866 |     if (capacityLease?.latest?.state !== 'released') {
  867 |       try {
  868 |         await capacity?.close();
  869 |       } catch (error) {
  870 |         add(secondary, `capacity cleanup: ${String(error)}`);
  871 |       }
  872 |     }
  873 |     await evidence('dispatched-kick-observation-cleanup', {
  874 |       at: new Date().toISOString(),
  875 |       pendingResponseBeforeCleanup: pending,
  876 |       secondary,
  877 |       failures,
  878 |       missing,
  879 |       gatewayAfterCleanup: qa.gateway.snapshot(),
  880 |       boundary: '清理后记录不回填测试期业务结果；仅释放本例屏障/租约及必要时停止自有SUT',
  881 |     });
  882 |   }
> 883 |   if (failures.length) assert.fail(failures.join('\n'));
      |                               ^ AssertionError: complete activity lower bound: 完整实际活动下界已超过60000ms
  884 |   if (primary && !(primary instanceof BlockedError)) throw primary;
  885 |   if (missing.length || secondary.length)
  886 |     throw new BlockedError([...missing, ...secondary].join('; '));
  887 | });
  888 | 
```