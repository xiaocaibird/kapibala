# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/protocol-boundaries.spec.ts >> [BLK-EXT-001] unacknowledged send has paired pending prefixes without a fabricated two-second bound
- Location: tests/system/protocol-boundaries.spec.ts:207:1

# Error details

```
BlockedError: [BLOCKED] No terminal evidence within observation budget for does-not-land. The 10s probe is not a product deadline or proof of permanent non-recovery; retain CL-01 protocol risk.
```

# Test source

```ts
  286 |             items.find((item) => item.clientMsgId === clientMsgId)!.deliveryStatus,
  287 |           );
  288 |           expect(
  289 |             qa.gateway.snapshot().requests.filter((entry) => entry.path === path),
  290 |           ).toHaveLength(1);
  291 |           expect(
  292 |             qa.gateway.snapshot().messages.filter((entry) => entry.clientMsgId === clientMsgId),
  293 |           ).toHaveLength(0);
  294 |         },
  295 |       });
  296 |       await evidence(qa, `${outcome}-indistinguishable-prefix`, prefix);
  297 |       qa.gateway.barriers.release(barrier);
  298 |       const observation = await observe({
  299 |         durationMs: 10_000,
  300 |         read: () => qa.api.messages(group.id),
  301 |         invariant: ({ items }) => {
  302 |           const local = items.filter((item) => item.clientMsgId === clientMsgId);
  303 |           const remote = qa.gateway
  304 |             .snapshot()
  305 |             .messages.filter((item) => item.clientMsgId === clientMsgId);
  306 |           // Releasing a QA barrier, or privately choosing effect:none, supplies
  307 |           // no new public non-delivery guarantee to the SUT. A late blind retry
  308 |           // must not pass merely because it became the only landed message.
  309 |           expect(
  310 |             qa.gateway.snapshot().requests.filter((entry) => entry.path === path),
  311 |           ).toHaveLength(1);
  312 |           expect(local).toHaveLength(1);
  313 |           expect(remote.length).toBeLessThanOrEqual(1);
  314 |           if (local[0]!.deliveryStatus === 'sent') {
  315 |             expect(remote).toHaveLength(1);
  316 |             expect(local[0]!.msgId).toBe(remote[0]!.msgId);
  317 |           }
  318 |           // There is no explicit failure/cancellation event in either branch.
  319 |           // A 404 plus a missing response cannot justify inventing a terminal
  320 |           // failure, even when the QA-only ledger has privately chosen no effect.
  321 |           expect(['failed', 'cancelled']).not.toContain(local[0]!.deliveryStatus);
  322 |         },
  323 |         complete: ({ items }) =>
  324 |           items.some(
  325 |             (item) =>
  326 |               item.clientMsgId === clientMsgId && ['sent', 'failed'].includes(item.deliveryStatus),
  327 |           ),
  328 |       });
  329 |       await evidence(qa, `${outcome}-outcome`, observation);
  330 |       if (!observation.complete) incomplete.push(outcome);
  331 |       const afterSnapshot =
  332 |         afterLease &&
  333 |         (await optionalActivityObservation(
  334 |           `${outcome} final recovered history`,
  335 |           () => afterLease!.snapshot(),
  336 |           missing,
  337 |         ));
  338 |       await qa.evidence(`${outcome}-recovery-lifecycle`, {
  339 |         before: beforeSnapshot ?? null,
  340 |         after: afterSnapshot ?? afterLease?.latest ?? null,
  341 |         missing,
  342 |       });
  343 |       await optionalActivityObservation(
  344 |         `${outcome} original/recovery association`,
  345 |         async () => {
  346 |           const association = assertMessageRecoveryAssociation(
  347 |             beforeSnapshot?.events ?? [],
  348 |             (afterSnapshot ?? afterLease?.latest)?.events ?? [],
  349 |           );
  350 |           await qa.evidence(`${outcome}-recovery-diagnosis`, association);
  351 |         },
  352 |         missing,
  353 |       );
  354 |       incomplete.push(...missing.map((message) => `${outcome}: ${message}`));
  355 |     } catch (error) {
  356 |       primaryFailure = true;
  357 |       throw error;
  358 |     } finally {
  359 |       qa.gateway.barriers.release(barrier);
  360 |       try {
  361 |         await evidence(qa, `${outcome}-final-ledger`);
  362 |       } catch (error) {
  363 |         if (!primaryFailure) {
  364 |           primaryFailure = true;
  365 |           throw error;
  366 |         }
  367 |       } finally {
  368 |         const cleanup = await Promise.allSettled(controls.map((control) => control.close()));
  369 |         const errors = cleanup.filter((result) => result.status === 'rejected');
  370 |         if (errors.length) {
  371 |           try {
  372 |             await qa.evidence(
  373 |               `${outcome}-recovery-cleanup-failure`,
  374 |               errors.map((entry) => String(entry.reason)),
  375 |             );
  376 |           } catch {
  377 |             /* Keep first failure. */
  378 |           }
  379 |           if (!primaryFailure)
  380 |             throw new BlockedError('本消息观测租约未全部确认释放，旧PID不可跟随新实例');
  381 |         }
  382 |       }
  383 |     }
  384 |   }
  385 |   if (incomplete.length)
> 386 |     throw new BlockedError(
      |           ^ BlockedError: [BLOCKED] No terminal evidence within observation budget for does-not-land. The 10s probe is not a product deadline or proof of permanent non-recovery; retain CL-01 protocol risk.
  387 |       `No terminal evidence within observation budget for ${incomplete.join(', ')}. ` +
  388 |         'The 10s probe is not a product deadline or proof of permanent non-recovery; retain CL-01 protocol risk.',
  389 |     );
  390 | });
  391 | 
  392 | test('[BLK-EXT-004] an already effective kick is not repeated against a rejoined target after restart', async ({
  393 |   qa,
  394 | }) => {
  395 |   await qa.api.login();
  396 |   const { group } = await qa.api.createGroup();
  397 |   const target = 'kick-rejoin-target';
  398 |   const path = `/groups/${group.gatewayGroupId}/kick`;
  399 |   qa.gateway.setMembership(group.gatewayGroupId, target, true);
  400 |   await enable(qa, group);
  401 |   qa.agent.enqueueTurns(
  402 |     tool('kick-before-rejoin', 'kick_user', {
  403 |       platform_user_id: target,
  404 |       reason: 'single authorized removal',
  405 |     }),
  406 |     final('resumed existing run'),
  407 |   );
  408 |   qa.gateway.enqueue(path, {
  409 |     effect: 'apply',
  410 |     barrier: { phase: 'after-effect', name: 'kick-before-rejoin' },
  411 |   });
  412 |   try {
  413 |     trigger(qa, group, 'remove once');
  414 |     await qa.gateway.barriers.waitFor('kick-before-rejoin');
  415 |     const id = await runId(qa, group);
  416 |     const original = qa.gateway.snapshot().requests.find((entry) => entry.path === path)!;
  417 |     expect(original.responseStatus).toBeUndefined();
  418 |     expect(
  419 |       qa.gateway
  420 |         .snapshot()
  421 |         .effects.filter((entry) => entry.kind === 'kick' && entry.groupId === group.gatewayGroupId),
  422 |     ).toHaveLength(1);
  423 |     await qa.kill();
  424 |     qa.gateway.barriers.release('kick-before-rejoin');
  425 |     // Finish the external operation and record its member_left event while the
  426 |     // SUT is down, then join again. Neither event is erased or reordered.
  427 |     await eventually(
  428 |       async () => qa.gateway.snapshot(),
  429 |       (snapshot) =>
  430 |         snapshot.requests.some((entry) => entry.id === original.id && entry.completedAt) &&
  431 |         snapshot.events.some(
  432 |           (entry) => entry.type === 'member_left' && entry.data.platformUserId === target,
  433 |         ),
  434 |     );
  435 |     qa.gateway.setMembership(group.gatewayGroupId, target, true);
  436 |     await evidence(qa, 'kick-applied-then-rejoined', { id });
  437 |     await qa.start();
  438 |     await qa.api.login();
  439 |     const result = await observe({
  440 |       durationMs: 20_000,
  441 |       read: () => qa.api.agentRun(id),
  442 |       complete: (run) => run.status !== 'running',
  443 |       invariant: (run) => {
  444 |         expect(run.id).toBe(id);
  445 |         expect(qa.gateway.snapshot().requests.filter((entry) => entry.path === path)).toHaveLength(
  446 |           1,
  447 |         );
  448 |         expect(
  449 |           qa.gateway
  450 |             .snapshot()
  451 |             .groups.find((item) => item.groupId === group.gatewayGroupId)!
  452 |             .members.some((item) => item.platformUserId === target),
  453 |         ).toBe(true);
  454 |         for (const step of run.steps.filter((step) => step.toolUseId === 'kick-before-rejoin'))
  455 |           expect(step.isError, 'already effective tool must not be recorded as failed').toBe(false);
  456 |       },
  457 |     });
  458 |     await evidence(qa, 'kick-rejoin-resumed', result);
  459 |     if (!result.complete)
  460 |       throw new BlockedError(
  461 |         'Restarted kick run remains open within 20s observation budget; no arbitrary recovery deadline asserted',
  462 |       );
  463 |     expect(result.last.status).toBe('finished');
  464 |     expect(result.last.endReason).toBe('final');
  465 |     expect(
  466 |       result.last.steps.filter((step) => step.toolUseId === 'kick-before-rejoin'),
  467 |     ).toHaveLength(1);
  468 |   } finally {
  469 |     qa.gateway.barriers.release('kick-before-rejoin');
  470 |     await evidence(qa, 'kick-rejoin-final-ledger');
  471 |   }
  472 | });
  473 | 
  474 | type TurnBody = {
  475 |   runId: string;
  476 |   messages: {
  477 |     role: string;
  478 |     content: { type: string; tool_use_id?: string; [key: string]: unknown }[];
  479 |   }[];
  480 | };
  481 | 
  482 | test('[BLK-EXT-005] a lost unexecuted model response may change while persisted history and effects survive', async ({
  483 |   qa,
  484 | }) => {
  485 |   await qa.api.login();
  486 |   const { group } = await qa.api.createGroup();
```