# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/agent.spec.ts >> [AGENT-025] run reaches sixty-second active wall-clock budget including slow turns
- Location: tests/system/agent.spec.ts:787:1

# Error details

```
AssertionError: 活动预算已证明超过原始60秒上限
```

# Test source

```ts
  1  | import assert from 'node:assert/strict';
  2  | import { BlockedError } from '../../harness/security.js';
  3  | import {
  4  |   assertActivityBudget,
  5  |   assertNoRecoveryPause,
  6  |   type RuntimeEvent,
  7  | } from '../../harness/runtime-observation.js';
  8  | 
  9  | /** Missing observation cannot prevent the caller checking public behavior.
  10 |  * Only evidence-unavailable errors are deferred; real assertion failures survive. */
  11 | export async function optionalActivityObservation<T>(
  12 |   stage: string,
  13 |   read: () => Promise<T>,
  14 |   missing: string[],
  15 | ): Promise<T | undefined> {
  16 |   try {
  17 |     return await read();
  18 |   } catch (error) {
  19 |     if (!(error instanceof BlockedError)) throw error;
  20 |     missing.push(`${stage}: ${error.message}`);
  21 |     return undefined;
  22 |   }
  23 | }
  24 | 
  25 | /** Input events already passed RuntimeLease's owner, run and append-only checks.
  26 |  * This no-restart scenario requires true whole-run, single-epoch observation. */
  27 | export function assertSingleEpochActivityBudget(
  28 |   events: readonly RuntimeEvent[],
  29 |   online: [number, number],
  30 |   endReason: string,
  31 | ): void {
  32 |   assertNoRecoveryPause(events);
  33 |   if (!online.every((value) => Number.isFinite(value) && value >= 0) || online[0] > online[1])
  34 |     throw new BlockedError('独立在线区间无效');
  35 |   // A missing terminal or an incomplete later sample cannot hide an already
  36 |   // proved violation. Online time supplies an upper bound, never activity truth.
  37 |   for (const event of events) {
  38 |     if (!event.includesUnsavedTail || !event.activeElapsedMs) continue;
  39 |     assert.ok(event.activeElapsedMs[0] <= online[1], '活动下界超过独立在线上界，证据矛盾');
> 40 |     assert.ok(event.activeElapsedMs[0] <= 60_000, '活动预算已证明超过原始60秒上限');
     |            ^ AssertionError: 活动预算已证明超过原始60秒上限
  41 |   }
  42 |   if (endReason === 'wall_clock')
  43 |     assert.ok(online[1] >= 60_000, '独立在线上界尚不足60秒却已提前宣告wall_clock');
  44 |   const terminal = events.findLast((event) => event.kind === 'activity-terminal');
  45 |   if (!terminal) throw new BlockedError('缺少真实活动终止边界，REST轮询区间不替代活动见证');
  46 |   const epochs = new Set(events.flatMap((event) => event.epochIds ?? []));
  47 |   if (epochs.size !== 1 || terminal.epochIds?.length !== 1)
  48 |     throw new BlockedError('本例缺少完整单epoch创建至终止关联；不推算遗漏或多个所有权段');
  49 |   assertActivityBudget(terminal, online, 60_000, endReason);
  50 | }
  51 | 
```