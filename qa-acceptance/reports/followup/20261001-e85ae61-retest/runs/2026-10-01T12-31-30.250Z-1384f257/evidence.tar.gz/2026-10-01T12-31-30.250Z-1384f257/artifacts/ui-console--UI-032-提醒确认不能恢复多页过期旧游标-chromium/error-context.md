# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui/console.spec.ts >> [UI-032] 提醒确认不能恢复多页过期旧游标
- Location: tests/ui/console.spec.ts:1402:1

# Error details

```
BlockedError: [BLOCKED] 需要唯一可见且可用、独立于整体刷新且只确认已呈现相关变化的公开操作；不可用入口不能伪造或强制点击（匹配0，可见null，可用null）
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - link "K kapibala ." [ref=e5] [cursor=pointer]:
      - /url: "#/groups"
      - generic [ref=e6]: K
      - text: kapibala
      - generic [ref=e7]: .
    - generic [ref=e8]: 工作空间
    - navigation [ref=e9]:
      - link "群组工作台" [ref=e10] [cursor=pointer]:
        - /url: "#/groups"
      - link "服务账号" [ref=e15] [cursor=pointer]:
        - /url: "#/accounts"
      - link "Agent 运行" [ref=e20] [cursor=pointer]:
        - /url: "#/agent-runs"
      - link "定时序列" [ref=e24] [cursor=pointer]:
        - /url: "#/sequences"
    - generic [ref=e31]:
      - generic [ref=e39]:
        - strong [ref=e40]: 消息运营平台
        - generic [ref=e41]: 本地工作空间
      - generic [ref=e42]:
        - generic [ref=e43]: A
        - generic [ref=e44]:
          - strong [ref=e45]: admin
          - generic [ref=e46]: 管理员
        - button "退出登录" [ref=e47] [cursor=pointer]
  - generic [ref=e50]:
    - generic [ref=e51]:
      - generic [ref=e52]:
        - text: 工作空间
        - generic [ref=e53]: /
        - strong [ref=e54]: 群组工作台
      - status [ref=e56]: 连接恢复中
    - main [ref=e58]:
      - generic [ref=e59]: 实时连接已断开，正在自动重连并补齐期间的变化。
      - generic [ref=e60]:
        - generic [ref=e61]:
          - generic [ref=e62]: GROUP WORKSPACE
          - heading "群组工作台" [level=1] [ref=e63]
          - paragraph [ref=e64]: 按创建时间浏览群组，或搜索名称、简介和群 ID。
        - button "创建群组" [ref=e66] [cursor=pointer]
      - region "群列表查找、筛选与排序" [ref=e69]:
        - generic [ref=e70]:
          - text: 搜索群组
          - searchbox "搜索群组" [ref=e71]
        - button "清除搜索" [disabled] [ref=e72]
        - generic [ref=e73]:
          - text: 群状态
          - combobox "群状态" [ref=e74]:
            - option "全部" [selected]
            - option "可用"
            - option "不可写"
            - option "已退出"
        - generic [ref=e75]:
          - text: Agent 自动应答
          - combobox "Agent 自动应答" [ref=e76]:
            - option "全部" [selected]
            - option "开启"
            - option "关闭"
        - generic [ref=e77]:
          - text: 创建时间
          - combobox "创建时间" [ref=e78]:
            - option "新到旧" [selected]
            - option "旧到新"
        - button "重置条件" [disabled] [ref=e79]
        - button "刷新列表" [ref=e80] [cursor=pointer]
        - paragraph [ref=e83]: 搜索与筛选完整群目录；关键词忽略首尾空白与英文大小写，按整段匹配。
      - status [ref=e84]:
        - generic [ref=e85]: 当前群目录可能有变化；刷新后确认当前范围。
        - button "刷新并查看更新" [ref=e86] [cursor=pointer]
      - generic [ref=e87]:
        - heading "所有群组" [level=2] [ref=e88]
        - generic [ref=e89]: 已加载 23 个群 · 列表待刷新
      - generic [ref=e90]:
        - link "可用 游标提醒-22 网关 ID · gateway-group-23 创建于 2026/10/01 20:32:03 3 位成员 Agent 未开启 查看群组详情" [ref=e91] [cursor=pointer]:
          - /url: "#/groups/37d8bc5f-d45a-408c-a86f-2920b5865e81"
          - generic [ref=e92]: 可用
          - heading "游标提醒-22" [level=3] [ref=e98]
          - generic "gateway-group-23" [ref=e99]: 网关 ID · gateway-group-23
          - generic [ref=e100]:
            - text: 创建于
            - time [ref=e101]: 2026/10/01 20:32:03
          - generic [ref=e102]:
            - generic [ref=e103]: 3 位成员
            - generic [ref=e107]: Agent 未开启
          - generic [ref=e109]: 查看群组详情
        - link "可用 游标提醒-21 网关 ID · gateway-group-22 创建于 2026/10/01 20:32:02 3 位成员 Agent 未开启 查看群组详情" [ref=e113] [cursor=pointer]:
          - /url: "#/groups/06912b45-9a91-47c0-a8f9-4d1dda15319d"
          - generic [ref=e114]: 可用
          - heading "游标提醒-21" [level=3] [ref=e120]
          - generic "gateway-group-22" [ref=e121]: 网关 ID · gateway-group-22
          - generic [ref=e122]:
            - text: 创建于
            - time [ref=e123]: 2026/10/01 20:32:02
          - generic [ref=e124]:
            - generic [ref=e125]: 3 位成员
            - generic [ref=e129]: Agent 未开启
          - generic [ref=e131]: 查看群组详情
        - link "可用 游标提醒-20 网关 ID · gateway-group-21 创建于 2026/10/01 20:32:01 3 位成员 Agent 未开启 查看群组详情" [ref=e135] [cursor=pointer]:
          - /url: "#/groups/80b8b404-e3da-4116-99ed-009265a5f6bc"
          - generic [ref=e136]: 可用
          - heading "游标提醒-20" [level=3] [ref=e142]
          - generic "gateway-group-21" [ref=e143]: 网关 ID · gateway-group-21
          - generic [ref=e144]:
            - text: 创建于
            - time [ref=e145]: 2026/10/01 20:32:01
          - generic [ref=e146]:
            - generic [ref=e147]: 3 位成员
            - generic [ref=e151]: Agent 未开启
          - generic [ref=e153]: 查看群组详情
        - link "可用 游标提醒-19 网关 ID · gateway-group-20 创建于 2026/10/01 20:32:00 3 位成员 Agent 未开启 查看群组详情" [ref=e157] [cursor=pointer]:
          - /url: "#/groups/9d95d5c9-3b06-4a3e-878b-a3b7589c0db1"
          - generic [ref=e158]: 可用
          - heading "游标提醒-19" [level=3] [ref=e164]
          - generic "gateway-group-20" [ref=e165]: 网关 ID · gateway-group-20
          - generic [ref=e166]:
            - text: 创建于
            - time [ref=e167]: 2026/10/01 20:32:00
          - generic [ref=e168]:
            - generic [ref=e169]: 3 位成员
            - generic [ref=e173]: Agent 未开启
          - generic [ref=e175]: 查看群组详情
        - link "可用 游标提醒-18 网关 ID · gateway-group-19 创建于 2026/10/01 20:32:00 3 位成员 Agent 未开启 查看群组详情" [ref=e179] [cursor=pointer]:
          - /url: "#/groups/b14c45c2-a2cb-4bc5-8d66-82a150c04bcd"
          - generic [ref=e180]: 可用
          - heading "游标提醒-18" [level=3] [ref=e186]
          - generic "gateway-group-19" [ref=e187]: 网关 ID · gateway-group-19
          - generic [ref=e188]:
            - text: 创建于
            - time [ref=e189]: 2026/10/01 20:32:00
          - generic [ref=e190]:
            - generic [ref=e191]: 3 位成员
            - generic [ref=e195]: Agent 未开启
          - generic [ref=e197]: 查看群组详情
        - link "可用 游标提醒-17 网关 ID · gateway-group-18 创建于 2026/10/01 20:31:59 3 位成员 Agent 未开启 查看群组详情" [ref=e201] [cursor=pointer]:
          - /url: "#/groups/89d26b10-ba6d-4e5a-8e68-935014214325"
          - generic [ref=e202]: 可用
          - heading "游标提醒-17" [level=3] [ref=e208]
          - generic "gateway-group-18" [ref=e209]: 网关 ID · gateway-group-18
          - generic [ref=e210]:
            - text: 创建于
            - time [ref=e211]: 2026/10/01 20:31:59
          - generic [ref=e212]:
            - generic [ref=e213]: 3 位成员
            - generic [ref=e217]: Agent 未开启
          - generic [ref=e219]: 查看群组详情
        - link "可用 游标提醒-16 网关 ID · gateway-group-17 创建于 2026/10/01 20:31:58 3 位成员 Agent 未开启 查看群组详情" [ref=e223] [cursor=pointer]:
          - /url: "#/groups/984d827f-e054-4054-a361-7334c92dcfa0"
          - generic [ref=e224]: 可用
          - heading "游标提醒-16" [level=3] [ref=e230]
          - generic "gateway-group-17" [ref=e231]: 网关 ID · gateway-group-17
          - generic [ref=e232]:
            - text: 创建于
            - time [ref=e233]: 2026/10/01 20:31:58
          - generic [ref=e234]:
            - generic [ref=e235]: 3 位成员
            - generic [ref=e239]: Agent 未开启
          - generic [ref=e241]: 查看群组详情
        - link "可用 游标提醒-15 网关 ID · gateway-group-16 创建于 2026/10/01 20:31:57 3 位成员 Agent 未开启 查看群组详情" [ref=e245] [cursor=pointer]:
          - /url: "#/groups/c10fc820-6440-4bed-9c1d-15fa956a032c"
          - generic [ref=e246]: 可用
          - heading "游标提醒-15" [level=3] [ref=e252]
          - generic "gateway-group-16" [ref=e253]: 网关 ID · gateway-group-16
          - generic [ref=e254]:
            - text: 创建于
            - time [ref=e255]: 2026/10/01 20:31:57
          - generic [ref=e256]:
            - generic [ref=e257]: 3 位成员
            - generic [ref=e261]: Agent 未开启
          - generic [ref=e263]: 查看群组详情
        - link "可用 游标提醒-14 网关 ID · gateway-group-15 创建于 2026/10/01 20:31:56 3 位成员 Agent 未开启 查看群组详情" [ref=e267] [cursor=pointer]:
          - /url: "#/groups/53587119-236d-4a8b-b342-bbaabf359e86"
          - generic [ref=e268]: 可用
          - heading "游标提醒-14" [level=3] [ref=e274]
          - generic "gateway-group-15" [ref=e275]: 网关 ID · gateway-group-15
          - generic [ref=e276]:
            - text: 创建于
            - time [ref=e277]: 2026/10/01 20:31:56
          - generic [ref=e278]:
            - generic [ref=e279]: 3 位成员
            - generic [ref=e283]: Agent 未开启
          - generic [ref=e285]: 查看群组详情
        - link "可用 游标提醒-13 网关 ID · gateway-group-14 创建于 2026/10/01 20:31:55 3 位成员 Agent 未开启 查看群组详情" [ref=e289] [cursor=pointer]:
          - /url: "#/groups/0a61a1f5-5977-4c13-8300-0e71972e8826"
          - generic [ref=e290]: 可用
          - heading "游标提醒-13" [level=3] [ref=e296]
          - generic "gateway-group-14" [ref=e297]: 网关 ID · gateway-group-14
          - generic [ref=e298]:
            - text: 创建于
            - time [ref=e299]: 2026/10/01 20:31:55
          - generic [ref=e300]:
            - generic [ref=e301]: 3 位成员
            - generic [ref=e305]: Agent 未开启
          - generic [ref=e307]: 查看群组详情
        - link "可用 游标提醒-12 网关 ID · gateway-group-13 创建于 2026/10/01 20:31:54 3 位成员 Agent 未开启 查看群组详情" [ref=e311] [cursor=pointer]:
          - /url: "#/groups/aa216c06-f515-4d3b-8198-b7d56a69505a"
          - generic [ref=e312]: 可用
          - heading "游标提醒-12" [level=3] [ref=e318]
          - generic "gateway-group-13" [ref=e319]: 网关 ID · gateway-group-13
          - generic [ref=e320]:
            - text: 创建于
            - time [ref=e321]: 2026/10/01 20:31:54
          - generic [ref=e322]:
            - generic [ref=e323]: 3 位成员
            - generic [ref=e327]: Agent 未开启
          - generic [ref=e329]: 查看群组详情
        - link "可用 游标提醒-11 网关 ID · gateway-group-12 创建于 2026/10/01 20:31:53 3 位成员 Agent 未开启 查看群组详情" [ref=e333] [cursor=pointer]:
          - /url: "#/groups/e3ab07f7-68a8-4856-b3d0-65264bdc50f3"
          - generic [ref=e334]: 可用
          - heading "游标提醒-11" [level=3] [ref=e340]
          - generic "gateway-group-12" [ref=e341]: 网关 ID · gateway-group-12
          - generic [ref=e342]:
            - text: 创建于
            - time [ref=e343]: 2026/10/01 20:31:53
          - generic [ref=e344]:
            - generic [ref=e345]: 3 位成员
            - generic [ref=e349]: Agent 未开启
          - generic [ref=e351]: 查看群组详情
        - link "可用 游标提醒-10 网关 ID · gateway-group-11 创建于 2026/10/01 20:31:52 3 位成员 Agent 未开启 查看群组详情" [ref=e355] [cursor=pointer]:
          - /url: "#/groups/e957151f-e7e7-4e4c-b397-c7443d9fb5aa"
          - generic [ref=e356]: 可用
          - heading "游标提醒-10" [level=3] [ref=e362]
          - generic "gateway-group-11" [ref=e363]: 网关 ID · gateway-group-11
          - generic [ref=e364]:
            - text: 创建于
            - time [ref=e365]: 2026/10/01 20:31:52
          - generic [ref=e366]:
            - generic [ref=e367]: 3 位成员
            - generic [ref=e371]: Agent 未开启
          - generic [ref=e373]: 查看群组详情
        - link "可用 游标提醒-9 网关 ID · gateway-group-10 创建于 2026/10/01 20:31:51 3 位成员 Agent 未开启 查看群组详情" [ref=e377] [cursor=pointer]:
          - /url: "#/groups/16b3a7bf-cfc1-4ae5-9205-af60a3959639"
          - generic [ref=e378]: 可用
          - heading "游标提醒-9" [level=3] [ref=e384]
          - generic "gateway-group-10" [ref=e385]: 网关 ID · gateway-group-10
          - generic [ref=e386]:
            - text: 创建于
            - time [ref=e387]: 2026/10/01 20:31:51
          - generic [ref=e388]:
            - generic [ref=e389]: 3 位成员
            - generic [ref=e393]: Agent 未开启
          - generic [ref=e395]: 查看群组详情
        - link "可用 游标提醒-8 网关 ID · gateway-group-9 创建于 2026/10/01 20:31:50 3 位成员 Agent 未开启 查看群组详情" [ref=e399] [cursor=pointer]:
          - /url: "#/groups/7847adfb-2422-4cae-a4a1-568f3d691326"
          - generic [ref=e400]: 可用
          - heading "游标提醒-8" [level=3] [ref=e406]
          - generic "gateway-group-9" [ref=e407]: 网关 ID · gateway-group-9
          - generic [ref=e408]:
            - text: 创建于
            - time [ref=e409]: 2026/10/01 20:31:50
          - generic [ref=e410]:
            - generic [ref=e411]: 3 位成员
            - generic [ref=e415]: Agent 未开启
          - generic [ref=e417]: 查看群组详情
        - link "可用 游标提醒-7 网关 ID · gateway-group-8 创建于 2026/10/01 20:31:49 3 位成员 Agent 未开启 查看群组详情" [ref=e421] [cursor=pointer]:
          - /url: "#/groups/2eb97b0b-b7d6-4e37-8d63-f771a0348fca"
          - generic [ref=e422]: 可用
          - heading "游标提醒-7" [level=3] [ref=e428]
          - generic "gateway-group-8" [ref=e429]: 网关 ID · gateway-group-8
          - generic [ref=e430]:
            - text: 创建于
            - time [ref=e431]: 2026/10/01 20:31:49
          - generic [ref=e432]:
            - generic [ref=e433]: 3 位成员
            - generic [ref=e437]: Agent 未开启
          - generic [ref=e439]: 查看群组详情
        - link "可用 游标提醒-6 网关 ID · gateway-group-7 创建于 2026/10/01 20:31:48 3 位成员 Agent 未开启 查看群组详情" [ref=e443] [cursor=pointer]:
          - /url: "#/groups/25c8da08-39fd-482a-a9fd-285cad96a81c"
          - generic [ref=e444]: 可用
          - heading "游标提醒-6" [level=3] [ref=e450]
          - generic "gateway-group-7" [ref=e451]: 网关 ID · gateway-group-7
          - generic [ref=e452]:
            - text: 创建于
            - time [ref=e453]: 2026/10/01 20:31:48
          - generic [ref=e454]:
            - generic [ref=e455]: 3 位成员
            - generic [ref=e459]: Agent 未开启
          - generic [ref=e461]: 查看群组详情
        - link "可用 游标提醒-5 网关 ID · gateway-group-6 创建于 2026/10/01 20:31:48 3 位成员 Agent 未开启 查看群组详情" [ref=e465] [cursor=pointer]:
          - /url: "#/groups/09c44fe8-1765-4498-b62e-02062e4b1ac5"
          - generic [ref=e466]: 可用
          - heading "游标提醒-5" [level=3] [ref=e472]
          - generic "gateway-group-6" [ref=e473]: 网关 ID · gateway-group-6
          - generic [ref=e474]:
            - text: 创建于
            - time [ref=e475]: 2026/10/01 20:31:48
          - generic [ref=e476]:
            - generic [ref=e477]: 3 位成员
            - generic [ref=e481]: Agent 未开启
          - generic [ref=e483]: 查看群组详情
        - link "可用 游标提醒-4 网关 ID · gateway-group-5 创建于 2026/10/01 20:31:47 3 位成员 Agent 未开启 查看群组详情" [ref=e487] [cursor=pointer]:
          - /url: "#/groups/5261373f-44f2-4b74-b032-7d2e2f83e94a"
          - generic [ref=e488]: 可用
          - heading "游标提醒-4" [level=3] [ref=e494]
          - generic "gateway-group-5" [ref=e495]: 网关 ID · gateway-group-5
          - generic [ref=e496]:
            - text: 创建于
            - time [ref=e497]: 2026/10/01 20:31:47
          - generic [ref=e498]:
            - generic [ref=e499]: 3 位成员
            - generic [ref=e503]: Agent 未开启
          - generic [ref=e505]: 查看群组详情
        - link "可用 游标提醒-3 网关 ID · gateway-group-4 创建于 2026/10/01 20:31:46 3 位成员 Agent 未开启 查看群组详情" [ref=e509] [cursor=pointer]:
          - /url: "#/groups/ba1afa8a-ec60-4694-999a-37adcaaa7118"
          - generic [ref=e510]: 可用
          - heading "游标提醒-3" [level=3] [ref=e516]
          - generic "gateway-group-4" [ref=e517]: 网关 ID · gateway-group-4
          - generic [ref=e518]:
            - text: 创建于
            - time [ref=e519]: 2026/10/01 20:31:46
          - generic [ref=e520]:
            - generic [ref=e521]: 3 位成员
            - generic [ref=e525]: Agent 未开启
          - generic [ref=e527]: 查看群组详情
        - link "可用 游标提醒-2 网关 ID · gateway-group-3 创建于 2026/10/01 20:31:45 3 位成员 Agent 未开启 查看群组详情" [ref=e531] [cursor=pointer]:
          - /url: "#/groups/bb4d5789-c409-452b-8a3c-7897e734ab82"
          - generic [ref=e532]: 可用
          - heading "游标提醒-2" [level=3] [ref=e538]
          - generic "gateway-group-3" [ref=e539]: 网关 ID · gateway-group-3
          - generic [ref=e540]:
            - text: 创建于
            - time [ref=e541]: 2026/10/01 20:31:45
          - generic [ref=e542]:
            - generic [ref=e543]: 3 位成员
            - generic [ref=e547]: Agent 未开启
          - generic [ref=e549]: 查看群组详情
        - link "可用 游标提醒-1 网关 ID · gateway-group-2 创建于 2026/10/01 20:31:44 3 位成员 Agent 未开启 查看群组详情" [ref=e553] [cursor=pointer]:
          - /url: "#/groups/3500d305-496e-49ce-ad2f-7d3f2bed93bd"
          - generic [ref=e554]: 可用
          - heading "游标提醒-1" [level=3] [ref=e560]
          - generic "gateway-group-2" [ref=e561]: 网关 ID · gateway-group-2
          - generic [ref=e562]:
            - text: 创建于
            - time [ref=e563]: 2026/10/01 20:31:44
          - generic [ref=e564]:
            - generic [ref=e565]: 3 位成员
            - generic [ref=e569]: Agent 未开启
          - generic [ref=e571]: 查看群组详情
        - link "可用 游标提醒-0 网关 ID · gateway-group-1 创建于 2026/10/01 20:31:43 3 位成员 Agent 未开启 查看群组详情" [ref=e575] [cursor=pointer]:
          - /url: "#/groups/b681af37-1d3f-457b-a2d4-c23db92e8f3e"
          - generic [ref=e576]: 可用
          - heading "游标提醒-0" [level=3] [ref=e582]
          - generic "gateway-group-1" [ref=e583]: 网关 ID · gateway-group-1
          - generic [ref=e584]:
            - text: 创建于
            - time [ref=e585]: 2026/10/01 20:31:43
          - generic [ref=e586]:
            - generic [ref=e587]: 3 位成员
            - generic [ref=e591]: Agent 未开启
          - generic [ref=e593]: 查看群组详情
      - generic [ref=e597]:
        - generic [ref=e598]: Kapibala Console
        - generic [ref=e599]: 状态有记录，执行可追踪。
```

# Test source

```ts
  1  | import type { Locator } from '@playwright/test';
  2  | import { BlockedError } from '../../harness/security.js';
  3  | 
  4  | export interface PublicActionPremise {
  5  |   count: number;
  6  |   visible: boolean | null;
  7  |   enabled: boolean | null;
  8  | }
  9  | /** Read-only admission check. It never clicks, forces a disabled control, or treats
  10 |  * a missing/ambiguous public entry as an observed product assertion failure. */
  11 | export async function requireAvailablePublicAction(
  12 |   locator: Pick<Locator, 'count' | 'isVisible' | 'isEnabled'>,
  13 |   reason: string,
  14 |   observe: (sample: PublicActionPremise) => void,
  15 | ): Promise<void> {
  16 |   const count = await locator.count();
  17 |   const sample: PublicActionPremise = {
  18 |     count,
  19 |     visible: count === 1 ? await locator.isVisible() : null,
  20 |     enabled: count === 1 ? await locator.isEnabled() : null,
  21 |   };
  22 |   observe(sample);
  23 |   if (count !== 1 || !sample.visible || !sample.enabled)
> 24 |     throw new BlockedError(
     |           ^ BlockedError: [BLOCKED] 需要唯一可见且可用、独立于整体刷新且只确认已呈现相关变化的公开操作；不可用入口不能伪造或强制点击（匹配0，可见null，可用null）
  25 |       `${reason}（匹配${count}，可见${sample.visible}，可用${sample.enabled}）`,
  26 |     );
  27 | }
  28 | 
```