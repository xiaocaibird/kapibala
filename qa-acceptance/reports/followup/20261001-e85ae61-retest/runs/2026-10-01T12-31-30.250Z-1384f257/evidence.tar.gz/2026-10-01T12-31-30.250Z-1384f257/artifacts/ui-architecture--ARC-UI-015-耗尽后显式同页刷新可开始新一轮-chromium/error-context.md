# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui/architecture.spec.ts >> [ARC-UI-015] 耗尽后显式同页刷新可开始新一轮
- Location: tests/ui/architecture.spec.ts:559:1

# Error details

```
BlockedError: [BLOCKED] 动作窗口出现document/URL/主frame导航/WS连接或scope_ready变化，不能把范围重建当作原页面确认或恢复
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - link "K kapibala ." [ref=e5] [cursor=pointer]:
      - /url: "#/groups"
      - generic [ref=e6]: K
      - text: kapibala
      - generic [ref=e7]: .
    - generic [ref=e8]: 工作空间
    - navigation [ref=e9]:
      - link "群组工作台" [ref=e10] [cursor=pointer]:
        - /url: "#/groups"
      - link "服务账号" [ref=e14] [cursor=pointer]:
        - /url: "#/accounts"
      - link "Agent 运行" [ref=e19] [cursor=pointer]:
        - /url: "#/agent-runs"
      - link "定时序列" [ref=e23] [cursor=pointer]:
        - /url: "#/sequences"
    - generic [ref=e31]:
      - generic [ref=e39]:
        - strong [ref=e40]: 消息运营平台
        - generic [ref=e41]: 本地工作空间
      - generic [ref=e42]:
        - generic [ref=e43]: A
        - generic [ref=e44]:
          - strong [ref=e45]: admin
          - generic [ref=e46]: 管理员
        - button "退出登录" [ref=e47] [cursor=pointer]
  - generic [ref=e50]:
    - generic [ref=e51]:
      - generic [ref=e52]:
        - text: 工作空间
        - generic [ref=e53]: /
        - strong [ref=e54]: 定时序列
      - status [ref=e56]: 连接恢复中
    - main [ref=e58]:
      - generic [ref=e59]: 实时连接已断开，正在自动重连并补齐期间的变化。
      - generic [ref=e60]:
        - generic [ref=e61]:
          - generic [ref=e62]: SCHEDULED MESSAGING
          - heading "定时序列" [level=1] [ref=e63]
          - paragraph [ref=e64]: 预检每一步的消息与变量来源，再有序发送到群组。
        - button "新建序列" [ref=e66] [cursor=pointer]
      - generic [ref=e70]:
        - paragraph [ref=e71]: 当前群组：未选择 · 状态：—
        - paragraph [ref=e72]: 当前展示运行：尚无运行
      - generic [ref=e73]:
        - generic [ref=e74]:
          - generic [ref=e75]:
            - heading "运行配置" [level=2] [ref=e76]
            - generic [ref=e77]: 先预检 · 后执行
          - generic [ref=e78]:
            - generic [ref=e79]:
              - text: 目标群组
              - combobox "目标群组" [ref=e80]:
                - option "请选择群组" [disabled] [selected]
            - generic [ref=e81]:
              - text: 消息序列
              - combobox "消息序列" [ref=e82]:
                - option "请选择序列" [disabled]
                - option "QA恢复目标 · 1 步" [selected]
            - generic [ref=e86]:
              - generic [ref=e87]: "1"
              - generic [ref=e88]:
                - strong [ref=e89]: "{event_1}"
                - generic [ref=e90]: 管理员 / 群主 · 延迟 0 秒
            - generic [ref=e91]:
              - text: 默认变量
              - code [ref=e92]: vars
              - textbox "默认变量 vars" [ref=e93]: "{}"
            - paragraph [ref=e94]: JSON 键值对象。需要的占位符：event_1。空字符串视为未提供。
            - generic [ref=e95]:
              - text: 分步变量
              - code [ref=e96]: stepVars
              - textbox "分步变量 stepVars" [ref=e97]: "{}"
            - paragraph [ref=e98]:
              - text: 例如
              - code [ref=e99]: "{\"2\":{\"location\":\"共享盘\"}}"
              - text: 。从该步起沿用新值；空字符串保留原值。
            - button "预检所有步骤" [disabled] [ref=e100]
        - generic [ref=e103]:
          - generic [ref=e105]:
            - strong [ref=e112]: 尚无序列运行
            - paragraph [ref=e113]: 选择序列并完成变量预检后，执行进度会在这里实时展示。
          - generic [ref=e114]:
            - heading "发送后，再开始下一步计时" [level=3] [ref=e115]
            - paragraph [ref=e116]: 限流时步骤等待恢复。没有匹配角色的可用账号时跳过；群不可写时停止运行。
      - generic [ref=e117]:
        - generic [ref=e118]: Kapibala Console
        - generic [ref=e119]: 状态有记录，执行可追踪。
```

# Test source

```ts
  1   | import type { Frame, JSHandle, Page, WebSocket } from '@playwright/test';
  2   | import { BlockedError } from '../../harness/security.js';
  3   | 
  4   | export interface ContinuityPoint {
  5   |   url: string;
  6   |   navigations: number;
  7   |   socketChanges: number;
  8   |   scopeReady: number;
  9   |   scopeEstablished: boolean;
  10  | }
  11  | 
  12  | /** Public observations only; does not read or write the product's internal scope. */
  13  | export class ContinuityLedger {
  14  |   readonly events: { at: number; kind: string; url?: string }[] = [];
  15  |   readonly checks: {
  16  |     at: number;
  17  |     before: ContinuityPoint;
  18  |     after: ContinuityPoint;
  19  |     sameDocument: boolean;
  20  |   }[] = [];
  21  |   private navigations = 0;
  22  |   private socketChanges = 0;
  23  |   private scopeReady = 0;
  24  |   private scopeEstablished = false;
  25  |   private nextSocketId = 0;
  26  |   private activeSocketId: number | undefined;
  27  |   navigation(url: string) {
  28  |     this.navigations++;
  29  |     this.events.push({ at: performance.now(), kind: 'main-frame-navigation', url });
  30  |   }
  31  |   socket(kind: 'open' | 'close', socketId = this.activeSocketId) {
  32  |     this.socketChanges++;
  33  |     if (kind === 'open') {
  34  |       socketId = ++this.nextSocketId;
  35  |       this.activeSocketId = socketId;
  36  |       this.scopeEstablished = false;
  37  |     } else if (socketId === this.activeSocketId) {
  38  |       this.activeSocketId = undefined;
  39  |       this.scopeEstablished = false;
  40  |     }
  41  |     this.events.push({ at: performance.now(), kind: `socket-${kind}` });
  42  |     return socketId;
  43  |   }
  44  |   frame(payload: string | Buffer, socketId = this.activeSocketId) {
  45  |     let value: unknown;
  46  |     try {
  47  |       value = JSON.parse(String(payload));
  48  |     } catch {
  49  |       return;
  50  |     }
  51  |     if (value && typeof value === 'object' && 'type' in value && value.type === 'scope_ready') {
  52  |       if (socketId === undefined || socketId !== this.activeSocketId) {
  53  |         this.events.push({ at: performance.now(), kind: 'stale-socket-scope_ready' });
  54  |         return;
  55  |       }
  56  |       this.scopeReady++;
  57  |       if (
  58  |         'startSeq' in value &&
  59  |         Number.isSafeInteger(value.startSeq) &&
  60  |         Number(value.startSeq) >= 0
  61  |       )
  62  |         this.scopeEstablished = true;
  63  |       this.events.push({ at: performance.now(), kind: 'scope_ready' });
  64  |     }
  65  |   }
  66  |   snapshot(url: string): ContinuityPoint {
  67  |     return {
  68  |       url,
  69  |       navigations: this.navigations,
  70  |       socketChanges: this.socketChanges,
  71  |       scopeReady: this.scopeReady,
  72  |       scopeEstablished: this.scopeEstablished,
  73  |     };
  74  |   }
  75  |   assertUnchanged(before: ContinuityPoint, url: string, sameDocument: boolean) {
  76  |     const after = this.snapshot(url);
  77  |     this.checks.push({ at: performance.now(), before, after, sameDocument });
  78  |     if (!before.scopeEstablished)
  79  |       throw new BlockedError('未观察到公开scope_ready，无法建立动作前的scope基线');
  80  |     if (
  81  |       !sameDocument ||
  82  |       Object.keys(before).some(
  83  |         (key) => before[key as keyof ContinuityPoint] !== after[key as keyof ContinuityPoint],
  84  |       )
  85  |     )
> 86  |       throw new BlockedError(
      |             ^ BlockedError: [BLOCKED] 动作窗口出现document/URL/主frame导航/WS连接或scope_ready变化，不能把范围重建当作原页面确认或恢复
  87  |         '动作窗口出现document/URL/主frame导航/WS连接或scope_ready变化，不能把范围重建当作原页面确认或恢复',
  88  |       );
  89  |   }
  90  | }
  91  | 
  92  | type RecordedError = { name: string; message: string };
  93  | const recordedError = (error: unknown): RecordedError =>
  94  |   error instanceof Error
  95  |     ? { name: error.name, message: error.message }
  96  |     : { name: 'ThrownValue', message: String(error) };
  97  | export interface ContinuityOutcome {
  98  |   outcome: 'completed' | 'confirmed-business-failure' | 'blocked-continuity' | 'action-error';
  99  |   primary?: RecordedError;
  100 |   confirmedBusinessFailure?: RecordedError;
  101 |   boundaryErrors: { stage: string; error: RecordedError }[];
  102 |   assertions: { label: string; error?: RecordedError; continuityAfter: boolean }[];
  103 | }
  104 | 
  105 | /** A later contaminated boundary must not erase a failure already proved in a valid window.
  106 |  * A title/locator timeout spanning navigation is not such proof: retain it, then BLOCKED.
  107 |  */
  108 | export async function withContinuityEvidence(
  109 |   continuity: () => Promise<void>,
  110 |   action: (
  111 |     check: (label: string, assertion: () => unknown | Promise<unknown>) => Promise<void>,
  112 |   ) => Promise<void>,
  113 |   record: (outcome: ContinuityOutcome) => void,
  114 | ): Promise<void> {
  115 |   let primary: { error: unknown } | undefined;
  116 |   let confirmed: { error: unknown } | undefined;
  117 |   const boundaries: { stage: string; error: unknown }[] = [];
  118 |   const assertions: ContinuityOutcome['assertions'] = [];
  119 |   const boundary = async (stage: string) => {
  120 |     try {
  121 |       await continuity();
  122 |       return undefined;
  123 |     } catch (error) {
  124 |       const failure = { stage, error };
  125 |       boundaries.push(failure);
  126 |       return failure;
  127 |     }
  128 |   };
  129 |   try {
  130 |     await action(async (label, assertion) => {
  131 |       const before = await boundary(`${label}:before`);
  132 |       if (before) throw before.error;
  133 |       let failed: { error: unknown } | undefined;
  134 |       try {
  135 |         await assertion();
  136 |       } catch (error) {
  137 |         failed = { error };
  138 |       }
  139 |       const after = await boundary(`${label}:after`);
  140 |       assertions.push({
  141 |         label,
  142 |         ...(failed ? { error: recordedError(failed.error) } : {}),
  143 |         continuityAfter: !after,
  144 |       });
  145 |       if (failed && !after && !(failed.error instanceof BlockedError)) confirmed ??= failed;
  146 |       if (after) throw after.error;
  147 |       if (failed) throw failed.error;
  148 |     });
  149 |   } catch (error) {
  150 |     primary = { error };
  151 |   }
  152 |   await boundary('action:final');
  153 |   const selected = confirmed ?? boundaries[0] ?? primary;
  154 |   record({
  155 |     outcome: confirmed
  156 |       ? 'confirmed-business-failure'
  157 |       : boundaries.length
  158 |         ? 'blocked-continuity'
  159 |         : primary
  160 |           ? 'action-error'
  161 |           : 'completed',
  162 |     ...(primary ? { primary: recordedError(primary.error) } : {}),
  163 |     ...(confirmed ? { confirmedBusinessFailure: recordedError(confirmed.error) } : {}),
  164 |     boundaryErrors: boundaries.map(({ stage, error }) => ({ stage, error: recordedError(error) })),
  165 |     assertions,
  166 |   });
  167 |   if (selected) throw selected.error;
  168 | }
  169 | 
  170 | /** Attach before login to observe the existing socket; callbacks never fabricate events. */
  171 | export function observePageContinuity(page: Page) {
  172 |   const ledger = new ContinuityLedger();
  173 |   const handles = new Set<JSHandle<Document>>();
  174 |   const sockets = new Map<
  175 |     WebSocket,
  176 |     { frame: (event: { payload: string | Buffer }) => void; close: () => void }
  177 |   >();
  178 |   const navigation = (frame: Frame) => {
  179 |     if (frame === page.mainFrame()) ledger.navigation(frame.url());
  180 |   };
  181 |   const opened = (socket: WebSocket) => {
  182 |     if (new URL(socket.url()).pathname !== '/ws') return;
  183 |     const socketId = ledger.socket('open')!;
  184 |     const frame = ({ payload }: { payload: string | Buffer }) => ledger.frame(payload, socketId);
  185 |     const close = () => {
  186 |       ledger.socket('close', socketId);
```