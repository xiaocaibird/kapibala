# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/integration-streams.spec.ts >> [INT-STREAM-001] real paused reader leaves healthy consumer working and received-cursor replay complete
- Location: tests/system/integration-streams.spec.ts:79:1

# Error details

```
BlockedError: [BLOCKED] Bounded healthy drain did not establish the complete injected set; no throughput SLA inferred
```

# Test source

```ts
  107 |   const receipts = (client: ReceiptSocket) => {
  108 |     client.assertProtocolViolations();
  109 |     const selected = assertReceiptSubset(
  110 |       client.observedFrames,
  111 |       new Set(expected.keys()),
  112 |       ancillary,
  113 |     );
  114 |     for (const frame of selected) expect(frame).toMatchObject({ groupId: group.id, isOwn: false });
  115 |     return selected;
  116 |   };
  117 |   const invariant = () => {
  118 |     // Check every already received violation before any QA limit can BLOCK the sample.
  119 |     for (const client of [healthy, slow, ...(replay ? [replay] : [])]) receipts(client);
  120 |     healthy.assertHealthy();
  121 |     replay?.assertHealthy();
  122 |     // A slow transport error is not proof of a peer policy. Keep its valid frames
  123 |     // for independent replay checks, then classify the unproven cause separately.
  124 |     slow.assertValidFrames();
  125 |   };
  126 |   const evidence = () => ({
  127 |     checkpoint,
  128 |     profile,
  129 |     expected: [...expected],
  130 |     injectedTextBytes,
  131 |     phases,
  132 |     slow: slow.snapshot(),
  133 |     healthy: healthy.snapshot(),
  134 |     replay: replay?.snapshot() ?? null,
  135 |     closureAndReplayVerified,
  136 |     slowPolicyVerified,
  137 |     peerFramePolicyVerified,
  138 |     connectionAttribution,
  139 |     limit:
  140 |       'payloadBytes measures complete received WS application-message bytes, not TCP/WS wire bytes. Close/replay alone does not identify server buffer or timeout policy, memory bound, throughput SLA or browser three-second recovery.',
  141 |   });
  142 |   try {
  143 |     phase('authenticate');
  144 |     await Promise.all([slow.authenticate(qa.api.token!), healthy.authenticate(qa.api.token!)]);
  145 |     qa.gateway.emitMessage({
  146 |       groupId: group.gatewayGroupId,
  147 |       msgId: 'pause-checkpoint',
  148 |       senderPlatformUserId: 'outside',
  149 |       text: 'checkpoint',
  150 |     });
  151 |     injectedTextBytes = Buffer.byteLength('checkpoint');
  152 |     const ready = await observe({
  153 |       read: async () => [slow.frames, healthy.frames],
  154 |       invariant: () => {
  155 |         invariant();
  156 |         slow.assertHealthy();
  157 |       },
  158 |       complete: (values) =>
  159 |         values.every((frames) => frames.some((f) => f.msgId === 'pause-checkpoint')),
  160 |       durationMs: 10000,
  161 |     });
  162 |     if (!ready.complete) throw new BlockedError('Initial received cursor was not established');
  163 |     checkpoint = slow.pause();
  164 |     expect(checkpoint).toBeGreaterThan(0);
  165 |     const receiptCount = slow.frames.length;
  166 |     const whilePaused = () => {
  167 |       invariant();
  168 |       slow.assertPausedWindow(checkpoint, receiptCount);
  169 |     };
  170 |     phase('inject-start');
  171 |     const injection = await injectBoundedReceiptWorkload({
  172 |       maxMessages: profile.maxMessages,
  173 |       batchSize: profile.batchSize,
  174 |       batchIntervalMs: profile.batchIntervalMs,
  175 |       durationMs: profile.injectionBudgetMs,
  176 |       invariant: whilePaused,
  177 |       inject: (i) => {
  178 |         const msgId = `slow-stream-${i}`;
  179 |         const text = `${msgId}:` + 'x'.repeat(profile.textPaddingBytes);
  180 |         if (injectedTextBytes + Buffer.byteLength(text) > profile.maxInjectedTextBytes)
  181 |           throw new BlockedError('Authored QA injection text-byte limit reached');
  182 |         expected.set(msgId, hash(text));
  183 |         qa.gateway.emitMessage({
  184 |           groupId: group.gatewayGroupId,
  185 |           msgId,
  186 |           senderPlatformUserId: 'outside',
  187 |           text,
  188 |         });
  189 |         injectedTextBytes += Buffer.byteLength(text);
  190 |       },
  191 |     });
  192 |     phase('inject-ended', injection);
  193 |     phase('healthy-drain-start');
  194 |     const drained = await observe({
  195 |       read: async () => receipts(healthy),
  196 |       invariant: whilePaused,
  197 |       complete: (frames) => frames.length === expected.size,
  198 |       durationMs: profile.healthyDrainMs,
  199 |     });
  200 |     phase('healthy-drain-ended', {
  201 |       complete: drained.complete,
  202 |       received: drained.last.length,
  203 |       expected: expected.size,
  204 |       elapsedMs: drained.elapsedMs,
  205 |     });
  206 |     if (!drained.complete || expected.size === 0)
> 207 |       throw new BlockedError(
      |             ^ BlockedError: [BLOCKED] Bounded healthy drain did not establish the complete injected set; no throughput SLA inferred
  208 |         'Bounded healthy drain did not establish the complete injected set; no throughput SLA inferred',
  209 |       );
  210 |     assertCompleteReceipts(drained.last, new Set(expected.keys()));
  211 |     slow.assertPausedWindow(checkpoint, receiptCount);
  212 |     // WS requires message identity, not payload.text. Check text via public history.
  213 |     const apiExpected = new Map<string, { text: string }>([
  214 |       ['message:pause-checkpoint', { text: 'checkpoint' }],
  215 |     ]);
  216 |     for (const msgId of expected.keys())
  217 |       apiExpected.set(`message:${msgId}`, {
  218 |         text: `${msgId}:` + 'x'.repeat(profile.textPaddingBytes),
  219 |       });
  220 |     phase('history-start');
  221 |     const historyStarted = performance.now();
  222 |     const history = await allMessages(qa.api, group.id, {
  223 |       maxPages: profile.historyMaxPages,
  224 |       budgetMs: profile.historyObservationMs,
  225 |       inspect: (items, complete) => {
  226 |         messageSubset(items, apiExpected);
  227 |         if (complete) expect(items).toHaveLength(expected.size + 1);
  228 |         whilePaused();
  229 |       },
  230 |     });
  231 |     expect(history).toHaveLength(expected.size + 1);
  232 |     for (const message of history.filter((entry) => entry.msgId?.startsWith('slow-stream-')))
  233 |       expect(hash(message.text)).toBe(expected.get(message.msgId!));
  234 |     phase('history-complete', {
  235 |       count: history.length,
  236 |       elapsedMs: performance.now() - historyStarted,
  237 |       observationBudgetExceeded: performance.now() - historyStarted > profile.historyObservationMs,
  238 |     });
  239 |     // No reading or application-level discarding while waiting for a server-side close.
  240 |     await observe({
  241 |       read: async () => healthy.closed,
  242 |       invariant: whilePaused,
  243 |       complete: () => false,
  244 |       durationMs: profile.pausedObservationMs,
  245 |     });
  246 |     phase('resume-old-reader');
  247 |     slow.resume();
  248 |     const closure = await observe({
  249 |       read: async () => slow.closed,
  250 |       invariant,
  251 |       complete: (value) => !!value,
  252 |       durationMs: profile.closeObservationMs,
  253 |     });
  254 |     phase('close-observation-ended', { complete: closure.complete, closed: slow.closed });
  255 |     if (!closure.complete)
  256 |       throw new BlockedError(
  257 |         'Real reader was paused, but this bounded profile did not prove server-side closure; increase an explicitly reviewed workload or supply transport observation, never fake sender callbacks',
  258 |       );
  259 |     if (slow.closed?.source === 'local-termination')
  260 |       throw new BlockedError(
  261 |         'QA locally terminated the reader; it cannot establish server-side closure',
  262 |       );
  263 | 
  264 |     // Use the last actually received cursor after draining the old connection,
  265 |     // never a server attempted-send position or the healthy client's cursor.
  266 |     const receivedBeforeReconnect = slow.lastReceivedSeq;
  267 |     const receivedHealthy = receipts(healthy);
  268 |     const receivedSlow = receipts(slow);
  269 |     expect(receivedSlow.map(projectFrame)).toEqual(
  270 |       receivedHealthy.filter((frame) => frame.seq! <= receivedBeforeReconnect).map(projectFrame),
  271 |     );
  272 |     const missing = healthy.frames.filter(
  273 |       (f) =>
  274 |         f.seq !== undefined &&
  275 |         f.seq > receivedBeforeReconnect &&
  276 |         f.msgId?.startsWith('slow-stream-'),
  277 |     );
  278 |     if (!missing.length)
  279 |       throw new BlockedError(
  280 |         'Old transport ended but buffered data fully drained; replay-gap prerequisite was not demonstrated',
  281 |       );
  282 |     phase('replay-start', { sinceSeq: receivedBeforeReconnect, missing: missing.length });
  283 |     replay = new ReceiptSocket(qa.api.baseUrl, profile.receipts);
  284 |     await replay.authenticate(qa.api.token!, receivedBeforeReconnect);
  285 |     const replayClient = replay;
  286 |     const restored = await observe({
  287 |       read: async () => {
  288 |         return assertReceiptSubset(
  289 |           replayClient.frames,
  290 |           new Set(missing.map((frame) => frame.msgId!)),
  291 |         );
  292 |       },
  293 |       invariant,
  294 |       complete: (frames) => frames.length === missing.length,
  295 |       durationMs: profile.replayObservationMs,
  296 |     });
  297 |     phase('replay-observation-ended', {
  298 |       complete: restored.complete,
  299 |       received: restored.last.length,
  300 |       missing: missing.length,
  301 |     });
  302 |     if (!restored.complete)
  303 |       throw new BlockedError(
  304 |         'Replay observation budget exhausted; no arbitrary server replay SLA inferred',
  305 |       );
  306 |     expect(restored.last.map(projectFrame)).toEqual(missing.map(projectFrame));
  307 |     const received = receipts(healthy);
```