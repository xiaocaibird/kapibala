# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/capacity-control.spec.ts >> [CAP-003] persistent admission refusal consumes the original active budget without resetting the clock
- Location: tests/system/capacity-control.spec.ts:340:1

# Error details

```
Error: 已确定超过活动预算才停止

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 60000
Received:    60004
```

# Test source

```ts
  331 | }) => {
  332 |   await deferred(qa, 'capacity-cancel', async (kick, lease, _control, creationBounds) => {
  333 |     await qa.api.require(qa.api.patch(`/api/groups/${kick.group.id}`, { agentEnabled: false }));
  334 |     expect((await qa.api.group(kick.group.id)).agentEnabled).toBe(false);
  335 |     await cancellationAfterRelease(qa, kick, lease, creationBounds, true);
  336 |     await captureKickEvidence(qa, 'capacity-cancel-final', [kick]);
  337 |   });
  338 | });
  339 | 
  340 | test('[CAP-003] persistent admission refusal consumes the original active budget without resetting the clock', async ({
  341 |   qa,
  342 | }) => {
  343 |   test.setTimeout(120_000);
  344 |   await deferred(
  345 |     qa,
  346 |     'capacity-budget',
  347 |     async (kick, lease, _control, creationBounds) => {
  348 |       let lastRunningRequestBefore: number | undefined;
  349 |       let firstTerminalResponseAfter: number | undefined;
  350 |       const publicSamples: {
  351 |         requestBefore: number;
  352 |         responseAfter: number;
  353 |         status: string;
  354 |         endReason: string | null;
  355 |       }[] = [];
  356 |       const samplePublicRun = async (): Promise<AgentRun> => {
  357 |         const requestBefore = performance.now();
  358 |         const current = await qa.api.agentRun(kick.runId);
  359 |         const responseAfter = performance.now();
  360 |         publicSamples.push({
  361 |           requestBefore,
  362 |           responseAfter,
  363 |           status: current.status,
  364 |           endReason: current.endReason,
  365 |         });
  366 |         if (current.status === 'running') {
  367 |           expect(firstTerminalResponseAfter, '已公开的终态不能重新变为running').toBeUndefined();
  368 |           lastRunningRequestBefore = requestBefore;
  369 |         } else firstTerminalResponseAfter ??= responseAfter;
  370 |         return current;
  371 |       };
  372 |       await samplePublicRun();
  373 |       const snapshot = await lease.waitFor(
  374 |         (value) => value.events.some((event) => event.kind === 'run-terminal'),
  375 |         {
  376 |           timeoutMs: 65_000,
  377 |           inspect: async () => {
  378 |             noKick(qa, kick);
  379 |             onceAudited(qa, kick);
  380 |             await samplePublicRun();
  381 |           },
  382 |         },
  383 |       );
  384 |       const end = snapshot.events.find((event) => event.kind === 'run-terminal')!;
  385 |       expect(end.status).toBe('failed');
  386 |       expect(end.endReason).toBe('wall_clock');
  387 |       const run = await eventually(samplePublicRun, (current) => current.status !== 'running', {
  388 |         timeoutMs: 30_000,
  389 |       });
  390 |       expect(run).toMatchObject({ status: 'failed', endReason: 'wall_clock' });
  391 |       const bounds = end.activeElapsedMs;
  392 |       const independentElapsedBounds =
  393 |         lastRunningRequestBefore === undefined || firstTerminalResponseAfter === undefined
  394 |           ? undefined
  395 |           : ([
  396 |               Math.max(0, lastRunningRequestBefore - creationBounds[1]),
  397 |               firstTerminalResponseAfter - creationBounds[0],
  398 |             ] as const);
  399 |       await qa.evidence('capacity-active-budget', {
  400 |         bounds,
  401 |         requiredMs: 60_000,
  402 |         diagnostic: end,
  403 |         creationBounds,
  404 |         publicSamples,
  405 |         independentElapsedBounds,
  406 |         independentClock:
  407 |           'QA performance.now；终态下界取最后running请求开始，上界取首次terminal响应完成，均减去保守创建区间',
  408 |         limit: '相交仅说明独立观察未证伪控制器；不将轮询或预设deadline宣称为精确60秒实测',
  409 |       });
  410 |       if (!bounds) throw new BlockedError('控制器未提供原 run 活动预算决定的权威时间区间');
  411 |       if (
  412 |         !independentElapsedBounds ||
  413 |         !independentElapsedBounds.every(Number.isFinite) ||
  414 |         independentElapsedBounds[0] > independentElapsedBounds[1]
  415 |       )
  416 |         throw new BlockedError(
  417 |           '缺少有效独立running→terminal时间上下界，不能采信控制器自报精确60000',
  418 |         );
  419 |       expect(
  420 |         independentElapsedBounds[0],
  421 |         '独立单调时钟已确认晚于60秒，控制器精确值不能掩盖',
  422 |       ).toBeLessThanOrEqual(60_000);
  423 |       expect(
  424 |         independentElapsedBounds[1],
  425 |         '独立单调时钟已确认早于60秒，控制器精确值不能掩盖',
  426 |       ).toBeGreaterThanOrEqual(60_000);
  427 |       expect(
  428 |         Math.max(independentElapsedBounds[0], bounds[0]),
  429 |         '控制器实际活动区间与独立公开观察区间不相交',
  430 |       ).toBeLessThanOrEqual(Math.min(independentElapsedBounds[1], bounds[1]));
> 431 |       expect(bounds[0], '已确定超过活动预算才停止').toBeLessThanOrEqual(60_000);
      |                                         ^ Error: 已确定超过活动预算才停止
  432 |       expect(bounds[1], '已确定提前冒充预算耗尽').toBeGreaterThanOrEqual(60_000);
  433 |       if (bounds[1] > 60_000)
  434 |         throw new BlockedError('预算决定测量区间跨60秒边界；保留证据，不擅加计时容差');
  435 |       expect(
  436 |         run.steps.filter((step) => step.toolUseId === kick.toolUseId).length,
  437 |       ).toBeLessThanOrEqual(1);
  438 |       await lease.release();
  439 |       await observeNoLateKick(qa, kick, { status: run.status, endReason: run.endReason });
  440 |       await captureKickEvidence(qa, 'capacity-budget-final', [kick]);
  441 |     },
  442 |     { clock: true },
  443 |   );
  444 | });
  445 | 
  446 | test('[CAP-004] policy is rechecked after confirmed zero-effect admission deferral', async ({
  447 |   qa,
  448 | }) => {
  449 |   await deferred(qa, 'capacity-policy', async (kick, lease) => {
  450 |     await qa.api.require(qa.api.patch(`/api/groups/${kick.group.id}`, { autoKickEnabled: false }));
  451 |     expect((await qa.api.group(kick.group.id)).autoKickEnabled).toBe(false);
  452 |     await lease.release();
  453 |     finalStep(qa, kick, await terminal(qa, kick), 'POLICY_DENIED');
  454 |     noKick(qa, kick);
  455 |     expect(targetIsPresent(qa, kick)).toBe(true);
  456 |     await captureKickEvidence(qa, 'capacity-policy-final', [kick]);
  457 |   });
  458 | });
  459 | 
  460 | test('[CAP-005] group unreachability during admission wait cancels without a late kick', async ({
  461 |   qa,
  462 | }) => {
  463 |   let staged: { clientMsgId: string; eventId: number } | undefined;
  464 |   try {
  465 |     await deferred(
  466 |       qa,
  467 |       'capacity-unreachable',
  468 |       async (kick, lease, _control, creationBounds) => {
  469 |         if (!staged) throw new Error('QA accepted-failure setup was not recorded');
  470 |         const { clientMsgId, eventId } = staged;
  471 |         await held(lease, '补投真实群不可写事件前');
  472 |         noKick(qa, kick);
  473 |         expect(qa.gateway.snapshot().connectedStreams).toBe(0);
  474 |         if ((await qa.api.group(kick.group.id)).status !== 'active')
  475 |           throw new BlockedError('恢复SSE前群已不再active，未命中容量拒绝后才处理失败事件的窗口');
  476 |         // The send was accepted before saturation. Restore retained SSE history;
  477 |         // do not release capacity or invent a failure for work still queued locally.
  478 |         qa.gateway.configure({ sseUnavailable: false });
  479 |         const observation = await observe({
  480 |           read: async () => ({
  481 |             group: await qa.api.group(kick.group.id),
  482 |             messages: await qa.api.messages(kick.group.id),
  483 |           }),
  484 |           durationMs: 15_000,
  485 |           invariant: ({ messages }) => {
  486 |             noKick(qa, kick);
  487 |             expect(
  488 |               messages.items.filter((message) => message.clientMsgId === clientMsgId),
  489 |             ).toHaveLength(1);
  490 |             expect(
  491 |               qa.gateway.snapshot().messages.some((message) => message.clientMsgId === clientMsgId),
  492 |             ).toBe(false);
  493 |           },
  494 |           complete: ({ group, messages }) =>
  495 |             group.status === 'unreachable' &&
  496 |             messages.items.some(
  497 |               (message) =>
  498 |                 message.clientMsgId === clientMsgId &&
  499 |                 message.deliveryStatus === 'failed' &&
  500 |                 message.failCode === 'GROUP_WRITE_FORBIDDEN',
  501 |             ),
  502 |         });
  503 |         await qa.evidence('capacity-group-write-forbidden-prerequisite', {
  504 |           clientMsgId,
  505 |           eventId,
  506 |           observation,
  507 |           gateway: qa.gateway.snapshot(),
  508 |         });
  509 |         if (!observation.complete)
  510 |           throw new BlockedError('有限观察内未建立真实失败事件补投后的消息failed及群不可写前提');
  511 |         expect(
  512 |           qa.gateway.snapshot().events.find((event) => event.eventId === eventId),
  513 |         ).toMatchObject({
  514 |           type: 'message_failed',
  515 |           data: { clientMsgId, code: 'GROUP_WRITE_FORBIDDEN' },
  516 |         });
  517 |         expect(
  518 |           qa.gateway.snapshot().groups.find((group) => group.groupId === kick.group.gatewayGroupId)
  519 |             ?.writable,
  520 |         ).toBe(false);
  521 |         await cancellationAfterRelease(qa, kick, lease, creationBounds, false);
  522 |         await captureKickEvidence(qa, 'capacity-unreachable-final', [kick]);
  523 |       },
  524 |       {
  525 |         beforeAdmissionHold: async (kick) => {
  526 |           qa.gateway.configure({ sseUnavailable: true });
  527 |           qa.gateway.disconnectStreams();
  528 |           const path = `/groups/${kick.group.gatewayGroupId}/send`;
  529 |           qa.gateway.enqueue(path, { failureCode: 'GROUP_WRITE_FORBIDDEN' });
  530 |           const sent = await qa.api.send(
  531 |             kick.group.id,
```