# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/integration-runtime.spec.ts >> [INT-ACT-001] activity budget accumulates across restart and excludes proven downtime without tail tolerance
- Location: tests/system/integration-runtime.spec.ts:141:1

# Error details

```
AssertionError: 两个真实活动段安全下界已超过原始60000ms上限
```

# Test source

```ts
  134 |       old.clock.monotonicMs > previous.clock.monotonicMs &&
  135 |       before.snapshot.events.every((event, i) =>
  136 |         isDeepStrictEqual(event, finalBefore.snapshot.events[i]),
  137 |       ),
  138 |     '两次live校准没有前进、身份漂移或历史改变',
  139 |   );
  140 |   const offset: Bounds = [
  141 |     Math.max(previous.offset[0], old.offset[0]),
  142 |     Math.min(previous.offset[1], old.offset[1]),
  143 |   ];
  144 |   need(offset[0] <= offset[1], '同一应用时钟两次映射不相容，不可假设稳定速率');
  145 |   need(
  146 |     finalBefore.snapshot.state === 'held' &&
  147 |       old.last.activityState === 'active' &&
  148 |       old.events.some(
  149 |         (e) =>
  150 |           e.kind === 'activity-safe-held' &&
  151 |           e.continuationDurable === true &&
  152 |           e.remoteInFlightCount === 0,
  153 |       ),
  154 |     '原epoch未在真实可恢复且无在途副作用的屏障保持',
  155 |   );
  156 |   return { old, offset };
  157 | }
  158 | /** Observe the same hard lower bound before terminal/COMMIT availability.
  159 |  * A current live lifecycle read must follow the measured activity read. When a
  160 |  * real stop already exists, its endpoint replaces later active bookkeeping. */
  161 | export function assertCrossEpochLiveLower(input: {
  162 |   beforeKill: [MeasuredRuntimeSnapshot, MeasuredRuntimeSnapshot];
  163 |   exited: ApplicationExitEvidence;
  164 |   current: MeasuredRuntimeSnapshot;
  165 |   lifecycle: MeasuredRuntimeSnapshot['snapshot'];
  166 | }): void {
  167 |   assertNoDispatchAfterStop(input.lifecycle.events);
  168 |   assertNoRecoveryPause(input.current.snapshot.events);
  169 |   const { old, offset } = prepareCrossEpochKill(input.beforeKill);
  170 |   const next = epoch(input.current, 'clock-acquisition');
  171 |   const prior = input.beforeKill[1];
  172 |   need(
  173 |     input.current.parentClockDomain === prior.parentClockDomain &&
  174 |       input.exited.parentClockDomain === prior.parentClockDomain &&
  175 |       input.exited.guardianPid === prior.snapshot.binding.pid &&
  176 |       input.exited.applicationPid === old.clock.applicationPid &&
  177 |       input.exited.applicationStarted === old.provenance.applicationStarted &&
  178 |       input.exited.signal === 'SIGKILL' &&
  179 |       ['owned-process-confirmed-absent', 'owned-process-identity-replaced'].includes(
  180 |         input.exited.exitObservation,
  181 |       ),
  182 |     '实时下界缺真实同域退出',
  183 |   );
  184 |   need(
  185 |     isDeepStrictEqual(prior.snapshot.correlation, input.current.snapshot.correlation) &&
  186 |       prior.snapshot.binding.revision === input.current.snapshot.binding.revision &&
  187 |       prior.snapshot.binding.observedOwnerToken ===
  188 |         input.current.snapshot.binding.observedOwnerToken &&
  189 |       old.id !== next.id &&
  190 |       old.clock.applicationPid !== next.clock.applicationPid &&
  191 |       old.clock.clockDomain !== next.clock.clockDomain,
  192 |     '实时下界跨run/候选/owner或未形成新epoch',
  193 |   );
  194 |   const exited = observationInterval([
  195 |     input.exited.signalRequestedBeforeMs,
  196 |     input.exited.processExitObservedAfterMs,
  197 |   ]);
  198 |   need(
  199 |     prior.parentWindowMs[1] <= exited[0] && mapped(next.start, next.offset)[0] >= exited[1],
  200 |     '实时活动段顺序不成立',
  201 |   );
  202 |   const oldLower = span(mapped(old.start, offset), exited)[0];
  203 |   const source = input.lifecycle.snapshotProvenance;
  204 |   need(
  205 |     source?.source === 'live-bridge' &&
  206 |       source.applicationPid === next.clock.applicationPid &&
  207 |       source.applicationStarted === next.provenance.applicationStarted &&
  208 |       input.lifecycle.events[0]?.kind === 'lifecycle-observation-attached' &&
  209 |       input.lifecycle.events[0].droppedThroughSourceSeq === 0,
  210 |     '实时活动下界缺完整实时停止历史',
  211 |   );
  212 |   const decisions = input.lifecycle.events.filter((e) => e.kind === 'agent-termination-decided');
  213 |   let currentLower: number;
  214 |   if (decisions.length) {
  215 |     need(decisions.length === 1, '实时停止决定不唯一');
  216 |     const decision = decisions[0]!;
  217 |     need(
  218 |       decision.runId === next.last.runId &&
  219 |         decision.groupId === next.last.groupId &&
  220 |         decision.applicationPid === next.clock.applicationPid &&
  221 |         decision.clockDomain === next.clock.clockDomain,
  222 |       '实时停止决定身份不匹配',
  223 |     );
  224 |     currentLower = span(next.start, observationInterval(decision.decisionWindowMs))[0];
  225 |   } else {
  226 |     need(next.last.activityState === 'active', '缺停止决定且无真实进行中阶段');
  227 |     currentLower = Math.max(
  228 |       0,
  229 |       ...next.events
  230 |         .filter((e) => e.activityState === 'active')
  231 |         .map((e) => observationInterval(e.observedEpochActiveMs)[0]),
  232 |     );
  233 |   }
> 234 |   assert.ok(oldLower + currentLower <= 60_000, '两个真实活动段安全下界已超过原始60000ms上限');
      |          ^ AssertionError: 两个真实活动段安全下界已超过原始60000ms上限
  235 | }
  236 | /** Independent QA interval arithmetic, not the engineering aggregator.
  237 |  * No latency symmetry, shared process clock origin, or fixed tail tolerance. */
  238 | export function collectCrossEpochEvidence(input: CrossEpochInput) {
  239 |   assertNoDispatchAfterStop(input.recoveredLifecycle);
  240 |   for (const measured of [...input.beforeKill, input.afterRecovery])
  241 |     assertNoRecoveryPause(measured.snapshot.events);
  242 |   const [before, finalBefore] = input.beforeKill;
  243 |   const { old, offset } = prepareCrossEpochKill(input.beforeKill);
  244 |   const next = epoch(input.afterRecovery, 'clock-acquisition');
  245 |   const parentClockDomain = finalBefore.parentClockDomain;
  246 |   need(
  247 |     input.afterRecovery.parentClockDomain === parentClockDomain &&
  248 |       input.exited.parentClockDomain === parentClockDomain,
  249 |     '跨父时钟域不得聚合',
  250 |   );
  251 |   need(
  252 |     isDeepStrictEqual(finalBefore.snapshot.correlation, input.afterRecovery.snapshot.correlation) &&
  253 |       finalBefore.snapshot.binding.revision === input.afterRecovery.snapshot.binding.revision &&
  254 |       finalBefore.snapshot.binding.observedOwnerToken ===
  255 |         input.afterRecovery.snapshot.binding.observedOwnerToken &&
  256 |       old.id !== next.id &&
  257 |       old.clock.applicationPid !== next.clock.applicationPid &&
  258 |       old.clock.clockDomain !== next.clock.clockDomain &&
  259 |       finalBefore.snapshot.binding.pid !== input.afterRecovery.snapshot.binding.pid,
  260 |     '恢复身份/候选不一致，或未形成两个实际epoch',
  261 |   );
  262 |   const exited = input.exited;
  263 |   need(
  264 |     exited.guardianPid === finalBefore.snapshot.binding.pid &&
  265 |       exited.applicationPid === old.clock.applicationPid &&
  266 |       exited.applicationStarted === old.provenance.applicationStarted &&
  267 |       exited.signal === 'SIGKILL' &&
  268 |       ['owned-process-confirmed-absent', 'owned-process-identity-replaced'].includes(
  269 |         exited.exitObservation,
  270 |       ),
  271 |     '退出没有核实实际应用身份，guardian退出不足',
  272 |   );
  273 |   const exitWindow = observationInterval([
  274 |     exited.signalRequestedBeforeMs,
  275 |     exited.processExitObservedAfterMs,
  276 |   ]);
  277 |   need(finalBefore.parentWindowMs[1] <= exitWindow[0], '实时校准必须在发出kill之前完成');
  278 |   const creation = mapped(old.start, offset);
  279 |   const oldActive = span(creation, exitWindow);
  280 |   need(
  281 |     next.last.kind === 'activity-terminal' && next.last.activityState === 'terminal',
  282 |     '新段缺真实终态边界',
  283 |   );
  284 |   const end = observationInterval(next.last.activityEndWindowMs);
  285 |   need(end[1] <= next.clock.monotonicMs, '终态边界晚于当前真实时钟读数');
  286 |   const newStart = mapped(next.start, next.offset),
  287 |     newEnd = mapped(end, next.offset);
  288 |   need(newStart[0] >= exitWindow[1], '两个实际进程活动段重叠或逆序');
  289 |   const missing: string[] = [];
  290 |   // These diagnostic/completeness obligations cannot hide the already proved
  291 |   // lower bound above the requirement. assertCrossEpochBudget orders verdicts.
  292 |   let startupGapMs: Bounds | null = null;
  293 |   let provenDowntimeMs: Bounds | null = null;
  294 |   try {
  295 |     const startup = observationInterval(input.startupWindowMs);
  296 |     need(
  297 |       startup[0] >= exitWindow[1] &&
  298 |         startup[1] <= input.afterRecovery.parentWindowMs[0] &&
  299 |         newStart[1] >= startup[0],
  300 |       '缺少有序真实启动窗',
  301 |     );
  302 |     provenDowntimeMs = span(exitWindow, [startup[0], startup[0]]);
  303 |     startupGapMs = [0, Math.max(0, newStart[1] - startup[0])];
  304 |   } catch (error) {
  305 |     if (!(error instanceof BlockedError)) throw error;
  306 |     missing.push(String(error));
  307 |   }
  308 |   let lastAcknowledgedSampleToExitMs: Bounds | null = null;
  309 |   const sample = old.last.lastSuccessfulSample;
  310 |   try {
  311 |     need(sample?.epochId === old.id, '未保留最后已确认采样');
  312 |     const point = observationInterval(sample.windowMs);
  313 |     need(point[0] >= old.start[0] && point[1] <= old.clock.monotonicMs, '最后确认采样不在原epoch');
  314 |     lastAcknowledgedSampleToExitMs = span(mapped(point, offset), exitWindow);
  315 |   } catch (error) {
  316 |     if (!(error instanceof BlockedError)) throw error;
  317 |     missing.push(String(error));
  318 |   }
  319 |   // A terminal witness may bracket finish/COMMIT, not the prior stop decision.
  320 |   // Never use that late lower endpoint as proof execution continued until then.
  321 |   const decisions = input.recoveredLifecycle.filter((e) => e.kind === 'agent-termination-decided');
  322 |   const commits = input.recoveredLifecycle.filter((e) => e.kind === 'agent-terminal-committed');
  323 |   let stopDecision: RuntimeEvent | null = null;
  324 |   let stopWindow: Bounds | null = null;
  325 |   try {
  326 |     need(decisions.length === 1, '缺唯一真实停止决定');
  327 |     const decision = decisions[0]!;
  328 |     need(
  329 |       decision.runId === next.last.runId &&
  330 |         decision.groupId === next.last.groupId &&
  331 |         decision.applicationPid === next.clock.applicationPid &&
  332 |         decision.clockDomain === next.clock.clockDomain,
  333 |       '停止决定没有关联本run实际应用时钟',
  334 |     );
```