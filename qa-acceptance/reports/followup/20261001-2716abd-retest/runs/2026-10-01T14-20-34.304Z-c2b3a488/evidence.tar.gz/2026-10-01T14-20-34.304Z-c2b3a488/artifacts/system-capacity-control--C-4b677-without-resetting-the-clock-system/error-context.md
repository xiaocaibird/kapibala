# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/capacity-control.spec.ts >> [CAP-003] persistent admission refusal consumes the original active budget without resetting the clock
- Location: tests/system/capacity-control.spec.ts:350:1

# Error details

```
BlockedError: [BLOCKED] capacity actual activity budget: [BLOCKED] 活动真值区间跨越60秒上限；不能证明上限符合，不引入尾差容忍; capacity actual stop decision: [BLOCKED] 实际停止决定区间跨60000ms，不能用公开终态或提交时间补证
```

# Test source

```ts
  373 |           const requestBefore = performance.now();
  374 |           const current = await qa.api.agentRun(kick.runId);
  375 |           const responseAfter = performance.now();
  376 |           publicSamples.push({
  377 |             requestBefore,
  378 |             responseAfter,
  379 |             status: current.status,
  380 |             endReason: current.endReason,
  381 |           });
  382 |           if (current.status === 'running') {
  383 |             expect(firstTerminalResponseAfter, '已公开的终态不能重新变为running').toBeUndefined();
  384 |             lastRunningRequestBefore = requestBefore;
  385 |           } else firstTerminalResponseAfter ??= responseAfter;
  386 |           return current;
  387 |         };
  388 |         await samplePublicRun();
  389 |         const snapshot = await lease.waitFor(
  390 |           (value) => value.events.some((event) => event.kind === 'run-terminal'),
  391 |           {
  392 |             timeoutMs: 65_000,
  393 |             inspect: async () => {
  394 |               noKick(qa, kick);
  395 |               onceAudited(qa, kick);
  396 |               await samplePublicRun();
  397 |             },
  398 |           },
  399 |         );
  400 |         const end = snapshot.events.find((event) => event.kind === 'run-terminal')!;
  401 |         expect(end.status).toBe('failed');
  402 |         expect(end.endReason).toBe('wall_clock');
  403 |         const run = await eventually(samplePublicRun, (current) => current.status !== 'running', {
  404 |           timeoutMs: 30_000,
  405 |         });
  406 |         expect(run).toMatchObject({ id: kick.runId, status: 'failed', endReason: 'wall_clock' });
  407 |         expect((await qa.api.group(kick.group.id)).activeAgentRunId).toBeNull();
  408 |         expect(
  409 |           run.steps.filter((step) => step.toolUseId === kick.toolUseId).length,
  410 |         ).toBeLessThanOrEqual(1);
  411 |         const activitySnapshot =
  412 |           activity &&
  413 |           (await optionalActivityObservation(
  414 |             'capacity complete activity witness',
  415 |             () => activity!.waitFor('activity-terminal', 5_000),
  416 |             missing,
  417 |           ));
  418 |         const lifecycleSnapshot =
  419 |           lifecycle &&
  420 |           (await optionalActivityObservation(
  421 |             'capacity actual decision and COMMIT',
  422 |             () => lifecycle!.waitFor('agent-terminal-committed', 5_000),
  423 |             missing,
  424 |           ));
  425 |         // Public visibility includes COMMIT, polling and network delay. Its lower
  426 |         // bound cannot establish activity duration or constrain the stop decision.
  427 |         const independentOnline: [number, number] = [
  428 |           0,
  429 |           firstTerminalResponseAfter! - creationBounds[0],
  430 |         ];
  431 |         await qa.evidence('capacity-active-budget', {
  432 |           capacitySampleOnly: end.activeElapsedMs,
  433 |           diagnostic: end,
  434 |           requiredMaximumMs: 60_000,
  435 |           creationBounds,
  436 |           publicSamples,
  437 |           lastRunningRequestBefore,
  438 |           independentOnline,
  439 |           activity: activitySnapshot ?? activity?.latest ?? null,
  440 |           lifecycle: lifecycleSnapshot ?? lifecycle?.latest ?? null,
  441 |           missing,
  442 |           limit:
  443 |             'capacity持久采样/公开终态仅诊断；真实完整活动和同attempt决定/COMMIT分别裁判。公开下界不作为决定下界，不强制区间相交，也不增设60秒下限。',
  444 |         });
  445 |         // Missing runtime evidence cannot skip already observable business facts.
  446 |         await lease.release();
  447 |         await observeNoLateKick(
  448 |           qa,
  449 |           kick,
  450 |           { status: run.status, endReason: run.endReason },
  451 |           { requests: 0, effects: 0, turns: 1 },
  452 |         );
  453 |         await captureKickEvidence(qa, 'capacity-budget-final', [kick]);
  454 |         const actualActivity = (activitySnapshot ?? activity?.latest)?.events ?? [];
  455 |         const actualLifecycle = (lifecycleSnapshot ?? lifecycle?.latest)?.events ?? [];
  456 |         // Defer only BLOCKED; a hard violation in either complete stream survives
  457 |         // missing evidence in the other stream.
  458 |         await optionalActivityObservation(
  459 |           'capacity actual activity budget',
  460 |           async () => {
  461 |             assertSingleEpochActivityBudget(actualActivity, independentOnline, run.endReason!);
  462 |           },
  463 |           missing,
  464 |         );
  465 |         await optionalActivityObservation(
  466 |           'capacity actual stop decision',
  467 |           async () => {
  468 |             const decision = assertSingleEpochLifecycleBudget(actualActivity, actualLifecycle);
  469 |             await qa.evidence('capacity-lifecycle-budget', decision);
  470 |           },
  471 |           missing,
  472 |         );
> 473 |         if (missing.length) throw new BlockedError(missing.join('; '));
      |                                   ^ BlockedError: [BLOCKED] capacity actual activity budget: [BLOCKED] 活动真值区间跨越60秒上限；不能证明上限符合，不引入尾差容忍; capacity actual stop decision: [BLOCKED] 实际停止决定区间跨60000ms，不能用公开终态或提交时间补证
  474 |       },
  475 |       {
  476 |         clock: true,
  477 |         beforeAdmissionHold: async (kick) => {
  478 |           const verified = await optionalActivityObservation(
  479 |             'verify capacity activity observer',
  480 |             async () => {
  481 |               runtime = runtimeObservationFor(qa);
  482 |               await runtime.verify(['activity-witness']);
  483 |               return runtime;
  484 |             },
  485 |             missing,
  486 |           );
  487 |           if (verified)
  488 |             activity = await optionalActivityObservation(
  489 |               'observe original capacity run activity',
  490 |               () =>
  491 |                 verified.arm('observe-activity', {
  492 |                   kind: 'activity',
  493 |                   groupId: kick.group.id,
  494 |                   runId: kick.runId,
  495 |                   toolUseId: 'all-run-steps',
  496 |                 }),
  497 |               missing,
  498 |             );
  499 |           if (verified)
  500 |             lifecycle = await optionalActivityObservation(
  501 |               'observe original capacity run lifecycle',
  502 |               async () => {
  503 |                 await verified.verify(['agent-lifecycle-witness']);
  504 |                 return verified.arm('observe-agent-lifecycle', {
  505 |                   kind: 'tool-wait',
  506 |                   groupId: kick.group.id,
  507 |                   runId: kick.runId,
  508 |                   toolUseId: 'all-run-steps',
  509 |                 });
  510 |               },
  511 |               missing,
  512 |             );
  513 |         },
  514 |       },
  515 |     );
  516 |   } catch (error) {
  517 |     primaryFailure = error;
  518 |     throw error;
  519 |   } finally {
  520 |     try {
  521 |       await runtime?.close();
  522 |     } catch (cleanup) {
  523 |       try {
  524 |         await qa.evidence('capacity-runtime-cleanup-failure', {
  525 |           error: String(cleanup),
  526 |           primaryFailure: String(primaryFailure),
  527 |         });
  528 |       } catch {
  529 |         /* Preserve the first failure. */
  530 |       }
  531 |       if (!primaryFailure) throw cleanup;
  532 |     }
  533 |   }
  534 | });
  535 | 
  536 | test('[CAP-004] policy is rechecked after confirmed zero-effect admission deferral', async ({
  537 |   qa,
  538 | }) => {
  539 |   await deferred(qa, 'capacity-policy', async (kick, lease) => {
  540 |     await qa.api.require(qa.api.patch(`/api/groups/${kick.group.id}`, { autoKickEnabled: false }));
  541 |     expect((await qa.api.group(kick.group.id)).autoKickEnabled).toBe(false);
  542 |     await lease.release();
  543 |     finalStep(qa, kick, await terminal(qa, kick), 'POLICY_DENIED');
  544 |     noKick(qa, kick);
  545 |     expect(targetIsPresent(qa, kick)).toBe(true);
  546 |     await captureKickEvidence(qa, 'capacity-policy-final', [kick]);
  547 |   });
  548 | });
  549 | 
  550 | test('[CAP-005] group unreachability during admission wait cancels without a late kick', async ({
  551 |   qa,
  552 | }) => {
  553 |   let staged: { clientMsgId: string; eventId: number } | undefined;
  554 |   try {
  555 |     await deferred(
  556 |       qa,
  557 |       'capacity-unreachable',
  558 |       async (kick, lease, _control, creationBounds) => {
  559 |         if (!staged) throw new Error('QA accepted-failure setup was not recorded');
  560 |         const { clientMsgId, eventId } = staged;
  561 |         await held(lease, '补投真实群不可写事件前');
  562 |         noKick(qa, kick);
  563 |         expect(qa.gateway.snapshot().connectedStreams).toBe(0);
  564 |         if ((await qa.api.group(kick.group.id)).status !== 'active')
  565 |           throw new BlockedError('恢复SSE前群已不再active，未命中容量拒绝后才处理失败事件的窗口');
  566 |         // The send was accepted before saturation. Restore retained SSE history;
  567 |         // do not release capacity or invent a failure for work still queued locally.
  568 |         qa.gateway.configure({ sseUnavailable: false });
  569 |         const observation = await observe({
  570 |           read: async () => ({
  571 |             group: await qa.api.group(kick.group.id),
  572 |             messages: await qa.api.messages(kick.group.id),
  573 |           }),
```