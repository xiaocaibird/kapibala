# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/agent.spec.ts >> [AGENT-025] run stays within sixty-second active wall-clock budget including slow turns
- Location: tests/system/agent.spec.ts:787:1

# Error details

```
AssertionError: 活动预算已证明超过原始60秒上限
```

# Test source

```ts
  1  | import assert from 'node:assert/strict';
  2  | import { BlockedError } from '../../harness/security.js';
  3  | import {
  4  |   assertAgentLifecycle,
  5  |   assertNoDispatchAfterStop,
  6  | } from '../../harness/lifecycle-observation.js';
  7  | import {
  8  |   assertActivityBudget,
  9  |   assertNoRecoveryPause,
  10 |   type RuntimeEvent,
  11 | } from '../../harness/runtime-observation.js';
  12 | 
  13 | /** Missing observation cannot prevent the caller checking public behavior.
  14 |  * Only evidence-unavailable errors are deferred; real assertion failures survive. */
  15 | export async function optionalActivityObservation<T>(
  16 |   stage: string,
  17 |   read: () => Promise<T>,
  18 |   missing: string[],
  19 | ): Promise<T | undefined> {
  20 |   try {
  21 |     return await read();
  22 |   } catch (error) {
  23 |     if (!(error instanceof BlockedError)) throw error;
  24 |     missing.push(`${stage}: ${error.message}`);
  25 |     return undefined;
  26 |   }
  27 | }
  28 | 
  29 | /** Input events already passed RuntimeLease's owner, run and append-only checks.
  30 |  * This no-restart scenario requires true whole-run, single-epoch observation. */
  31 | export function assertSingleEpochActivityBudget(
  32 |   events: readonly RuntimeEvent[],
  33 |   online: [number, number],
  34 |   endReason: string,
  35 | ): void {
  36 |   assertNoRecoveryPause(events);
  37 |   if (!online.every((value) => Number.isFinite(value) && value >= 0) || online[0] > online[1])
  38 |     throw new BlockedError('独立在线区间无效');
  39 |   // A missing terminal or an incomplete later sample cannot hide an already
  40 |   // proved violation. Online time supplies an upper bound, never activity truth.
  41 |   for (const event of events) {
  42 |     if (!event.includesUnsavedTail || !event.activeElapsedMs) continue;
  43 |     assert.ok(event.activeElapsedMs[0] <= online[1], '活动下界超过独立在线上界，证据矛盾');
> 44 |     assert.ok(event.activeElapsedMs[0] <= 60_000, '活动预算已证明超过原始60秒上限');
     |            ^ AssertionError: 活动预算已证明超过原始60秒上限
  45 |   }
  46 |   const terminal = events.findLast((event) => event.kind === 'activity-terminal');
  47 |   if (!terminal) throw new BlockedError('缺少真实活动终止边界，REST轮询区间不替代活动见证');
  48 |   const epochs = new Set(events.flatMap((event) => event.epochIds ?? []));
  49 |   if (epochs.size !== 1 || terminal.epochIds?.length !== 1)
  50 |     throw new BlockedError('本例缺少完整单epoch创建至终止关联；不推算遗漏或多个所有权段');
  51 |   assertActivityBudget(terminal, online, 60_000, endReason);
  52 | }
  53 | 
  54 | /** Both streams already passed RuntimeLease identity/history validation. A
  55 |  * public terminal observation or persisted active_ms is not a stop decision. */
  56 | export function assertSingleEpochLifecycleBudget(
  57 |   activity: readonly RuntimeEvent[],
  58 |   lifecycle: readonly RuntimeEvent[],
  59 | ) {
  60 |   assertNoDispatchAfterStop(lifecycle);
  61 |   assertNoRecoveryPause(activity);
  62 |   const created = lifecycle.find((event) => event.kind === 'agent-run-created');
  63 |   const actual = activity.filter((event) =>
  64 |     ['activity-checkpoint', 'activity-terminal'].includes(event.kind),
  65 |   );
  66 |   const terminal = actual.findLast((event) => event.kind === 'activity-terminal');
  67 |   // includesUnsavedTail=true is a reviewed continuous-boundary guarantee, not
  68 |   // an inference from a few active samples (engineering witness doc §§3–4).
  69 |   if (
  70 |     !created?.clockDomain ||
  71 |     !created.applicationPid ||
  72 |     !terminal?.includesUnsavedTail ||
  73 |     terminal.epochIds?.length !== 1 ||
  74 |     !actual.every(
  75 |       (event) =>
  76 |         event.clockDomain === created.clockDomain &&
  77 |         event.applicationPid === created.applicationPid &&
  78 |         event.runId === created.runId &&
  79 |         event.groupId === created.groupId &&
  80 |         event.includesUnsavedTail &&
  81 |         event.epochIds?.length === 1 &&
  82 |         event.epochIds[0] === terminal.epochIds![0] &&
  83 |         ['active', 'terminal'].includes(String(event.activityState)),
  84 |     )
  85 |   )
  86 |     throw new BlockedError(
  87 |       '缺少同run/进程时钟域完整连续单epoch活动来源，不能以在线或持久采样替代决定',
  88 |     );
  89 |   return assertAgentLifecycle(lifecycle);
  90 | }
  91 | 
```