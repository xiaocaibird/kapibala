# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui/console.spec.ts >> [UI-017] 多页过期禁止旧游标，失败保留列表，成功整体换首页
- Location: tests/ui/console.spec.ts:695:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('a[data-directory-group-id]')
Expected: 23
Received: 20
Timeout:  8000ms

Call log:
  - Expect "toHaveCount" locator('a[data-directory-group-id]') with timeout 8000ms
  - waiting for locator('a[data-directory-group-id]')
    20 × locator resolved to 20 elements
       - unexpected value "20"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - link "K kapibala ." [ref=e5] [cursor=pointer]:
      - /url: "#/groups"
      - generic [ref=e6]: K
      - text: kapibala
      - generic [ref=e7]: .
    - generic [ref=e8]: 工作空间
    - navigation [ref=e9]:
      - link "群组工作台" [ref=e10] [cursor=pointer]:
        - /url: "#/groups"
      - link "服务账号" [ref=e15] [cursor=pointer]:
        - /url: "#/accounts"
      - link "Agent 运行" [ref=e20] [cursor=pointer]:
        - /url: "#/agent-runs"
      - link "定时序列" [ref=e24] [cursor=pointer]:
        - /url: "#/sequences"
    - generic [ref=e31]:
      - generic [ref=e39]:
        - strong [ref=e40]: 消息运营平台
        - generic [ref=e41]: 本地工作空间
      - generic [ref=e42]:
        - generic [ref=e43]: A
        - generic [ref=e44]:
          - strong [ref=e45]: admin
          - generic [ref=e46]: 管理员
        - button "退出登录" [ref=e47] [cursor=pointer]
  - generic [ref=e50]:
    - generic [ref=e51]:
      - generic [ref=e52]:
        - text: 工作空间
        - generic [ref=e53]: /
        - strong [ref=e54]: 群组工作台
      - status [ref=e56]: 连接恢复中
    - main [ref=e58]:
      - generic [ref=e59]: 实时连接已断开，正在自动重连并补齐期间的变化。
      - generic [ref=e60]:
        - generic [ref=e61]:
          - generic [ref=e62]: GROUP WORKSPACE
          - heading "群组工作台" [level=1] [ref=e63]
          - paragraph [ref=e64]: 按创建时间浏览群组，或搜索名称、简介和群 ID。
        - button "创建群组" [ref=e66] [cursor=pointer]
      - region "群列表查找、筛选与排序" [ref=e69]:
        - generic [ref=e70]:
          - text: 搜索群组
          - searchbox "搜索群组" [ref=e71]
        - button "清除搜索" [disabled] [ref=e72]
        - generic [ref=e73]:
          - text: 群状态
          - combobox "群状态" [ref=e74]:
            - option "全部" [selected]
            - option "可用"
            - option "不可写"
            - option "已退出"
        - generic [ref=e75]:
          - text: Agent 自动应答
          - combobox "Agent 自动应答" [ref=e76]:
            - option "全部" [selected]
            - option "开启"
            - option "关闭"
        - generic [ref=e77]:
          - text: 创建时间
          - combobox "创建时间" [ref=e78]:
            - option "新到旧" [selected]
            - option "旧到新"
        - button "重置条件" [disabled] [ref=e79]
        - button "刷新列表" [ref=e80] [cursor=pointer]
        - paragraph [ref=e83]: 搜索与筛选完整群目录；关键词忽略首尾空白与英文大小写，按整段匹配。
      - generic [ref=e84]:
        - heading "所有群组" [level=2] [ref=e85]
        - generic [ref=e86]: 已加载 20 个群 · 还有更多
      - generic [ref=e87]:
        - link "可用 目录-22 网关 ID · gateway-group-23 创建于 2026/10/01 22:16:03 3 位成员 Agent 未开启 查看群组详情" [ref=e88] [cursor=pointer]:
          - /url: "#/groups/e603a0d1-1403-4678-a2c8-ec820b7d9725"
          - generic [ref=e89]: 可用
          - heading "目录-22" [level=3] [ref=e95]
          - generic "gateway-group-23" [ref=e96]: 网关 ID · gateway-group-23
          - generic [ref=e97]:
            - text: 创建于
            - time [ref=e98]: 2026/10/01 22:16:03
          - generic [ref=e99]:
            - generic [ref=e100]: 3 位成员
            - generic [ref=e104]: Agent 未开启
          - generic [ref=e106]: 查看群组详情
        - link "可用 目录-21 网关 ID · gateway-group-22 创建于 2026/10/01 22:16:03 3 位成员 Agent 未开启 查看群组详情" [ref=e110] [cursor=pointer]:
          - /url: "#/groups/2b14d337-549e-4048-a861-70abed20d2f1"
          - generic [ref=e111]: 可用
          - heading "目录-21" [level=3] [ref=e117]
          - generic "gateway-group-22" [ref=e118]: 网关 ID · gateway-group-22
          - generic [ref=e119]:
            - text: 创建于
            - time [ref=e120]: 2026/10/01 22:16:03
          - generic [ref=e121]:
            - generic [ref=e122]: 3 位成员
            - generic [ref=e126]: Agent 未开启
          - generic [ref=e128]: 查看群组详情
        - link "可用 目录-20 网关 ID · gateway-group-21 创建于 2026/10/01 22:16:02 3 位成员 Agent 未开启 查看群组详情" [ref=e132] [cursor=pointer]:
          - /url: "#/groups/787aa4d2-0e8e-4102-991c-35bc63928914"
          - generic [ref=e133]: 可用
          - heading "目录-20" [level=3] [ref=e139]
          - generic "gateway-group-21" [ref=e140]: 网关 ID · gateway-group-21
          - generic [ref=e141]:
            - text: 创建于
            - time [ref=e142]: 2026/10/01 22:16:02
          - generic [ref=e143]:
            - generic [ref=e144]: 3 位成员
            - generic [ref=e148]: Agent 未开启
          - generic [ref=e150]: 查看群组详情
        - link "可用 目录-19 网关 ID · gateway-group-20 创建于 2026/10/01 22:16:01 3 位成员 Agent 未开启 查看群组详情" [ref=e154] [cursor=pointer]:
          - /url: "#/groups/28747cb5-bee6-404f-8c6a-ed9dfe5d5bf8"
          - generic [ref=e155]: 可用
          - heading "目录-19" [level=3] [ref=e161]
          - generic "gateway-group-20" [ref=e162]: 网关 ID · gateway-group-20
          - generic [ref=e163]:
            - text: 创建于
            - time [ref=e164]: 2026/10/01 22:16:01
          - generic [ref=e165]:
            - generic [ref=e166]: 3 位成员
            - generic [ref=e170]: Agent 未开启
          - generic [ref=e172]: 查看群组详情
        - link "可用 目录-18 网关 ID · gateway-group-19 创建于 2026/10/01 22:16:00 3 位成员 Agent 未开启 查看群组详情" [ref=e176] [cursor=pointer]:
          - /url: "#/groups/f3b71369-8031-4ff1-ad63-ce251d9a65ef"
          - generic [ref=e177]: 可用
          - heading "目录-18" [level=3] [ref=e183]
          - generic "gateway-group-19" [ref=e184]: 网关 ID · gateway-group-19
          - generic [ref=e185]:
            - text: 创建于
            - time [ref=e186]: 2026/10/01 22:16:00
          - generic [ref=e187]:
            - generic [ref=e188]: 3 位成员
            - generic [ref=e192]: Agent 未开启
          - generic [ref=e194]: 查看群组详情
        - link "可用 目录-17 网关 ID · gateway-group-18 创建于 2026/10/01 22:15:59 3 位成员 Agent 未开启 查看群组详情" [ref=e198] [cursor=pointer]:
          - /url: "#/groups/7991ceb6-b2e8-469b-baac-81f52a4d7428"
          - generic [ref=e199]: 可用
          - heading "目录-17" [level=3] [ref=e205]
          - generic "gateway-group-18" [ref=e206]: 网关 ID · gateway-group-18
          - generic [ref=e207]:
            - text: 创建于
            - time [ref=e208]: 2026/10/01 22:15:59
          - generic [ref=e209]:
            - generic [ref=e210]: 3 位成员
            - generic [ref=e214]: Agent 未开启
          - generic [ref=e216]: 查看群组详情
        - link "可用 目录-16 网关 ID · gateway-group-17 创建于 2026/10/01 22:15:58 3 位成员 Agent 未开启 查看群组详情" [ref=e220] [cursor=pointer]:
          - /url: "#/groups/354c3103-4fe4-4837-bdc0-b813ae8f2ade"
          - generic [ref=e221]: 可用
          - heading "目录-16" [level=3] [ref=e227]
          - generic "gateway-group-17" [ref=e228]: 网关 ID · gateway-group-17
          - generic [ref=e229]:
            - text: 创建于
            - time [ref=e230]: 2026/10/01 22:15:58
          - generic [ref=e231]:
            - generic [ref=e232]: 3 位成员
            - generic [ref=e236]: Agent 未开启
          - generic [ref=e238]: 查看群组详情
        - link "可用 目录-15 网关 ID · gateway-group-16 创建于 2026/10/01 22:15:57 3 位成员 Agent 未开启 查看群组详情" [ref=e242] [cursor=pointer]:
          - /url: "#/groups/d27c6664-d76f-4b2f-ad2b-b9c348173ab7"
          - generic [ref=e243]: 可用
          - heading "目录-15" [level=3] [ref=e249]
          - generic "gateway-group-16" [ref=e250]: 网关 ID · gateway-group-16
          - generic [ref=e251]:
            - text: 创建于
            - time [ref=e252]: 2026/10/01 22:15:57
          - generic [ref=e253]:
            - generic [ref=e254]: 3 位成员
            - generic [ref=e258]: Agent 未开启
          - generic [ref=e260]: 查看群组详情
        - link "可用 目录-14 网关 ID · gateway-group-15 创建于 2026/10/01 22:15:56 3 位成员 Agent 未开启 查看群组详情" [ref=e264] [cursor=pointer]:
          - /url: "#/groups/d79ee499-bfad-4eb1-9c46-a1f8a326de19"
          - generic [ref=e265]: 可用
          - heading "目录-14" [level=3] [ref=e271]
          - generic "gateway-group-15" [ref=e272]: 网关 ID · gateway-group-15
          - generic [ref=e273]:
            - text: 创建于
            - time [ref=e274]: 2026/10/01 22:15:56
          - generic [ref=e275]:
            - generic [ref=e276]: 3 位成员
            - generic [ref=e280]: Agent 未开启
          - generic [ref=e282]: 查看群组详情
        - link "可用 目录-13 网关 ID · gateway-group-14 创建于 2026/10/01 22:15:55 3 位成员 Agent 未开启 查看群组详情" [ref=e286] [cursor=pointer]:
          - /url: "#/groups/1ac14d13-2613-49cd-9fd9-a006a1428a27"
          - generic [ref=e287]: 可用
          - heading "目录-13" [level=3] [ref=e293]
          - generic "gateway-group-14" [ref=e294]: 网关 ID · gateway-group-14
          - generic [ref=e295]:
            - text: 创建于
            - time [ref=e296]: 2026/10/01 22:15:55
          - generic [ref=e297]:
            - generic [ref=e298]: 3 位成员
            - generic [ref=e302]: Agent 未开启
          - generic [ref=e304]: 查看群组详情
        - link "可用 目录-12 网关 ID · gateway-group-13 创建于 2026/10/01 22:15:54 3 位成员 Agent 未开启 查看群组详情" [ref=e308] [cursor=pointer]:
          - /url: "#/groups/fd0cb1e5-4c31-4399-a124-6d3ee9c7a824"
          - generic [ref=e309]: 可用
          - heading "目录-12" [level=3] [ref=e315]
          - generic "gateway-group-13" [ref=e316]: 网关 ID · gateway-group-13
          - generic [ref=e317]:
            - text: 创建于
            - time [ref=e318]: 2026/10/01 22:15:54
          - generic [ref=e319]:
            - generic [ref=e320]: 3 位成员
            - generic [ref=e324]: Agent 未开启
          - generic [ref=e326]: 查看群组详情
        - link "可用 目录-11 网关 ID · gateway-group-12 创建于 2026/10/01 22:15:53 3 位成员 Agent 未开启 查看群组详情" [ref=e330] [cursor=pointer]:
          - /url: "#/groups/ac8a437a-d2c0-4eba-943b-18926ac39026"
          - generic [ref=e331]: 可用
          - heading "目录-11" [level=3] [ref=e337]
          - generic "gateway-group-12" [ref=e338]: 网关 ID · gateway-group-12
          - generic [ref=e339]:
            - text: 创建于
            - time [ref=e340]: 2026/10/01 22:15:53
          - generic [ref=e341]:
            - generic [ref=e342]: 3 位成员
            - generic [ref=e346]: Agent 未开启
          - generic [ref=e348]: 查看群组详情
        - link "可用 目录-10 网关 ID · gateway-group-11 创建于 2026/10/01 22:15:53 3 位成员 Agent 未开启 查看群组详情" [ref=e352] [cursor=pointer]:
          - /url: "#/groups/a5a7ce5a-3985-47e9-9c15-644b1c7c1825"
          - generic [ref=e353]: 可用
          - heading "目录-10" [level=3] [ref=e359]
          - generic "gateway-group-11" [ref=e360]: 网关 ID · gateway-group-11
          - generic [ref=e361]:
            - text: 创建于
            - time [ref=e362]: 2026/10/01 22:15:53
          - generic [ref=e363]:
            - generic [ref=e364]: 3 位成员
            - generic [ref=e368]: Agent 未开启
          - generic [ref=e370]: 查看群组详情
        - link "可用 目录-9 网关 ID · gateway-group-10 创建于 2026/10/01 22:15:52 3 位成员 Agent 未开启 查看群组详情" [ref=e374] [cursor=pointer]:
          - /url: "#/groups/7b37244e-8b41-42f3-af40-fbe856fe32f0"
          - generic [ref=e375]: 可用
          - heading "目录-9" [level=3] [ref=e381]
          - generic "gateway-group-10" [ref=e382]: 网关 ID · gateway-group-10
          - generic [ref=e383]:
            - text: 创建于
            - time [ref=e384]: 2026/10/01 22:15:52
          - generic [ref=e385]:
            - generic [ref=e386]: 3 位成员
            - generic [ref=e390]: Agent 未开启
          - generic [ref=e392]: 查看群组详情
        - link "可用 目录-8 网关 ID · gateway-group-9 创建于 2026/10/01 22:15:51 3 位成员 Agent 未开启 查看群组详情" [ref=e396] [cursor=pointer]:
          - /url: "#/groups/b3f84d05-1437-4cd0-a143-91c7824b5017"
          - generic [ref=e397]: 可用
          - heading "目录-8" [level=3] [ref=e403]
          - generic "gateway-group-9" [ref=e404]: 网关 ID · gateway-group-9
          - generic [ref=e405]:
            - text: 创建于
            - time [ref=e406]: 2026/10/01 22:15:51
          - generic [ref=e407]:
            - generic [ref=e408]: 3 位成员
            - generic [ref=e412]: Agent 未开启
          - generic [ref=e414]: 查看群组详情
        - link "可用 目录-7 网关 ID · gateway-group-8 创建于 2026/10/01 22:15:50 3 位成员 Agent 未开启 查看群组详情" [ref=e418] [cursor=pointer]:
          - /url: "#/groups/94d28bcd-d7e4-4a82-a93d-2584ee99e3ac"
          - generic [ref=e419]: 可用
          - heading "目录-7" [level=3] [ref=e425]
          - generic "gateway-group-8" [ref=e426]: 网关 ID · gateway-group-8
          - generic [ref=e427]:
            - text: 创建于
            - time [ref=e428]: 2026/10/01 22:15:50
          - generic [ref=e429]:
            - generic [ref=e430]: 3 位成员
            - generic [ref=e434]: Agent 未开启
          - generic [ref=e436]: 查看群组详情
        - link "可用 目录-6 网关 ID · gateway-group-7 创建于 2026/10/01 22:15:49 3 位成员 Agent 未开启 查看群组详情" [ref=e440] [cursor=pointer]:
          - /url: "#/groups/4a36fdca-ad33-4f4c-9ad0-f1eb84d36987"
          - generic [ref=e441]: 可用
          - heading "目录-6" [level=3] [ref=e447]
          - generic "gateway-group-7" [ref=e448]: 网关 ID · gateway-group-7
          - generic [ref=e449]:
            - text: 创建于
            - time [ref=e450]: 2026/10/01 22:15:49
          - generic [ref=e451]:
            - generic [ref=e452]: 3 位成员
            - generic [ref=e456]: Agent 未开启
          - generic [ref=e458]: 查看群组详情
        - link "可用 目录-5 网关 ID · gateway-group-6 创建于 2026/10/01 22:15:48 3 位成员 Agent 未开启 查看群组详情" [ref=e462] [cursor=pointer]:
          - /url: "#/groups/1effa7e0-4dc4-472e-91bd-3fc4b90fa528"
          - generic [ref=e463]: 可用
          - heading "目录-5" [level=3] [ref=e469]
          - generic "gateway-group-6" [ref=e470]: 网关 ID · gateway-group-6
          - generic [ref=e471]:
            - text: 创建于
            - time [ref=e472]: 2026/10/01 22:15:48
          - generic [ref=e473]:
            - generic [ref=e474]: 3 位成员
            - generic [ref=e478]: Agent 未开启
          - generic [ref=e480]: 查看群组详情
        - link "可用 目录-4 网关 ID · gateway-group-5 创建于 2026/10/01 22:15:47 3 位成员 Agent 未开启 查看群组详情" [ref=e484] [cursor=pointer]:
          - /url: "#/groups/9e783fd7-0c83-42e1-abe8-d1a37c98028b"
          - generic [ref=e485]: 可用
          - heading "目录-4" [level=3] [ref=e491]
          - generic "gateway-group-5" [ref=e492]: 网关 ID · gateway-group-5
          - generic [ref=e493]:
            - text: 创建于
            - time [ref=e494]: 2026/10/01 22:15:47
          - generic [ref=e495]:
            - generic [ref=e496]: 3 位成员
            - generic [ref=e500]: Agent 未开启
          - generic [ref=e502]: 查看群组详情
        - link "可用 目录-3 网关 ID · gateway-group-4 创建于 2026/10/01 22:15:46 3 位成员 Agent 未开启 查看群组详情" [ref=e506] [cursor=pointer]:
          - /url: "#/groups/93dda0ef-9399-4033-bb6f-219c4dc516e8"
          - generic [ref=e507]: 可用
          - heading "目录-3" [level=3] [ref=e513]
          - generic "gateway-group-4" [ref=e514]: 网关 ID · gateway-group-4
          - generic [ref=e515]:
            - text: 创建于
            - time [ref=e516]: 2026/10/01 22:15:46
          - generic [ref=e517]:
            - generic [ref=e518]: 3 位成员
            - generic [ref=e522]: Agent 未开启
          - generic [ref=e524]: 查看群组详情
      - generic [ref=e528]:
        - button "加载更多" [ref=e529] [cursor=pointer]
        - generic [ref=e530]: 每次最多加载 20 个群
      - generic [ref=e531]:
        - generic [ref=e532]: Kapibala Console
        - generic [ref=e533]: 状态有记录，执行可追踪。
```

# Test source

```ts
  607 |     }
  608 |     requests++;
  609 |     await held;
  610 |     await route.fulfill({
  611 |       status: 503,
  612 |       contentType: 'application/json',
  613 |       body: JSON.stringify({
  614 |         error: { code: 'SERVICE_UNAVAILABLE', message: 'QA fault', requestId: 'qa-ui-save' },
  615 |       }),
  616 |     });
  617 |   });
  618 |   try {
  619 |     await element(page, qa, 'saveProfile').click();
  620 |     await expect.poll(() => requests).toBe(1);
  621 |     await element(page, qa, 'saveProfile').click({ force: true });
  622 |     await page.keyboard.press('Escape');
  623 |     await expect(element(page, qa, 'profileDialog')).toBeVisible();
  624 |     release();
  625 |     await expect(element(page, qa, 'saveProfile')).toBeEnabled();
  626 |     await expect(element(page, qa, 'groupName')).toHaveValue('保留草稿');
  627 |     await remains(async () => expect(requests).toBe(1));
  628 |   } finally {
  629 |     release();
  630 |     await page.unrouteAll({ behavior: 'wait' });
  631 |   }
  632 | });
  633 | test('[UI-015] 同字段冲突保留草稿，明确再确认才提交', async ({ qa, page }) => {
  634 |   const group = await prepare(qa);
  635 |   await qa.api.require(qa.api.patch(`/api/groups/${group.id}`, { name: '最初' }));
  636 |   await login(page, qa);
  637 |   await go(page, qa, 'group', group.id);
  638 |   await element(page, qa, 'editProfile').click();
  639 |   await element(page, qa, 'groupName').fill('我的草稿');
  640 |   await qa.api.require(qa.api.patch(`/api/groups/${group.id}`, { name: '服务器新版' }));
  641 |   const response = page.waitForResponse((r) => r.request().method() === 'PATCH');
  642 |   await element(page, qa, 'saveProfile').click();
  643 |   expect((await response).status()).toBe(409);
  644 |   await expect(element(page, qa, 'groupName')).toHaveValue('我的草稿');
  645 |   await expect(page.locator('body')).toContainText('服务器新版');
  646 |   expect(
  647 |     (await qa.api.require(qa.api.get<Group & { name: string }>(`/api/groups/${group.id}`))).name,
  648 |   ).toBe('服务器新版');
  649 |   await element(page, qa, 'confirmConflict').click();
  650 |   await expect
  651 |     .poll(
  652 |       async () =>
  653 |         (await qa.api.require(qa.api.get<Group & { name: string }>(`/api/groups/${group.id}`)))
  654 |           .name,
  655 |     )
  656 |     .toBe('我的草稿');
  657 | });
  658 | test('[UI-016] 搜索旧响应不能覆盖新条件且不抢焦点', async ({ qa, page }) => {
  659 |   const old = await prepare(qa);
  660 |   await qa.api.require(qa.api.patch(`/api/groups/${old.id}`, { name: 'old-query' }));
  661 |   const { group: newGroup } = await qa.api.createGroup();
  662 |   await qa.api.require(qa.api.patch(`/api/groups/${newGroup.id}`, { name: 'new-query' }));
  663 |   await login(page, qa);
  664 |   await go(page, qa, 'groups');
  665 |   let release!: () => void;
  666 |   const hold = new Promise<void>((r) => (release = r));
  667 |   let seen = false;
  668 |   await page.route('**/api/group-directory?**', async (route) => {
  669 |     if (new URL(route.request().url()).searchParams.get('q') === 'old-query') {
  670 |       seen = true;
  671 |       const response = await route.fetch();
  672 |       await hold;
  673 |       await route.fulfill({ response });
  674 |     } else await route.continue();
  675 |   });
  676 |   try {
  677 |     const search = element(page, qa, 'search');
  678 |     await search.fill('old-query');
  679 |     await expect.poll(() => seen).toBe(true);
  680 |     await search.fill('new-query');
  681 |     await expect(element(page, qa, 'directoryItem')).toContainText('new-query');
  682 |     release();
  683 |     await remains(async () => {
  684 |       expect(await search.inputValue()).toBe('new-query');
  685 |       expect(await search.evaluate((e) => e === document.activeElement)).toBe(true);
  686 |       expect(await element(page, qa, 'directoryItem').allTextContents()).toEqual([
  687 |         expect.stringContaining('new-query'),
  688 |       ]);
  689 |     });
  690 |   } finally {
  691 |     release();
  692 |     await page.unrouteAll({ behavior: 'wait' });
  693 |   }
  694 | });
  695 | test('[UI-017] 多页过期禁止旧游标，失败保留列表，成功整体换首页', async ({ qa, page }) => {
  696 |   await qa.api.login();
  697 |   let first: Group | undefined;
  698 |   for (let i = 0; i < 23; i++) {
  699 |     const { group } = await qa.api.createGroup();
  700 |     first ??= group;
  701 |     await qa.api.require(qa.api.patch(`/api/groups/${group.id}`, { name: `目录-${i}` }));
  702 |   }
  703 |   await login(page, qa);
  704 |   await go(page, qa, 'groups');
  705 |   await expect(element(page, qa, 'directoryItem')).toHaveCount(20);
  706 |   await element(page, qa, 'loadMoreGroups').click();
> 707 |   await expect(element(page, qa, 'directoryItem')).toHaveCount(23);
      |                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  708 |   await qa.api.require(qa.api.patch(`/api/groups/${first!.id}`, { name: '变化名称' }));
  709 |   await expect(element(page, qa, 'directoryStale')).toBeVisible();
  710 |   const more = element(page, qa, 'loadMoreGroups');
  711 |   await expect.poll(async () => (await more.count()) === 0 || (await more.isDisabled())).toBe(true);
  712 |   let fail = true;
  713 |   await page.route('**/api/group-directory**', async (r) => {
  714 |     if (fail)
  715 |       await r.fulfill({
  716 |         status: 403,
  717 |         contentType: 'application/json',
  718 |         body: JSON.stringify({
  719 |           error: {
  720 |             code: 'FORBIDDEN',
  721 |             message: 'QA refresh failure',
  722 |             requestId: 'refresh',
  723 |           },
  724 |         }),
  725 |       });
  726 |     else await r.continue();
  727 |   });
  728 |   await element(page, qa, 'refreshDirectory').click();
  729 |   await expect(element(page, qa, 'directoryError')).toBeVisible();
  730 |   await expect(element(page, qa, 'directoryItem')).toHaveCount(23);
  731 |   fail = false;
  732 |   await element(page, qa, 'refreshDirectory').click();
  733 |   await expect(element(page, qa, 'directoryItem')).toHaveCount(20);
  734 |   await expect(element(page, qa, 'directoryStale')).toBeHidden();
  735 | });
  736 | test('[UI-018] 目录组合筛选、清关键词与重置含义不同', async ({ qa, page }) => {
  737 |   const group = await prepare(qa);
  738 |   await qa.api.require(
  739 |     qa.api.patch(`/api/groups/${group.id}`, { name: '查找我', agentEnabled: true }),
  740 |   );
  741 |   await login(page, qa);
  742 |   await go(page, qa, 'groups');
  743 |   await element(page, qa, 'search').fill('查找');
  744 |   await element(page, qa, 'order').selectOption('asc');
  745 |   await element(page, qa, 'statusFilter').selectOption('active');
  746 |   await element(page, qa, 'agentFilter').selectOption('true');
  747 |   await expect(element(page, qa, 'directoryItem')).toHaveCount(1);
  748 |   await element(page, qa, 'clearSearch').click();
  749 |   await expect(element(page, qa, 'search')).toHaveValue('');
  750 |   await expect(element(page, qa, 'order')).toHaveValue('asc');
  751 |   await expect(element(page, qa, 'agentFilter')).toHaveValue('true');
  752 |   await element(page, qa, 'resetFilters').click();
  753 |   await expect(element(page, qa, 'order')).toHaveValue('desc');
  754 |   await expect(element(page, qa, 'statusFilter')).toHaveValue('');
  755 |   await expect(element(page, qa, 'agentFilter')).toHaveValue('');
  756 | });
  757 | test('[UI-019] 初次失败可重试，成功空搜索不冒充加载错误', async ({ qa, page }) => {
  758 |   await prepare(qa);
  759 |   await login(page, qa);
  760 |   let fail = true;
  761 |   await page.route('**/api/group-directory**', async (r) => {
  762 |     if (fail)
  763 |       await r.fulfill({
  764 |         status: 403,
  765 |         contentType: 'application/json',
  766 |         body: JSON.stringify({
  767 |           error: {
  768 |             code: 'FORBIDDEN',
  769 |             message: 'QA first load failure',
  770 |             requestId: 'first',
  771 |           },
  772 |         }),
  773 |       });
  774 |     else await r.continue();
  775 |   });
  776 |   await go(page, qa, 'groups');
  777 |   await expect(element(page, qa, 'directoryError')).toBeVisible();
  778 |   fail = false;
  779 |   await element(page, qa, 'retryDirectory').click();
  780 |   await expect(element(page, qa, 'directoryItem')).toHaveCount(1);
  781 |   await element(page, qa, 'search').fill('不存在的唯一关键词');
  782 |   await expect(element(page, qa, 'directoryEmpty')).toBeVisible();
  783 |   await expect(element(page, qa, 'directoryError')).toBeHidden();
  784 | });
  785 | test('[UI-020] 当前群失焦只提示相关更新，聚焦本身不确认', async ({ qa, page, context }) => {
  786 |   const group = await prepare(qa);
  787 |   const { group: other } = await qa.api.createGroup();
  788 |   await login(page, qa);
  789 |   await go(page, qa, 'group', group.id);
  790 |   const quietTitle = await page.title();
  791 |   const background = await backgroundTab(page);
  792 |   try {
  793 |     incoming(qa, other, '无关群变化');
  794 |     await remains(async () => expect(await page.title()).toBe(quietTitle), 3000);
  795 |     incoming(qa, group, '相关未确认变化');
  796 |     await expect(page).not.toHaveTitle(quietTitle);
  797 |     await page.bringToFront();
  798 |     await expect(page.getByText('相关未确认变化', { exact: true })).toBeVisible();
  799 |     await remains(async () => expect(await page.title()).not.toBe(quietTitle));
  800 |     await page.getByText('相关未确认变化', { exact: true }).click();
  801 |     await expect(page).toHaveTitle(quietTitle);
  802 |   } finally {
  803 |     await background.close();
  804 |   }
  805 | });
  806 | test('[UI-021] 离开群详情销毁提醒范围，旧群变化不污染新页', async ({ qa, page }) => {
  807 |   const group = await prepare(qa);
```