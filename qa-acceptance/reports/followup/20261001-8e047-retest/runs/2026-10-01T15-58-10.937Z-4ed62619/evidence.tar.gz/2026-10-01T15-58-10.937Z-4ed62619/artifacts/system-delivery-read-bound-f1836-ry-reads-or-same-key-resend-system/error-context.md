# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/delivery-read-boundaries.spec.ts >> [INT-READ-001] actual database lock cannot be hidden by abandoned delivery reads or same-key resend
- Location: tests/system/delivery-read-boundaries.spec.ts:45:1

# Error details

```
AssertionError: 实际工具状态等待下界超过原始5000ms上限
```

# Test source

```ts
  226 |     if (
  227 |       event.kind.endsWith('-committed') ||
  228 |       event.kind === 'agent-run-created' ||
  229 |       event.kind === 'send-tool-prepared' ||
  230 |       event.kind === 'message-recovery-adopted'
  231 |     )
  232 |       need(event.commitBoundary === 'outer-commit-confirmed', '不能将提交尝试冒充已提交');
  233 |   }
  234 | }
  235 | 
  236 | const one = (events: readonly RuntimeEvent[], kind: string) => {
  237 |   const matches = events.filter((e) => e.kind === kind);
  238 |   need(matches.length === 1, `需要唯一真实${kind}，当前${matches.length}条`);
  239 |   return matches[0]!;
  240 | };
  241 | function completeHistory(events: readonly RuntimeEvent[]) {
  242 |   need(
  243 |     events[0]?.kind === 'lifecycle-observation-attached' && events[0].droppedThroughSourceSeq === 0,
  244 |     '进程历史已截断或不完整，不能证明完整生命周期',
  245 |   );
  246 | }
  247 | 
  248 | export function toolWaitWindow(events: readonly RuntimeEvent[], toolUseId: string, key: string) {
  249 |   const entered = one(
  250 |     events.filter((e) => e.toolUseId === toolUseId),
  251 |     'send-tool-entered',
  252 |   );
  253 |   const execution = events.filter((e) => e.attemptId === entered.attemptId);
  254 |   const startBefore = one(execution, 'send-key-resolved');
  255 |   const startAfter = one(execution, 'send-wait-started');
  256 |   const endBefore = one(execution, 'send-wait-result-ready');
  257 |   const endAfter = one(execution, 'send-tool-result-returned');
  258 |   const ordered = [entered, startBefore, startAfter, endBefore, endAfter];
  259 |   need(
  260 |     ordered.every(
  261 |       (e, i) =>
  262 |         e.stepId === entered.stepId &&
  263 |         e.toolUseId === toolUseId &&
  264 |         e.runId === entered.runId &&
  265 |         e.clockDomain === entered.clockDomain &&
  266 |         (!i || e.sourceSeq! > ordered[i - 1]!.sourceSeq!),
  267 |     ),
  268 |     '工具等待跨步骤/时钟/顺序',
  269 |   );
  270 |   need(
  271 |     [startBefore, startAfter, endBefore, endAfter].every(
  272 |       (e) => e.clientMsgId === startBefore.clientMsgId && e.idempotencyKey === key,
  273 |     ),
  274 |     '工具等待未关联同一真实消息和key',
  275 |   );
  276 |   const start: Interval = [
  277 |     observationInterval(startBefore.monotonicMs)[0],
  278 |     observationInterval(startAfter.monotonicMs)[1],
  279 |   ];
  280 |   const end: Interval = [
  281 |     observationInterval(endBefore.monotonicMs)[0],
  282 |     observationInterval(endAfter.monotonicMs)[1],
  283 |   ];
  284 |   return {
  285 |     start,
  286 |     end,
  287 |     elapsed: span(start, end),
  288 |     clientMsgId: startBefore.clientMsgId,
  289 |     attemptId: entered.attemptId,
  290 |     runId: entered.runId,
  291 |     stepId: entered.stepId,
  292 |     toolUseId,
  293 |     enteredSeq: entered.seq,
  294 |     clockDomain: entered.clockDomain,
  295 |     errorCode: endAfter.errorCode,
  296 |     readyErrorCode: endBefore.errorCode,
  297 |     keyReused: startBefore.keyReused,
  298 |     result: endAfter.result,
  299 |     returnedSeq: endAfter.seq,
  300 |     droppedThroughSourceSeq: events[0]?.droppedThroughSourceSeq,
  301 |     earlierStages: events.filter(
  302 |       (e) =>
  303 |         e.stepId === entered.stepId &&
  304 |         [
  305 |           'send-tool-prepared',
  306 |           'send-tool-entered',
  307 |           'send-audit-started',
  308 |           'send-audit-completed',
  309 |         ].includes(e.kind),
  310 |     ),
  311 |     history: execution.filter((e) => e.kind === 'send-tool-history-committed'),
  312 |     historyCandidates: events.filter(
  313 |       (e) =>
  314 |         e.stepId === entered.stepId &&
  315 |         e.toolUseId === toolUseId &&
  316 |         e.kind === 'send-tool-history-committed',
  317 |     ),
  318 |   };
  319 | }
  320 | export function assertToolWaitBudget(
  321 |   window: ReturnType<typeof toolWaitWindow>,
  322 |   expectedCode: string | null,
  323 | ) {
  324 |   assert.equal(window.errorCode, expectedCode, '实际工具交还结果错误');
  325 |   assert.equal(window.readyErrorCode, expectedCode, '状态等待结果与交还结果不一致');
> 326 |   assert.ok(window.elapsed[0] <= 5000, '实际工具状态等待下界超过原始5000ms上限');
      |          ^ AssertionError: 实际工具状态等待下界超过原始5000ms上限
  327 |   if (expectedCode === 'SEND_TIMEOUT')
  328 |     assert.ok(window.elapsed[1] >= 5000, '未满5秒且无结论却提前宣告SEND_TIMEOUT');
  329 |   if (window.elapsed[1] > 5000)
  330 |     throw new BlockedError('工具实际等待区间跨5000ms，不能用后续turn或计时容差补证');
  331 | }
  332 | 
  333 | /** Pair by the real execution attempt, never repair a missing host argument by
  334 |  * guessing from a matching toolUseId. Check hard timing violations first. */
  335 | export function assertToolWaitCompletion(window: ReturnType<typeof toolWaitWindow>) {
  336 |   need(window.droppedThroughSourceSeq === 0, '工具流此前历史被截断');
  337 |   const prepared = window.earlierStages.filter((e) => e.kind === 'send-tool-prepared');
  338 |   need(
  339 |     prepared.length === 1 &&
  340 |       prepared[0]!.runId === window.runId &&
  341 |       prepared[0]!.toolUseId === window.toolUseId &&
  342 |       prepared[0]!.stepId === window.stepId &&
  343 |       prepared[0]!.clockDomain === window.clockDomain &&
  344 |       prepared[0]!.seq < window.enteredSeq,
  345 |     '缺少真实合法工具持久化来源',
  346 |   );
  347 |   need(
  348 |     window.history.length === 1 &&
  349 |       window.historyCandidates.length === 1 &&
  350 |       window.history[0]!.seq === window.historyCandidates[0]!.seq &&
  351 |       window.history[0]!.sourceSeq === window.historyCandidates[0]!.sourceSeq &&
  352 |       window.history[0]!.attemptId === window.attemptId &&
  353 |       window.history[0]!.runId === window.runId &&
  354 |       window.history[0]!.stepId === window.stepId &&
  355 |       window.history[0]!.toolUseId === window.toolUseId &&
  356 |       window.history[0]!.seq > window.returnedSeq &&
  357 |       window.history[0]!.clockDomain === window.clockDomain,
  358 |     '缺少同一真实executionAttempt的history COMMIT，不能按toolUseId猜配',
  359 |   );
  360 |   assert.equal(window.history[0]!.errorCode, window.errorCode, '保存history的错误码与交还值不同');
  361 |   assert.deepEqual(window.history[0]!.result, window.result, '保存history的结果与交还值不同');
  362 | }
  363 | 
  364 | /** RuntimeLease has already validated real run/process/clock identities. This
  365 |  * order violation needs neither elapsed-time truth nor a later successful COMMIT. */
  366 | export function assertNoDispatchAfterStop(events: readonly RuntimeEvent[]): void {
  367 |   for (const decision of events.filter((event) => event.kind === 'agent-termination-decided'))
  368 |     assert.ok(
  369 |       !events.some(
  370 |         (event) =>
  371 |           event.kind === 'agent-turn-dispatched' &&
  372 |           event.runId === decision.runId &&
  373 |           event.groupId === decision.groupId &&
  374 |           event.applicationPid === decision.applicationPid &&
  375 |           event.clockDomain === decision.clockDomain &&
  376 |           event.seq > decision.seq,
  377 |       ),
  378 |       '实际终止决定之后不得派发新turn',
  379 |     );
  380 | }
  381 | 
  382 | export function assertAgentLifecycle(events: readonly RuntimeEvent[]) {
  383 |   assertNoDispatchAfterStop(events);
  384 |   const created = one(events, 'agent-run-created');
  385 |   const start = observationInterval(created.creationWindowMs);
  386 |   const decisions = events.filter((e) => e.kind === 'agent-termination-decided');
  387 |   // Evaluate every observed hard violation before missing completion/history.
  388 |   for (const event of [...decisions, ...events.filter((e) => e.kind === 'agent-turn-dispatched')]) {
  389 |     const end = observationInterval(
  390 |       event.kind === 'agent-termination-decided' ? event.decisionWindowMs : event.monotonicMs,
  391 |     );
  392 |     assert.ok(end[0] - start[1] <= 60_000, '真实决定或新turn派发已超过原始60000ms上限');
  393 |   }
  394 |   completeHistory(events);
  395 |   const terminal = one(events, 'agent-terminal-committed');
  396 |   const decision = one(
  397 |     decisions.filter((e) => e.attemptId === terminal.attemptId),
  398 |     'agent-termination-decided',
  399 |   );
  400 |   need(
  401 |     decision.seq < terminal.seq &&
  402 |       decision.status === terminal.status &&
  403 |       decision.reason === terminal.reason,
  404 |     '终止决定与实际COMMIT没有配对',
  405 |   );
  406 |   assert.equal(terminal.status, 'failed');
  407 |   assert.equal(terminal.reason, 'wall_clock');
  408 |   const elapsed = span(start, observationInterval(decision.decisionWindowMs));
  409 |   // The paired COMMIT proves durability but is not the stop-decision timestamp.
  410 |   // A5.2 imposes only the maximum; it does not require running until 60000ms.
  411 |   if (elapsed[1] > 60_000)
  412 |     throw new BlockedError('实际停止决定区间跨60000ms，不能用公开终态或提交时间补证');
  413 |   return {
  414 |     elapsed,
  415 |     created,
  416 |     decision,
  417 |     terminal,
  418 |     turns: events.filter((e) => e.kind === 'agent-turn-dispatched'),
  419 |   };
  420 | }
  421 | 
  422 | /** Diagnostic only: an automatic query is not a negative completion guarantee. */
  423 | export function messageRecoveryEvidence(events: readonly RuntimeEvent[]) {
  424 |   return {
  425 |     attached: events[0],
  426 |     dispatches: events.filter((e) => e.kind === 'message-send-dispatch'),
```