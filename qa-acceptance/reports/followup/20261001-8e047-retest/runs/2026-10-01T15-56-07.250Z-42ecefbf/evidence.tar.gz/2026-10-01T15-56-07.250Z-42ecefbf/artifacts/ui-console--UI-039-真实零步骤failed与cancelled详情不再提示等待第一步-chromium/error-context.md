# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui/console.spec.ts >> [UI-039] 真实零步骤failed与cancelled详情不再提示等待第一步
- Location: tests/ui/console.spec.ts:2410:1

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.fill: Test timeout of 120000ms exceeded.
Call log:
  - waiting for locator('input[autocomplete="username"]')

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - complementary [ref=f1e4]:
    - link "K kapibala ." [ref=f1e5] [cursor=pointer]:
      - /url: "#/groups"
      - generic [ref=f1e6]: K
      - text: kapibala
      - generic [ref=f1e7]: .
    - generic [ref=f1e8]: 工作空间
    - navigation [ref=f1e9]:
      - link "群组工作台" [ref=f1e10] [cursor=pointer]:
        - /url: "#/groups"
      - link "服务账号" [ref=f1e15] [cursor=pointer]:
        - /url: "#/accounts"
      - link "Agent 运行" [ref=f1e20] [cursor=pointer]:
        - /url: "#/agent-runs"
      - link "定时序列" [ref=f1e24] [cursor=pointer]:
        - /url: "#/sequences"
    - generic [ref=f1e31]:
      - generic [ref=f1e39]:
        - strong [ref=f1e40]: 消息运营平台
        - generic [ref=f1e41]: 本地工作空间
      - generic [ref=f1e42]:
        - generic [ref=f1e43]: A
        - generic [ref=f1e44]:
          - strong [ref=f1e45]: admin
          - generic [ref=f1e46]: 管理员
        - button "退出登录" [ref=f1e47] [cursor=pointer]
  - generic [ref=f1e50]:
    - generic [ref=f1e51]:
      - generic [ref=f1e52]:
        - text: 工作空间
        - generic [ref=f1e53]: /
        - strong [ref=f1e54]: 群组工作台
      - status [ref=f1e56]: 连接恢复中
    - main [ref=f1e58]:
      - generic [ref=f1e59]: 实时连接已断开，正在自动重连并补齐期间的变化。
      - generic [ref=f1e60]:
        - generic [ref=f1e61]:
          - generic [ref=f1e62]: GROUP WORKSPACE
          - heading "群组工作台" [level=1] [ref=f1e63]
          - paragraph [ref=f1e64]: 按创建时间浏览群组，或搜索名称、简介和群 ID。
        - button "创建群组" [ref=f1e66] [cursor=pointer]
      - region "群列表查找、筛选与排序" [ref=f1e69]:
        - generic [ref=f1e70]:
          - text: 搜索群组
          - searchbox "搜索群组" [ref=f1e71]
        - button "清除搜索" [disabled] [ref=f1e72]
        - generic [ref=f1e73]:
          - text: 群状态
          - combobox "群状态" [ref=f1e74]:
            - option "全部" [selected]
            - option "可用"
            - option "不可写"
            - option "已退出"
        - generic [ref=f1e75]:
          - text: Agent 自动应答
          - combobox "Agent 自动应答" [ref=f1e76]:
            - option "全部" [selected]
            - option "开启"
            - option "关闭"
        - generic [ref=f1e77]:
          - text: 创建时间
          - combobox "创建时间" [ref=f1e78]:
            - option "新到旧" [selected]
            - option "旧到新"
        - button "重置条件" [disabled] [ref=f1e79]
        - button "刷新列表" [ref=f1e80] [cursor=pointer]
        - paragraph [ref=f1e83]: 搜索与筛选完整群目录；关键词忽略首尾空白与英文大小写，按整段匹配。
      - generic [ref=f1e84]:
        - heading "所有群组" [level=2] [ref=f1e85]
        - generic [ref=f1e86]: 已加载 6 个群 · 已全部加载
      - generic [ref=f1e87]:
        - link "可用 gateway-group-6 网关 ID · gateway-group-6 创建于 2026/10/01 23:56:15 3 位成员 Agent 未开启 查看群组详情" [ref=f1e88] [cursor=pointer]:
          - /url: "#/groups/8bb69957-79f4-4e03-a3f9-96590369e75f"
          - generic [ref=f1e89]: 可用
          - heading "gateway-group-6" [level=3] [ref=f1e95]
          - generic "gateway-group-6" [ref=f1e96]: 网关 ID · gateway-group-6
          - generic [ref=f1e97]:
            - text: 创建于
            - time [ref=f1e98]: 2026/10/01 23:56:15
          - generic [ref=f1e99]:
            - generic [ref=f1e100]: 3 位成员
            - generic [ref=f1e104]: Agent 未开启
          - generic [ref=f1e106]: 查看群组详情
        - link "可用 gateway-group-5 网关 ID · gateway-group-5 创建于 2026/10/01 23:56:14 3 位成员 Agent 已开启 查看群组详情" [ref=f1e110] [cursor=pointer]:
          - /url: "#/groups/ec000e6a-a8f6-4323-93c0-ef7da999216d"
          - generic [ref=f1e111]: 可用
          - heading "gateway-group-5" [level=3] [ref=f1e117]
          - generic "gateway-group-5" [ref=f1e118]: 网关 ID · gateway-group-5
          - generic [ref=f1e119]:
            - text: 创建于
            - time [ref=f1e120]: 2026/10/01 23:56:14
          - generic [ref=f1e121]:
            - generic [ref=f1e122]: 3 位成员
            - generic [ref=f1e126]: Agent 已开启
          - generic [ref=f1e128]: 查看群组详情
        - link "可用 gateway-group-4 网关 ID · gateway-group-4 创建于 2026/10/01 23:56:13 3 位成员 Agent 已开启 查看群组详情" [ref=f1e132] [cursor=pointer]:
          - /url: "#/groups/c972b03f-868d-4d7a-be9e-1c2f6e45d11d"
          - generic [ref=f1e133]: 可用
          - heading "gateway-group-4" [level=3] [ref=f1e139]
          - generic "gateway-group-4" [ref=f1e140]: 网关 ID · gateway-group-4
          - generic [ref=f1e141]:
            - text: 创建于
            - time [ref=f1e142]: 2026/10/01 23:56:13
          - generic [ref=f1e143]:
            - generic [ref=f1e144]: 3 位成员
            - generic [ref=f1e148]: Agent 已开启
          - generic [ref=f1e150]: 查看群组详情
        - link "可用 gateway-group-3 网关 ID · gateway-group-3 创建于 2026/10/01 23:56:12 3 位成员 Agent 已开启 查看群组详情" [ref=f1e154] [cursor=pointer]:
          - /url: "#/groups/dfb150b2-766a-421a-b1a0-15bf3727653b"
          - generic [ref=f1e155]: 可用
          - heading "gateway-group-3" [level=3] [ref=f1e161]
          - generic "gateway-group-3" [ref=f1e162]: 网关 ID · gateway-group-3
          - generic [ref=f1e163]:
            - text: 创建于
            - time [ref=f1e164]: 2026/10/01 23:56:12
          - generic [ref=f1e165]:
            - generic [ref=f1e166]: 3 位成员
            - generic [ref=f1e170]: Agent 已开启
          - generic [ref=f1e172]: 查看群组详情
        - link "可用 gateway-group-2 网关 ID · gateway-group-2 创建于 2026/10/01 23:56:12 3 位成员 Agent 已开启 查看群组详情" [ref=f1e176] [cursor=pointer]:
          - /url: "#/groups/c5a16ab9-485a-46a1-948e-672a4da05fd7"
          - generic [ref=f1e177]: 可用
          - heading "gateway-group-2" [level=3] [ref=f1e183]
          - generic "gateway-group-2" [ref=f1e184]: 网关 ID · gateway-group-2
          - generic [ref=f1e185]:
            - text: 创建于
            - time [ref=f1e186]: 2026/10/01 23:56:12
          - generic [ref=f1e187]:
            - generic [ref=f1e188]: 3 位成员
            - generic [ref=f1e192]: Agent 已开启
          - generic [ref=f1e194]: 查看群组详情
        - link "可用 gateway-group-1 网关 ID · gateway-group-1 创建于 2026/10/01 23:56:11 3 位成员 Agent 已开启 查看群组详情" [ref=f1e198] [cursor=pointer]:
          - /url: "#/groups/c61e2e46-476a-4997-ab88-af520455c1a8"
          - generic [ref=f1e199]: 可用
          - heading "gateway-group-1" [level=3] [ref=f1e205]
          - generic "gateway-group-1" [ref=f1e206]: 网关 ID · gateway-group-1
          - generic [ref=f1e207]:
            - text: 创建于
            - time [ref=f1e208]: 2026/10/01 23:56:11
          - generic [ref=f1e209]:
            - generic [ref=f1e210]: 3 位成员
            - generic [ref=f1e214]: Agent 已开启
          - generic [ref=f1e216]: 查看群组详情
      - generic [ref=f1e220]:
        - generic [ref=f1e221]: Kapibala Console
        - generic [ref=f1e222]: 状态有记录，执行可追踪。
```

# Test source

```ts
  1   | import type { Page, Locator, Request } from '@playwright/test';
  2   | import assert from 'node:assert/strict';
  3   | import { randomUUID } from 'node:crypto';
  4   | import { observe } from '../../harness/observation.js';
  5   | import { mkdir } from 'node:fs/promises';
  6   | import { dirname } from 'node:path';
  7   | import { test, expect } from '../fixtures.js';
  8   | import { BlockedError } from '../../harness/security.js';
  9   | import type { QaEnvironment } from '../../harness/environment.js';
  10  | import type { AgentRun, Group } from '../../harness/platform-client.js';
  11  | import type { AgentRequest, AgentResponsePlan } from '../../harness/agent.js';
  12  | import {
  13  |   observeDirectory,
  14  |   directoryPremise,
  15  |   directoryPeriodMs,
  16  |   directoryGroupIds,
  17  | } from './directory-observer.js';
  18  | import { nativeBackgroundTab } from './native-focus.js';
  19  | import { observePageContinuity, withContinuityEvidence } from './page-continuity.js';
  20  | import { assertDirectoryRefreshBoundary } from './directory-refresh-boundary.js';
  21  | import { requireAvailablePublicAction } from './public-action-premise.js';
  22  | 
  23  | const pageErrors = new WeakMap<Page, string[]>();
  24  | test.beforeEach(async ({ page }) => {
  25  |   const errors: string[] = [];
  26  |   pageErrors.set(page, errors);
  27  |   page.on('pageerror', (error) => errors.push(error.message));
  28  | });
  29  | test.afterEach(async ({ page, qa }, info) => {
  30  |   if (page.isClosed()) {
  31  |     await qa.evidence('ui-final', {
  32  |       closed: true,
  33  |       pageErrors: pageErrors.get(page) ?? [],
  34  |       captureLimitation: '页面已关闭，无法补拍最终画面',
  35  |     });
  36  |     return;
  37  |   }
  38  |   const alerts = await page.locator('[role="alert"],[aria-live="assertive"]').evaluateAll((nodes) =>
  39  |     nodes
  40  |       .filter((node) => {
  41  |         const style = getComputedStyle(node);
  42  |         const box = node.getBoundingClientRect();
  43  |         return (
  44  |           style.visibility !== 'hidden' &&
  45  |           style.display !== 'none' &&
  46  |           box.width > 0 &&
  47  |           box.height > 0
  48  |         );
  49  |       })
  50  |       .map((node) => node.textContent?.slice(0, 1000) ?? ''),
  51  |   );
  52  |   await qa.evidence('ui-final', {
  53  |     url: page.url(),
  54  |     title: await page.title(),
  55  |     visibleAlerts: alerts,
  56  |     visibleTextExcerpt: (await page.locator('body').innerText()).slice(0, 8000),
  57  |     pageErrors: pageErrors.get(page) ?? [],
  58  |   });
  59  |   const path = info.outputPath('evidence', 'ui-final.png');
  60  |   await mkdir(dirname(path), { recursive: true });
  61  |   await page.screenshot({ path, fullPage: true, animations: 'disabled', timeout: 10000 });
  62  |   await info.attach('ui-final-screenshot', { path, contentType: 'image/png' });
  63  |   await info.attach('ui-final-state', {
  64  |     path: info.outputPath('evidence', 'ui-final.json'),
  65  |     contentType: 'application/json',
  66  |   });
  67  | });
  68  | 
  69  | function element(page: Page, qa: QaEnvironment, key: string): Locator {
  70  |   const selector = qa.config.ui.selectors[key];
  71  |   if (!selector) throw new BlockedError(`UI适配缺少${key}；通过可见页面确认定位后重跑`);
  72  |   return page.locator(selector);
  73  | }
  74  | async function go(page: Page, qa: QaEnvironment, route: string, id?: string): Promise<void> {
  75  |   const path = qa.config.ui.routes[route];
  76  |   if (!path) throw new BlockedError(`UI路由适配缺少${route}`);
  77  |   await page.goto(`${qa.webUrl}${path.replace('{id}', encodeURIComponent(id ?? ''))}`, {
  78  |     waitUntil: 'domcontentloaded',
  79  |   });
  80  | }
  81  | async function login(
  82  |   page: Page,
  83  |   qa: QaEnvironment,
  84  |   role: 'admin' | 'viewer' = 'admin',
  85  | ): Promise<void> {
  86  |   if (!qa.config.ui.adapterConfirmed)
  87  |     throw new BlockedError('尚未根据被测页面确认UI定位适配；模板不是实现事实');
  88  |   await qa.startWeb();
  89  |   await go(page, qa, 'login');
> 90  |   await element(page, qa, 'username').fill(role);
      |                                       ^ Error: locator.fill: Test timeout of 120000ms exceeded.
  91  |   await element(page, qa, 'password').fill(role);
  92  |   const response = page.waitForResponse(
  93  |     (r) => new URL(r.url()).pathname === '/api/auth/login' && r.request().method() === 'POST',
  94  |   );
  95  |   await element(page, qa, 'login').click();
  96  |   expect((await response).status()).toBe(200);
  97  |   await expect(element(page, qa, 'username')).toBeHidden();
  98  | }
  99  | /** A negative assertion must survive a declared observation window, not pass before delivery. */
  100 | async function remains(check: () => Promise<void>, durationMs = 1_000): Promise<void> {
  101 |   const until = performance.now() + durationMs;
  102 |   do {
  103 |     await check();
  104 |     await new Promise<void>((resolve) => setTimeout(resolve, 50));
  105 |   } while (performance.now() < until);
  106 |   await check();
  107 | }
  108 | function card(page: Page, qa: QaEnvironment, text: string): Locator {
  109 |   return element(page, qa, 'directoryItem').filter({ hasText: text });
  110 | }
  111 | function child(locator: Locator, qa: QaEnvironment, key: string): Locator {
  112 |   const selector = qa.config.ui.selectors[key];
  113 |   if (!selector) throw new BlockedError(`UI适配缺少卡片内${key}`);
  114 |   return locator.locator(selector);
  115 | }
  116 | function directoryRequest(request: Request): boolean {
  117 |   return new URL(request.url()).pathname === '/api/group-directory' && request.method() === 'GET';
  118 | }
  119 | async function backgroundTab(page: Page): Promise<Page> {
  120 |   return nativeBackgroundTab(page, {
  121 |     record: async (evidence) => {
  122 |       await test.info().attach('native-tab-focus', {
  123 |         body: JSON.stringify(evidence, null, 2),
  124 |         contentType: 'application/json',
  125 |       });
  126 |     },
  127 |   });
  128 | }
  129 | async function favicon(page: Page): Promise<string> {
  130 |   return page.evaluate(async () =>
  131 |     JSON.stringify(
  132 |       await Promise.all(
  133 |         Array.from(document.querySelectorAll<HTMLLinkElement>('link[rel~="icon"]')).map(
  134 |           async (link) => {
  135 |             const response = await fetch(link.href);
  136 |             return Array.from(new Uint8Array(await response.arrayBuffer()));
  137 |           },
  138 |         ),
  139 |       ),
  140 |     ),
  141 |   );
  142 | }
  143 | async function prepare(qa: QaEnvironment): Promise<Group> {
  144 |   await qa.api.login();
  145 |   return (await qa.api.createGroup()).group;
  146 | }
  147 | function incoming(qa: QaEnvironment, group: Group, text: string) {
  148 |   return qa.gateway.emitMessage({
  149 |     groupId: group.gatewayGroupId,
  150 |     senderPlatformUserId: 'external-ui',
  151 |     text,
  152 |   });
  153 | }
  154 | async function run(qa: QaEnvironment, group: Group): Promise<AgentRun> {
  155 |   const runs = await qa.api.waitFor<AgentRun[]>(
  156 |     `/api/groups/${group.id}/agent-runs`,
  157 |     (items) => items.length > 0 && items[0]!.status !== 'running',
  158 |   );
  159 |   return qa.api.agentRun(runs[0]!.id);
  160 | }
  161 | async function createSequence(qa: QaEnvironment) {
  162 |   return qa.api.require(
  163 |     qa.api.post<{ id: string }>('/api/sequences', {
  164 |       name: 'QA变量序列',
  165 |       steps: [
  166 |         { index: 1, accountRole: 'admin', text: '{event} 在 {place}', delaySeconds: 1 },
  167 |         { index: 2, accountRole: 'member', text: '{event} 在 {place}', delaySeconds: 1 },
  168 |       ],
  169 |     }),
  170 |   );
  171 | }
  172 | async function fillVars(
  173 |   page: Page,
  174 |   qa: QaEnvironment,
  175 |   key: string,
  176 |   value: Record<string, unknown>,
  177 | ) {
  178 |   const selector = qa.config.ui.selectors[key];
  179 |   if (!selector) throw new BlockedError(`UI缺少${key}`);
  180 |   if (selector.includes('{key}')) {
  181 |     for (const [name, v] of Object.entries(value)) {
  182 |       if (typeof v === 'object' && v !== null)
  183 |         for (const [nested, nv] of Object.entries(v))
  184 |           await page
  185 |             .locator(selector.replace('{step}', name).replace('{key}', nested))
  186 |             .fill(String(nv));
  187 |       else await page.locator(selector.replace('{key}', name)).fill(String(v));
  188 |     }
  189 |   } else await page.locator(selector).fill(JSON.stringify(value));
  190 | }
```