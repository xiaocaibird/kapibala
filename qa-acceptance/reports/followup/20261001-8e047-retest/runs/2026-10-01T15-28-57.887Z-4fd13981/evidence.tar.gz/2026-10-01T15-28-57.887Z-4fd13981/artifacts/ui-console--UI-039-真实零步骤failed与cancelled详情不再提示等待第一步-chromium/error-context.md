# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui/console.spec.ts >> [UI-039] 真实零步骤failed与cancelled详情不再提示等待第一步
- Location: tests/ui/console.spec.ts:2409:1

# Error details

```
BlockedError: [BLOCKED] cancelled：未形成可证实的真实cancelled/steps=[]；当前轮产生步骤不等于文案失败；failed：当前交付观察协议无真实创建后/首轮派发前活动hold；模型超时会产生步骤，禁止SQL写终态或active_ms伪造零步骤
```

# Test source

```ts
  2443 |     );
  2444 |     await expect(page.locator('main')).toContainText(
  2445 |       /暂无步骤|没有步骤|无步骤|no steps|no step records/i,
  2446 |     );
  2447 |     const visibleText = await page.locator('main').innerText();
  2448 |     expect(visibleText).not.toMatch(
  2449 |       /正在等待第一步结果|waiting for (?:the )?first (?:step|result)/i,
  2450 |     );
  2451 |     expect(await qa.api.agentRun(actual.id)).toEqual(actual);
  2452 |     await qa.evidence(`ui039-${status}-copy`, { actual, visibleText });
  2453 |     outcomes[status] = { status: 'PASS', runId: actual.id, evidence: `ui039-${status}-copy` };
  2454 |   };
  2455 |   // The existing external response barrier observes an already dispatched first
  2456 |   // model request. It is a real cancellation probe, not a pre-dispatch guarantee.
  2457 |   qa.agent.enqueueTurns({
  2458 |     barrier: { phase: 'before-response', name: barrier },
  2459 |     body: {
  2460 |       stop_reason: 'end_turn',
  2461 |       content: [{ type: 'text', text: '零步骤取消前提：当前模型轮真实返回' }],
  2462 |     },
  2463 |   });
  2464 |   try {
  2465 |     await qa.api.require(qa.api.patch(`/api/groups/${group.id}`, { agentEnabled: true }));
  2466 |     incoming(qa, group, barrier);
  2467 |     const created = await observe({
  2468 |       read: () => qa.api.require(qa.api.get<AgentRun[]>(`/api/groups/${group.id}/agent-runs`)),
  2469 |       invariant: (items) => {
  2470 |         expect(items.length).toBeLessThanOrEqual(1);
  2471 |         noUnexpectedEffect();
  2472 |       },
  2473 |       complete: (items) => items.length === 1,
  2474 |       durationMs: 10_000,
  2475 |     });
  2476 |     if (!created.complete) {
  2477 |       blockers.push('cancelled：有限观察未取得本轮真实run，不将10秒诊断上限作为业务SLA');
  2478 |       outcomes.cancelled = { status: 'BLOCKED', observed: created };
  2479 |     } else {
  2480 |       const runId = created.last[0]!.id;
  2481 |       let hit;
  2482 |       try {
  2483 |         hit = await qa.agent.barriers.waitFor(barrier, 5_000);
  2484 |       } catch (error) {
  2485 |         blockers.push(`cancelled：首个模型响应屏障未命中：${String(error)}`);
  2486 |       }
  2487 |       const heldState = await qa.api.agentRun(runId);
  2488 |       await qa.evidence('ui039-cancelled-before-disable', { hit, heldState });
  2489 |       await qa.api.require(qa.api.patch(`/api/groups/${group.id}`, { agentEnabled: false }));
  2490 |       // Allow the actual current model round to finish; do not require terminal
  2491 |       // state while held and do not discard a real returned step to make zero.
  2492 |       qa.agent.barriers.release(barrier);
  2493 |       const terminal = await observe({
  2494 |         read: () => qa.api.agentRun(runId),
  2495 |         invariant: (actual) => {
  2496 |           expect(actual.id).toBe(runId);
  2497 |           expect(actual.groupId).toBe(group.id);
  2498 |           if (actual.status === 'cancelled') expect(actual.endReason).toBe('cancelled');
  2499 |           if (actual.status === 'failed')
  2500 |             expect(['wall_clock', 'budget_exhausted', 'protocol_errors']).toContain(
  2501 |               actual.endReason,
  2502 |             );
  2503 |           noUnexpectedEffect();
  2504 |         },
  2505 |         complete: (actual) => actual.status !== 'running',
  2506 |         durationMs: 20_000,
  2507 |       });
  2508 |       await qa.evidence('ui039-cancelled-terminal-premise', terminal);
  2509 |       if (
  2510 |         terminal.complete &&
  2511 |         terminal.last.status === 'cancelled' &&
  2512 |         terminal.last.steps.length === 0 &&
  2513 |         hit
  2514 |       ) {
  2515 |         await verifyEmptyTerminal(terminal.last, 'cancelled');
  2516 |       } else {
  2517 |         blockers.push(
  2518 |           'cancelled：未形成可证实的真实cancelled/steps=[]；当前轮产生步骤不等于文案失败',
  2519 |         );
  2520 |         outcomes.cancelled = { status: 'BLOCKED', observed: terminal };
  2521 |       }
  2522 |       // A coincident genuine zero-step wall_clock result may independently supply
  2523 |       // the failed-state UI premise, but is never relabelled as cancelled.
  2524 |       if (
  2525 |         terminal.complete &&
  2526 |         terminal.last.status === 'failed' &&
  2527 |         terminal.last.endReason === 'wall_clock' &&
  2528 |         terminal.last.steps.length === 0
  2529 |       )
  2530 |         await verifyEmptyTerminal(terminal.last, 'failed');
  2531 |     }
  2532 |     if (!outcomes.failed) {
  2533 |       blockers.push(
  2534 |         'failed：当前交付观察协议无真实创建后/首轮派发前活动hold；模型超时会产生步骤，禁止SQL写终态或active_ms伪造零步骤',
  2535 |       );
  2536 |       outcomes.failed = {
  2537 |         status: 'BLOCKED',
  2538 |         dependency:
  2539 |           'owned pre-first-dispatch active window with actual run identity; not delivered',
  2540 |       };
  2541 |     }
  2542 |     noUnexpectedEffect();
> 2543 |     if (blockers.length) throw new BlockedError(blockers.join('；'));
       |                                ^ BlockedError: [BLOCKED] cancelled：未形成可证实的真实cancelled/steps=[]；当前轮产生步骤不等于文案失败；failed：当前交付观察协议无真实创建后/首轮派发前活动hold；模型超时会产生步骤，禁止SQL写终态或active_ms伪造零步骤
  2544 |   } finally {
  2545 |     qa.agent.barriers.release(barrier);
  2546 |     await qa.evidence('ui039-per-state-results', {
  2547 |       outcomes,
  2548 |       blockers,
  2549 |       gateway: qa.gateway.snapshot(),
  2550 |       agent: qa.agent.snapshot(),
  2551 |       boundary: '两个零步骤终态分别必须有真实公开状态与页面证据；任一缺少不得判整例PASS',
  2552 |     });
  2553 |   }
  2554 | });
  2555 | 
```