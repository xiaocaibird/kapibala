# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/protocol-boundaries.spec.ts >> [BLK-EXT-004] an already effective kick is not repeated against a rejoined target after restart
- Location: tests/system/protocol-boundaries.spec.ts:392:1

# Error details

```
BlockedError: [BLOCKED] Restarted kick run remains open within 20s observation budget; no arbitrary recovery deadline asserted
```

# Test source

```ts
  360 |       try {
  361 |         await evidence(qa, `${outcome}-final-ledger`);
  362 |       } catch (error) {
  363 |         if (!primaryFailure) {
  364 |           primaryFailure = true;
  365 |           throw error;
  366 |         }
  367 |       } finally {
  368 |         const cleanup = await Promise.allSettled(controls.map((control) => control.close()));
  369 |         const errors = cleanup.filter((result) => result.status === 'rejected');
  370 |         if (errors.length) {
  371 |           try {
  372 |             await qa.evidence(
  373 |               `${outcome}-recovery-cleanup-failure`,
  374 |               errors.map((entry) => String(entry.reason)),
  375 |             );
  376 |           } catch {
  377 |             /* Keep first failure. */
  378 |           }
  379 |           if (!primaryFailure)
  380 |             throw new BlockedError('本消息观测租约未全部确认释放，旧PID不可跟随新实例');
  381 |         }
  382 |       }
  383 |     }
  384 |   }
  385 |   if (incomplete.length)
  386 |     throw new BlockedError(
  387 |       `No terminal evidence within observation budget for ${incomplete.join(', ')}. ` +
  388 |         'The 10s probe is not a product deadline or proof of permanent non-recovery; retain CL-01 protocol risk.',
  389 |     );
  390 | });
  391 | 
  392 | test('[BLK-EXT-004] an already effective kick is not repeated against a rejoined target after restart', async ({
  393 |   qa,
  394 | }) => {
  395 |   await qa.api.login();
  396 |   const { group } = await qa.api.createGroup();
  397 |   const target = 'kick-rejoin-target';
  398 |   const path = `/groups/${group.gatewayGroupId}/kick`;
  399 |   qa.gateway.setMembership(group.gatewayGroupId, target, true);
  400 |   await enable(qa, group);
  401 |   qa.agent.enqueueTurns(
  402 |     tool('kick-before-rejoin', 'kick_user', {
  403 |       platform_user_id: target,
  404 |       reason: 'single authorized removal',
  405 |     }),
  406 |     final('resumed existing run'),
  407 |   );
  408 |   qa.gateway.enqueue(path, {
  409 |     effect: 'apply',
  410 |     barrier: { phase: 'after-effect', name: 'kick-before-rejoin' },
  411 |   });
  412 |   try {
  413 |     trigger(qa, group, 'remove once');
  414 |     await qa.gateway.barriers.waitFor('kick-before-rejoin');
  415 |     const id = await runId(qa, group);
  416 |     const original = qa.gateway.snapshot().requests.find((entry) => entry.path === path)!;
  417 |     expect(original.responseStatus).toBeUndefined();
  418 |     expect(
  419 |       qa.gateway
  420 |         .snapshot()
  421 |         .effects.filter((entry) => entry.kind === 'kick' && entry.groupId === group.gatewayGroupId),
  422 |     ).toHaveLength(1);
  423 |     await qa.kill();
  424 |     qa.gateway.barriers.release('kick-before-rejoin');
  425 |     // Finish the external operation and record its member_left event while the
  426 |     // SUT is down, then join again. Neither event is erased or reordered.
  427 |     await eventually(
  428 |       async () => qa.gateway.snapshot(),
  429 |       (snapshot) =>
  430 |         snapshot.requests.some((entry) => entry.id === original.id && entry.completedAt) &&
  431 |         snapshot.events.some(
  432 |           (entry) => entry.type === 'member_left' && entry.data.platformUserId === target,
  433 |         ),
  434 |     );
  435 |     qa.gateway.setMembership(group.gatewayGroupId, target, true);
  436 |     await evidence(qa, 'kick-applied-then-rejoined', { id });
  437 |     await qa.start();
  438 |     await qa.api.login();
  439 |     const result = await observe({
  440 |       durationMs: 20_000,
  441 |       read: () => qa.api.agentRun(id),
  442 |       complete: (run) => run.status !== 'running',
  443 |       invariant: (run) => {
  444 |         expect(run.id).toBe(id);
  445 |         expect(qa.gateway.snapshot().requests.filter((entry) => entry.path === path)).toHaveLength(
  446 |           1,
  447 |         );
  448 |         expect(
  449 |           qa.gateway
  450 |             .snapshot()
  451 |             .groups.find((item) => item.groupId === group.gatewayGroupId)!
  452 |             .members.some((item) => item.platformUserId === target),
  453 |         ).toBe(true);
  454 |         for (const step of run.steps.filter((step) => step.toolUseId === 'kick-before-rejoin'))
  455 |           expect(step.isError, 'already effective tool must not be recorded as failed').toBe(false);
  456 |       },
  457 |     });
  458 |     await evidence(qa, 'kick-rejoin-resumed', result);
  459 |     if (!result.complete)
> 460 |       throw new BlockedError(
      |             ^ BlockedError: [BLOCKED] Restarted kick run remains open within 20s observation budget; no arbitrary recovery deadline asserted
  461 |         'Restarted kick run remains open within 20s observation budget; no arbitrary recovery deadline asserted',
  462 |       );
  463 |     expect(result.last.status).toBe('finished');
  464 |     expect(result.last.endReason).toBe('final');
  465 |     expect(
  466 |       result.last.steps.filter((step) => step.toolUseId === 'kick-before-rejoin'),
  467 |     ).toHaveLength(1);
  468 |   } finally {
  469 |     qa.gateway.barriers.release('kick-before-rejoin');
  470 |     await evidence(qa, 'kick-rejoin-final-ledger');
  471 |   }
  472 | });
  473 | 
  474 | type TurnBody = {
  475 |   runId: string;
  476 |   messages: {
  477 |     role: string;
  478 |     content: { type: string; tool_use_id?: string; [key: string]: unknown }[];
  479 |   }[];
  480 | };
  481 | 
  482 | test('[BLK-EXT-005] a lost unexecuted model response may change while persisted history and effects survive', async ({
  483 |   qa,
  484 | }) => {
  485 |   await qa.api.login();
  486 |   const { group } = await qa.api.createGroup();
  487 |   await enable(qa, group);
  488 |   const text = 'effect before lost model turn';
  489 |   qa.agent.enqueueTurns(
  490 |     tool('persisted-send', 'send_message', { text, idempotency_key: 'persisted-send-key' }),
  491 |     {
  492 |       ...tool('lost-read', 'get_recent_messages', { limit: 2 }),
  493 |       barrier: { phase: 'before-response', name: 'lost-model-response' },
  494 |     },
  495 |     final('different but legal response after restart'),
  496 |   );
  497 |   try {
  498 |     trigger(qa, group, 'start response-loss test');
  499 |     await qa.agent.barriers.waitFor('lost-model-response');
  500 |     const id = await runId(qa, group);
  501 |     const before = qa.agent.snapshot().turns.at(-1)!;
  502 |     const persisted = (before.body as TurnBody).messages
  503 |       .flatMap((message) => message.content)
  504 |       .find((block) => block.type === 'tool_result' && block.tool_use_id === 'persisted-send');
  505 |     expect(persisted).toBeDefined();
  506 |     expect(before.completedAt).toBeUndefined();
  507 |     await eventually(
  508 |       async () => qa.gateway.snapshot().messages.filter((entry) => entry.text === text),
  509 |       (messages) => messages.length > 0,
  510 |     );
  511 |     expect(qa.gateway.snapshot().messages.filter((entry) => entry.text === text)).toHaveLength(1);
  512 |     await qa.kill();
  513 |     qa.agent.barriers.release('lost-model-response');
  514 |     await evidence(qa, 'lost-model-response-at-crash', { id, persisted });
  515 |     await qa.start();
  516 |     await qa.api.login();
  517 |     const result = await observe({
  518 |       durationMs: 20_000,
  519 |       read: () => qa.api.agentRun(id),
  520 |       complete: (run) => run.status !== 'running',
  521 |       invariant: (run) => {
  522 |         expect(run.id).toBe(id);
  523 |         expect(run.steps.length).toBeLessThanOrEqual(12);
  524 |         expect(qa.gateway.snapshot().messages.filter((entry) => entry.text === text)).toHaveLength(
  525 |           1,
  526 |         );
  527 |         const all = qa.agent.snapshot().turns;
  528 |         expect(all.every((turn) => (turn.body as TurnBody).runId === id)).toBe(true);
  529 |         for (const turn of all.filter((turn) => turn.id > before.id))
  530 |           expect(
  531 |             (turn.body as TurnBody).messages.flatMap((message) => message.content),
  532 |           ).toContainEqual(persisted);
  533 |       },
  534 |     });
  535 |     await evidence(qa, 'lost-model-response-resumed', result);
  536 |     if (!result.complete)
  537 |       throw new BlockedError(
  538 |         'Run not terminal within 20s probe; original recovery obligation retained without inventing a deadline',
  539 |       );
  540 |     expect(qa.agent.snapshot().turns.some((turn) => turn.id > before.id)).toBe(true);
  541 |     expect(result.last.status).toBe('finished');
  542 |     expect(result.last.endReason).toBe('final');
  543 |     expect(result.last.steps.filter((step) => step.toolUseId === 'persisted-send')).toHaveLength(1);
  544 |     expect(result.last.steps.find((step) => step.toolUseId === 'persisted-send')?.isError).toBe(
  545 |       false,
  546 |     );
  547 |     expect(
  548 |       qa.gateway.snapshot().requests.filter((request) => request.path.endsWith('/send')),
  549 |     ).toHaveLength(1);
  550 |   } finally {
  551 |     qa.agent.barriers.release('lost-model-response');
  552 |     await evidence(qa, 'lost-model-response-final-ledger');
  553 |   }
  554 | });
  555 | 
```