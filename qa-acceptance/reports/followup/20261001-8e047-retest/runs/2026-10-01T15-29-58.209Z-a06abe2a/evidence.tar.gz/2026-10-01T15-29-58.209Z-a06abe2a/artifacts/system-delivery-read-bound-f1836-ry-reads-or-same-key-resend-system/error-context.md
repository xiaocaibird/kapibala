# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/delivery-read-boundaries.spec.ts >> [INT-READ-001] actual database lock cannot be hidden by abandoned delivery reads or same-key resend
- Location: tests/system/delivery-read-boundaries.spec.ts:45:1

# Error details

```
BlockedError: [BLOCKED] 真实locker身份或ACCESS EXCLUSIVE持锁未证实
```

# Test source

```ts
  1   | import { BlockedError } from '../../harness/security.js';
  2   | 
  3   | export interface OwnedPgExpectation {
  4   |   name: string;
  5   |   owner: string;
  6   |   port: number;
  7   |   database: string;
  8   |   registered: boolean;
  9   | }
  10  | /** No credentials or SQL are accepted from the inspected object. */
  11  | export function ownedPgContainer(raw: unknown, expected: OwnedPgExpectation): string {
  12  |   const value = raw as {
  13  |     Id?: string;
  14  |     Name?: string;
  15  |     Config?: { Labels?: Record<string, string> };
  16  |     State?: { Running?: boolean };
  17  |     NetworkSettings?: { Ports?: Record<string, { HostIp: string; HostPort: string }[]> };
  18  |   };
  19  |   const ports = value?.NetworkSettings?.Ports?.['5432/tcp'];
  20  |   if (
  21  |     !expected.registered ||
  22  |     !/^qa_[a-f0-9]{24}$/.test(expected.database) ||
  23  |     expected.name !== `qa-acceptance-${expected.owner}` ||
  24  |     value?.Name !== `/${expected.name}` ||
  25  |     !/^[a-f0-9]{64}$/.test(value.Id ?? '') ||
  26  |     value.Config?.Labels?.['qa.owner'] !== expected.owner ||
  27  |     !value.State?.Running ||
  28  |     ports?.length !== 1 ||
  29  |     ports[0]?.HostIp !== '127.0.0.1' ||
  30  |     Number(ports[0]?.HostPort) !== expected.port
  31  |   )
  32  |     throw new BlockedError('PG表锁夹具归属/注册数据库/容器/唯一回环端口不匹配');
  33  |   return value.Id!;
  34  | }
  35  | 
  36  | export interface PgActivity {
  37  |   pid: number;
  38  |   datname: string;
  39  |   usename: string;
  40  |   application_name: string;
  41  |   backend_start: string;
  42  |   xact_start: string | null;
  43  |   query_start: string | null;
  44  |   state: string;
  45  |   wait_event_type: string | null;
  46  |   wait_event: string | null;
  47  |   query: string;
  48  |   blockers: number[];
  49  |   relation_locks: { relation: number; mode: string; granted: boolean }[];
  50  | }
  51  | export interface PgLockSample {
  52  |   beforeMs: number;
  53  |   afterMs: number;
  54  |   at: string;
  55  |   database: string;
  56  |   activities: PgActivity[];
  57  | }
  58  | 
  59  | /** A real wait relation is evidence of fault placement, not a result oracle or
  60  |  * proof that this is waitForDelivery rather than another product reader. */
  61  | export function blockedMessageReaders(
  62  |   sample: PgLockSample,
  63  |   owner: { database: string; lockerPid: number; lockerStart: string; relationOid: number },
  64  | ): PgActivity[] {
  65  |   const locker = sample.activities.find((row) => row.pid === owner.lockerPid);
  66  |   if (
  67  |     sample.database !== owner.database ||
  68  |     !locker ||
  69  |     locker.backend_start !== owner.lockerStart ||
  70  |     locker.datname !== owner.database ||
  71  |     !locker.relation_locks.some(
  72  |       (lock) =>
  73  |         lock.relation === owner.relationOid && lock.granted && lock.mode === 'AccessExclusiveLock',
  74  |     )
  75  |   )
> 76  |     throw new BlockedError('真实locker身份或ACCESS EXCLUSIVE持锁未证实');
      |           ^ BlockedError: [BLOCKED] 真实locker身份或ACCESS EXCLUSIVE持锁未证实
  77  |   return sample.activities.filter(
  78  |     (row) =>
  79  |       row.pid !== owner.lockerPid &&
  80  |       row.datname === owner.database &&
  81  |       row.usename === 'qa' &&
  82  |       !row.application_name.startsWith('qa-int-read-') &&
  83  |       row.state === 'active' &&
  84  |       row.wait_event_type === 'Lock' &&
  85  |       row.blockers.includes(owner.lockerPid) &&
  86  |       /^\s*select\b/i.test(row.query) &&
  87  |       /\b(?:from|join)\s+(?:"?public"?\.)?"?messages"?(?=\s|$)/i.test(row.query) &&
  88  |       row.relation_locks.some(
  89  |         (lock) =>
  90  |           lock.relation === owner.relationOid && !lock.granted && lock.mode === 'AccessShareLock',
  91  |       ),
  92  |   );
  93  | }
  94  | 
  95  | /** Same backend/query identity, never PID alone. Diagnostic classification only:
  96  |  * even an idle sample cannot certify an unobserved ROLLBACK ordering. */
  97  | export function readerAfterReturn(before: PgActivity, rows: readonly PgActivity[]) {
  98  |   const after = rows.find((row) => row.pid === before.pid);
  99  |   if (!after) return 'backend-absent' as const;
  100 |   if (after.backend_start !== before.backend_start) return 'backend-replaced' as const;
  101 |   if (after.state.startsWith('idle in transaction')) return 'idle-transaction-observed' as const;
  102 |   if (after.state === 'idle' && after.xact_start === null)
  103 |     return 'idle-without-transaction' as const;
  104 |   if (after.query_start === before.query_start && after.query === before.query)
  105 |     return 'same-query-still-active' as const;
  106 |   return 'busy-or-reused-not-proven-clean' as const;
  107 | }
  108 | 
```