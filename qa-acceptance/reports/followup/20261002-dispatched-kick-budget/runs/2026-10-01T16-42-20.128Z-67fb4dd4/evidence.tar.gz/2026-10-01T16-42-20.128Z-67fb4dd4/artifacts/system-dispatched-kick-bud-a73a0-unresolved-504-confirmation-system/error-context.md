# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: system/dispatched-kick-budget.spec.ts >> [INT-KICK-BUDGET-001] original active budget bounds an already dispatched kick with unresolved 504 confirmation
- Location: tests/system/dispatched-kick-budget.spec.ts:31:1

# Error details

```
AssertionError: whole original activity: 原A5.8强恢复未满足：原run等待人工或外部结果确认而不能自动续跑；这不是活动预算超时结论
actual decision and paired outer COMMIT: 原A5.8强恢复未满足：原run等待人工或外部结果确认而不能自动续跑；这不是活动预算超时结论
```

# Test source

```ts
  656 |         await sample('final-before-cleanup');
  657 |         budgetChecks(true);
  658 |       } catch (error) {
  659 |         add(secondary, `final observation: ${String(error)}`);
  660 |       }
  661 |     }
  662 |     ledgerChecks();
  663 |     if (primary instanceof assert.AssertionError) add(failures, primary.message);
  664 |     else if (primary instanceof BlockedError) add(missing, primary.message);
  665 |     await evidence('dispatched-kick-budget-final', {
  666 |       caseId: 'INT-KICK-BUDGET-001',
  667 |       kick,
  668 |       requiredMaximumMs: 60_000,
  669 |       diagnosticBudgetMs,
  670 |       stages,
  671 |       publicSamples,
  672 |       activitySamples,
  673 |       activity: activity?.latest,
  674 |       lifecycle: lifecycle?.latest,
  675 |       lifecycleVerdict,
  676 |       capacity: capacityLease?.latest,
  677 |       gateway: qa.gateway.snapshot(),
  678 |       agent: qa.agent.snapshot(),
  679 |       postId,
  680 |       confirmationId,
  681 |       postReleased,
  682 |       confirmationWindowEstablished,
  683 |       auditPassEstablished,
  684 |       windowClosedBeforeTerminal,
  685 |       decisionObservedWithPendingConfirmation,
  686 |       calibrations,
  687 |       mappedConfirmationBoundary,
  688 |       failures,
  689 |       missing,
  690 |       primary: primary ? String(primary) : null,
  691 |       coverage: {
  692 |         secondInstance: 'NOT_RUN',
  693 |         restartRecovery: 'NOT_RUN',
  694 |         arbitraryUnknownRecovery: 'NOT_RUN',
  695 |         cancellationCause: {
  696 |           status: 'BLOCKED',
  697 |           reason:
  698 |             '当前协议无原请求取消来源标记；peer-close仅是传输事实，此细项不改已证预算或不重放判定',
  699 |         },
  700 |         limit:
  701 |           '单实例实际活动/已派发kick/有限不重放组合；unknown仅如实记录。peer-close不自动证明abort原因，不替代A5.8强恢复，也不证明所有未来不重复。',
  702 |       },
  703 |     });
  704 |     // Stop only this QA-owned process if a response remains held. The final
  705 |     // product snapshot above is immutable; cleanup must not manufacture a
  706 |     // success by sending the previously unavailable members response.
  707 |     const pending =
  708 |       !!kick &&
  709 |       requests().some(
  710 |         (entry) =>
  711 |           entry.path.startsWith(`/groups/${kick!.group.gatewayGroupId}/`) &&
  712 |           !entry.responseFinishedAt &&
  713 |           !entry.responseClosedAt,
  714 |       );
  715 |     // Read-only observers can be released against the still-live owner. A held
  716 |     // admission gate is released only after stopping an unfinished owned run.
  717 |     try {
  718 |       await runtime?.close();
  719 |     } catch (error) {
  720 |       add(secondary, `runtime cleanup: ${String(error)}`);
  721 |     }
  722 |     if (capacityLease?.latest?.state === 'released') {
  723 |       try {
  724 |         await capacity?.close();
  725 |       } catch (error) {
  726 |         add(secondary, `capacity cleanup: ${String(error)}`);
  727 |       }
  728 |     }
  729 |     if (createdBefore && (pending || !run || run.status === 'running')) {
  730 |       try {
  731 |         await qa.kill();
  732 |       } catch (error) {
  733 |         add(secondary, `owned process stop: ${String(error)}`);
  734 |       }
  735 |     }
  736 |     qa.agent.barriers.release(kick?.auditBarrier ?? 'qa-audit-dispatched-original-budget');
  737 |     qa.gateway.barriers.release(postBarrier);
  738 |     qa.gateway.barriers.release(confirmationBarrier);
  739 |     if (capacityLease?.latest?.state !== 'released') {
  740 |       try {
  741 |         await capacity?.close();
  742 |       } catch (error) {
  743 |         add(secondary, `capacity cleanup: ${String(error)}`);
  744 |       }
  745 |     }
  746 |     await evidence('dispatched-kick-budget-cleanup', {
  747 |       at: new Date().toISOString(),
  748 |       pendingResponseBeforeCleanup: pending,
  749 |       secondary,
  750 |       failures,
  751 |       missing,
  752 |       gatewayAfterCleanup: qa.gateway.snapshot(),
  753 |       boundary: '清理后记录不回填测试期业务结果；仅释放本例屏障/租约及必要时停止自有SUT',
  754 |     });
  755 |   }
> 756 |   if (failures.length) assert.fail(failures.join('\n'));
      |                               ^ AssertionError: whole original activity: 原A5.8强恢复未满足：原run等待人工或外部结果确认而不能自动续跑；这不是活动预算超时结论
  757 |   if (primary && !(primary instanceof BlockedError)) throw primary;
  758 |   if (missing.length || secondary.length)
  759 |     throw new BlockedError([...missing, ...secondary].join('; '));
  760 | });
  761 | 
```