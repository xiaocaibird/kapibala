from pathlib import Path
import os
import subprocess
import sys

root = Path('/Users/zcm/.codex/worktrees/architecture-runtime-boundaries/kapibala')
output = Path('/tmp/kapibala-runtime-boundaries-evidence')
count = int(sys.argv[1]) if len(sys.argv) > 1 else 20
label = os.environ.get('PG_PROBE_LABEL', 'shutdown-probe')
url = os.environ.get('DATABASE_URL', '')
if not url.startswith('postgres://qa:qa-local@127.0.0.1:50033/'):
    raise SystemExit('Requires the explicitly isolated PostgreSQL URL on port 50033')
if not (root / 'node_modules').exists():
    raise SystemExit('Install the temporary node_modules symlink before this exclusive probe')

for index in range(1, count + 1):
    trace = output / f'{label}-{index:02}.jsonl'
    log = output / f'{label}-{index:02}.tap'
    trace.write_text('')
    env = dict(os.environ, PG_SHUTDOWN_TRACE=str(trace))
    command = [
        'node', '--import', str(output / 'trace-pg-shutdown.mjs'), '--import', 'tsx',
        '--test', '--test-reporter=tap',
        '--test-name-pattern=transaction client loss during HTTP',
        'tests/integration/core-reliability.test.ts',
    ]
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=20)
    print(f'probe {index}: exit={result.returncode} log={log} trace={trace}', flush=True)
    if result.returncode:
        break
