import { createRequire } from "node:module";
import { appendFileSync } from "node:fs";
import { performance } from "node:perf_hooks";

const require = createRequire(import.meta.url);
const pg = require("/Users/zcm/Desktop/kapibala/node_modules/pg");
const output = process.env.PG_SHUTDOWN_TRACE;
if (!output) throw new Error("PG_SHUTDOWN_TRACE must select a trace output file");
const started = performance.now();
const ids = new WeakMap();
let nextId = 0;
const observers = new WeakSet();
function id(object, prefix) {
  if (!ids.has(object)) ids.set(object, `${prefix}-${++nextId}`);
  return ids.get(object);
}
function record(event, fields = {}) {
  appendFileSync(output, JSON.stringify({
    process: process.pid,
    ms: Number((performance.now() - started).toFixed(3)),
    event,
    ...fields,
  }) + "\n");
}
function errorDetails(error) {
  return { message: error?.message, code: error?.code, stack: error?.stack };
}
function clientDetails(client) {
  return {
    client: id(client, "client"),
    backendPid: client.processID,
    database: client.database,
    errorListeners: client.listenerCount("error"),
    ending: client._ending,
    ended: client._ended,
  };
}
const clientEmit = pg.Client.prototype.emit;
const clientConnect = pg.Client.prototype.connect;
pg.Client.prototype.connect = function (...args) {
  if (args.length === 0 && this.database?.startsWith("kapibala_test_"))
    observers.add(this);
  return clientConnect.apply(this, args);
};
pg.Client.prototype.emit = function (event, ...args) {
  if (event === "error" || event === "end")
    record(`client.${event}`, {
      ...clientDetails(this),
      ...(event === "error" ? errorDetails(args[0]) : {}),
    });
  // Logging must not consume, replace or attach a handler to an error event.
  return clientEmit.call(this, event, ...args);
};
const clientEnd = pg.Client.prototype.end;
pg.Client.prototype.end = function (...args) {
  record("client.end.called", clientDetails(this));
  const delayMs = Number(process.env.PG_SHUTDOWN_DELAY_MS ?? 0);
  if (delayMs > 0 && observers.has(this) && !this._ending) {
    const connection = this.connection;
    const end = connection.end;
    connection.end = function (...endArgs) {
      record("probe.observer.shutdown.delayed", { ...clientDetails(thisClient), delayMs });
      setTimeout(() => {
        connection.end = end;
        end.apply(connection, endArgs);
      }, delayMs);
    };
    const thisClient = this;
  }
  return clientEnd.apply(this, args);
};
const poolEmit = pg.Pool.prototype.emit;
pg.Pool.prototype.emit = function (event, ...args) {
  if (event === "acquire" && this.listenerCount("error") === 0)
    observers.add(args[0]);
  if (["error", "release", "remove", "acquire"].includes(event)) {
    const client = event === "error" || event === "release" ? args[1] : args[0];
    record(`pool.${event}`, {
      pool: id(this, "pool"),
      poolErrorListeners: this.listenerCount("error"),
      ending: this.ending,
      ended: this.ended,
      ...(client ? clientDetails(client) : {}),
      ...(event === "error" ? errorDetails(args[0]) : {}),
      ...(event === "release" ? { releaseWithError: Boolean(args[0]) } : {}),
    });
  }
  return poolEmit.call(this, event, ...args);
};
const poolEnd = pg.Pool.prototype.end;
pg.Pool.prototype.end = function (...args) {
  record("pool.end.called", { pool: id(this, "pool") });
  const result = poolEnd.apply(this, args);
  if (!result?.then) return result;
  return result.then(
    (value) => {
      record("pool.end.resolved", { pool: id(this, "pool") });
      return value;
    },
    (error) => {
      record("pool.end.rejected", { pool: id(this, "pool"), ...errorDetails(error) });
      throw error;
    },
  );
};
const query = pg.Client.prototype.query;
pg.Client.prototype.query = function (...args) {
  const sql = typeof args[0] === "string" ? args[0] : args[0]?.text;
  if (typeof sql === "string" && /DROP DATABASE|pg_terminate_backend|pg_backend_pid|^(BEGIN|COMMIT|ROLLBACK)$/.test(sql))
    record("client.query", { ...clientDetails(this), sql });
  return query.apply(this, args);
};
process.on("uncaughtExceptionMonitor", (error, origin) => {
  record("uncaughtExceptionMonitor", { origin, ...errorDetails(error) });
});
record("probe.ready", { note: "No error handler installed or swallowed; observe only" });
